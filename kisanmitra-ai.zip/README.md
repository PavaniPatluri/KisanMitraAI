# KisanMitra AI (కిసాన్ మిత్ర AI)
> **Every Farmer Deserves an AI Expert.**

KisanMitra AI is a multilingual, voice-first intelligent agricultural assistant designed specifically for Indian farmers. It helps farmers identify crop diseases with multimodal computer vision, evaluate micro-climate weather risks, compare APMC mandi prices, access central and state government schemes (PM-KISAN, KCC, PMFBY, Rythu Bharosa), and manage daily farming operations.

---

## Key Features

1. **AI Crop Doctor (పంట వ్యాధి నిర్ధారణ)**
   - Upload or snap photographs of crop leaves/fruits.
   - Multimodal disease diagnosis powered by **Gemini 3.8 Flash** (`gemini-3.8-flash`).
   - Identifies pathogens (Alternaria, Pink Bollworm, Thrips, Early Blight).
   - Provides severity ratings (Mild, Moderate, Severe), confidence scores, and **strictly safe** biological/cultural next steps (Trichoderma, Neem formulations, KVK contacts).
   - Includes 1-click test specimen samples for quick evaluation without local images.
   - Saves consultations directly to the farmer's health logbook.

2. **Multilingual Voice Assistant (వాయిస్ అసిస్టెంట్)**
   - Designed as the primary feature with a large animated microphone and audio waveform meter.
   - Real-time speech transcription (STT) and synthesized spoken responses (TTS).
   - Speaks natively in **Telugu (తెలుగు)**, **Hindi (हिन्दी)**, **English**, **Tamil (தமிழ்)**, **Kannada (ಕನ್ನಡ)**, and **Marathi (मराठी)**.
   - Integrated with **Gnani.ai** (Prisma STT, Evon NLU, Timbre TTS) endpoints with seamless, automatic fallback to modern browser Web Speech APIs.
   - Context-aware agronomy that remembers farmer Ramesh's 3-acre cotton farm in Warangal, black soil, and drip irrigation history.

3. **Weather Intelligence & Spray Window**
   - Live meteorological data via Open-Meteo API for agricultural hubs (Warangal, Khammam, Karimnagar, Nizamabad, Guntur, Kurnool, Aurangabad, Indore).
   - 7-day agricultural forecast with daily farming actions.
   - Real-time morning spray safety window calculation based on wind drift (< 12 km/h) and precipitation probability.

4. **Smart Mandi Price Comparison**
   - Live AGMARKNET APMC market price tracking.
   - Tracks Cotton (Kapas), Red Chilli, Paddy, Maize, Soybean, and Turmeric across Warangal Enumamula, Khammam Mirchi Yard, and regional mandis.
   - 30-day historical price trend charts rendered using **Recharts**.
   - Identifies Minimum, Maximum, and Modal prices with MSP reference benchmarks.

5. **Government Schemes Assistant**
   - Detailed coverage of **PM-KISAN**, **Kisan Credit Card (KCC)**, **PMFBY Crop Insurance**, **Rythu Bharosa / Bandhu**, and **PM-KUSUM Solar Pumps**.
   - 30-Second Scheme Eligibility Quiz.
   - Document checklists, application steps, helpline numbers, and direct links to official government portals (`pmkisan.gov.in`, `pmfby.gov.in`, `dharani.telangana.gov.in`).

6. **AI Farm Risk Intelligence**
   - Dynamic multi-factor risk assessment combining weather forecasts, pest pressure, crop growth stage vulnerability, and soil moisture capacity.
   - Computes composite risk levels (Low, Medium, High) with actionable mitigation recommendations.

7. **Personalized Farm Profile & Multi-Farmer Authentication (రైతు లాగిన్)**
   - **Mobile & PIN/OTP Sign In:** Indian phone number authentication with 4-digit PIN verification or SMS OTP simulation.
   - **1-Click Demo Profiles:** Switch between diverse Indian farmers across different agro-climatic zones:
     - **Ramesh Kumar (Warangal, Telangana):** 3.0 Acres, Deep Black Soil, Borewell & Drip, Cotton (Flowering), Telugu.
     - **Lakshmi Devi (Guntur, Andhra Pradesh):** 4.5 Acres, Red Loamy Soil, Canal & Drip, Red Chilli (Teja), Telugu.
     - **Balram Patel (Indore, Madhya Pradesh):** 5.0 Acres, Heavy Black Soil, Tube well, Soybean & Wheat, Hindi.
     - **Suresh Gowda (Mandya, Karnataka):** 2.5 Acres, Clay Loam, Canal, Paddy (Sona Mahsuri), Kannada.
   - **New Farmer Registration:** Add custom farm records (Name, Mobile, Land size, Soil type, Crop, Irrigation, and Language).
   - Fully editable and persistently stored in backend JSON storage (`data/kisanmitra_db.json`).

---

## Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Lucide React, Recharts, Motion.
- **Backend:** Node.js, Express, TypeScript (`tsx`).
- **AI Models:**
  - **Google Gemini 3.8 Flash** (`@google/genai`) for crop disease vision diagnosis and multilingual agricultural advisory.
  - **Gnani.ai** (Prisma STT, Evon NLU, Timbre TTS) proxy endpoints with browser SpeechRecognition & SpeechSynthesis fallback.
- **Meteorology:** Open-Meteo Meteorological API.
- **Market Data:** AGMARKNET APMC schema.

---

## Setup & Local Development

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Configure Environment Variables:**
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Add your Gemini API Key:
   ```env
   GEMINI_API_KEY="your-gemini-api-key"
   ```
   *(Optional: configure GNANI_API_KEY if live Gnani enterprise credentials are available).*

3. **Start the Development Server:**
   ```bash
   npm run dev
   ```
   The application will be accessible at `http://localhost:3000`.

4. **Build for Production:**
   ```bash
   npm run build
   npm start
   ```

---

## Agricultural Safety & Ethics

KisanMitra AI follows strict agricultural safety guidelines aligned with the Indian Council of Agricultural Research (ICAR). It prioritizes biological control agents (Trichoderma viride, Pseudomonas fluorescens), botanical sprays (Neem oil), pheromone monitoring traps, and cultural practices. It never prescribes unregistered toxic chemical combinations. Farmers are advised to consult their local Krishi Vigyan Kendra (KVK) or Mandal Agricultural Extension Officer (AEO) for severe localized outbreaks.
