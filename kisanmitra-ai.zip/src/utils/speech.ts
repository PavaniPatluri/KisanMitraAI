import { LanguageCode } from '../types/index.ts';

// Browser SpeechRecognition interface declaration
interface IWindow extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

export const LANGUAGE_LOCALES: Record<LanguageCode, { locale: string; name: string; nativeName: string }> = {
  te: { locale: 'te-IN', name: 'Telugu', nativeName: 'తెలుగు' },
  hi: { locale: 'hi-IN', name: 'Hindi', nativeName: 'हिन्दी' },
  en: { locale: 'en-IN', name: 'English', nativeName: 'English' },
  ta: { locale: 'ta-IN', name: 'Tamil', nativeName: 'தமிழ்' },
  kn: { locale: 'kn-IN', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  mr: { locale: 'mr-IN', name: 'Marathi', nativeName: 'मराठी' }
};

export class SpeechHandler {
  private recognition: any = null;
  private isListening: boolean = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  public isSpeechSupported(): boolean {
    const win = window as unknown as IWindow;
    return Boolean(win.SpeechRecognition || win.webkitSpeechRecognition);
  }

  public isSynthesisSupported(): boolean {
    return 'speechSynthesis' in window;
  }

  public startListening(
    lang: LanguageCode,
    onResult: (text: string, isFinal: boolean) => void,
    onError: (error: string) => void,
    onEnd: () => void
  ): boolean {
    const win = window as unknown as IWindow;
    const SpeechRec = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRec) {
      onError('Browser does not support Speech Recognition. Please use text input or Chrome/Edge browser.');
      return false;
    }

    try {
      this.stopListening();
      this.recognition = new SpeechRec();
      const locale = LANGUAGE_LOCALES[lang]?.locale || 'te-IN';
      this.recognition.lang = locale;
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;

      this.recognition.onstart = () => {
        this.isListening = true;
      };

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const output = finalTranscript || interimTranscript;
        if (output) {
          onResult(output, Boolean(finalTranscript));
        }
      };

      this.recognition.onerror = (event: any) => {
        this.isListening = false;
        console.warn('Speech Recognition error event:', event.error);
        if (event.error === 'not-allowed') {
          onError('Microphone access blocked. Please allow microphone permissions in browser.');
        } else if (event.error !== 'no-speech') {
          onError(`Speech recognition note: ${event.error}`);
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        onEnd();
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      this.isListening = false;
      onError(err?.message || 'Failed to start microphone');
      return false;
    }
  }

  public stopListening(): void {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore already stopped
      }
      this.recognition = null;
    }
    this.isListening = false;
  }

  public speak(
    text: string,
    lang: LanguageCode,
    onStart?: () => void,
    onEnd?: () => void,
    onError?: (err: any) => void
  ): boolean {
    if (!this.isSynthesisSupported()) {
      if (onError) onError('Speech synthesis not supported in this environment');
      return false;
    }

    try {
      this.stopSpeaking();

      // Clean markdown stars, hashes, or technical symbols for clean speech output
      const cleanText = text
        .replace(/\*\*(.*?)\*\*/g, '$1')
        .replace(/#(.*?)\n/g, '$1')
        .replace(/`/g, '')
        .replace(/\n+/g, '. ');

      const utterance = new SpeechSynthesisUtterance(cleanText);
      const targetLocale = LANGUAGE_LOCALES[lang]?.locale || 'te-IN';
      utterance.lang = targetLocale;
      utterance.rate = 0.95; // Slightly slower, measured cadence for clear understanding
      utterance.pitch = 1.0;

      // Locate appropriate Indic voice if available in browser
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(
        v => v.lang === targetLocale || v.lang.startsWith(targetLocale.slice(0, 2))
      );
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.onstart = () => {
        if (onStart) onStart();
      };

      utterance.onend = () => {
        this.currentUtterance = null;
        if (onEnd) onEnd();
      };

      utterance.onerror = (e) => {
        this.currentUtterance = null;
        if (onEnd) onEnd();
        if (onError) onError(e);
      };

      this.currentUtterance = utterance;
      window.speechSynthesis.speak(utterance);
      return true;
    } catch (err) {
      console.warn('Speech synthesis error:', err);
      if (onError) onError(err);
      return false;
    }
  }

  public stopSpeaking(): void {
    if (this.isSynthesisSupported()) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        // ignore
      }
    }
    this.currentUtterance = null;
  }
}

export const speechHandler = new SpeechHandler();
