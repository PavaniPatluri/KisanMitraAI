/**
 * Sample crop disease photographs (as high-resolution vector data URIs)
 * Allows instant 1-click test of Gemini Vision Crop Doctor on any device
 */

export interface SampleImageItem {
  id: string;
  name: string;
  crop: string;
  expectedDisease: string;
  symptomsDescription: string;
  dataUrl: string;
}

// Generate realistic leaf illustration data URIs
function createLeafSvgDataUrl(options: {
  bgHue: string;
  leafFill: string;
  spotFill: string;
  hasCurling?: boolean;
  hasTargetRings?: boolean;
}): string {
  const { bgHue, leafFill, spotFill, hasCurling, hasTargetRings } = options;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" width="600" height="600">
    <rect width="600" height="600" fill="${bgHue}"/>
    <g transform="translate(100, 50)">
      <!-- Leaf Stem -->
      <path d="M 200 480 Q 195 320 200 80" stroke="#2d5a27" stroke-width="12" fill="none" stroke-linecap="round"/>
      
      <!-- Leaf Blade -->
      <path d="M 200 80 C 70 120 40 280 120 420 C 160 480 190 480 200 480 C 210 480 240 480 280 420 C 360 280 330 120 200 80 Z" fill="${leafFill}" stroke="#1e4620" stroke-width="6"/>
      
      <!-- Veins -->
      <path d="M 200 160 Q 140 180 90 220" stroke="#3b7a33" stroke-width="5" fill="none"/>
      <path d="M 200 160 Q 260 180 310 220" stroke="#3b7a33" stroke-width="5" fill="none"/>
      <path d="M 200 240 Q 130 270 80 320" stroke="#3b7a33" stroke-width="5" fill="none"/>
      <path d="M 200 240 Q 270 270 320 320" stroke="#3b7a33" stroke-width="5" fill="none"/>
      <path d="M 200 320 Q 150 350 110 400" stroke="#3b7a33" stroke-width="5" fill="none"/>
      <path d="M 200 320 Q 250 350 290 400" stroke="#3b7a33" stroke-width="5" fill="none"/>

      <!-- Disease Spots / Lesions -->
      <circle cx="150" cy="220" r="28" fill="${spotFill}" opacity="0.9"/>
      <circle cx="150" cy="220" r="14" fill="#3e1a00" opacity="0.8"/>
      <circle cx="150" cy="220" r="36" stroke="#d4b106" stroke-width="4" fill="none" opacity="0.6"/>

      <circle cx="260" cy="270" r="32" fill="${spotFill}" opacity="0.9"/>
      <circle cx="260" cy="270" r="16" fill="#3e1a00" opacity="0.8"/>
      <circle cx="260" cy="270" r="42" stroke="#d4b106" stroke-width="4" fill="none" opacity="0.6"/>

      <circle cx="140" cy="330" r="22" fill="${spotFill}" opacity="0.9"/>
      <circle cx="240" cy="180" r="18" fill="${spotFill}" opacity="0.9"/>
      <circle cx="210" cy="380" r="24" fill="${spotFill}" opacity="0.85"/>
      
      ${hasCurling ? `
      <!-- Leaf margin chlorosis / curl -->
      <path d="M 70 260 Q 120 310 140 370" stroke="#c29d0b" stroke-width="12" fill="none" opacity="0.8"/>
      <path d="M 330 260 Q 280 310 260 370" stroke="#c29d0b" stroke-width="12" fill="none" opacity="0.8"/>
      ` : ''}

      ${hasTargetRings ? `
      <!-- Concentric target rings (Alternaria) -->
      <ellipse cx="160" cy="230" rx="45" ry="40" stroke="#5a2e0a" stroke-width="3" fill="none" stroke-dasharray="6,4"/>
      <ellipse cx="250" cy="290" rx="50" ry="45" stroke="#5a2e0a" stroke-width="3" fill="none" stroke-dasharray="6,4"/>
      ` : ''}
    </g>
    <text x="30" y="560" font-family="sans-serif" font-weight="bold" font-size="22" fill="#1b4d24">KisanMitra AI - Diagnostic Sample</text>
  </svg>`;

  try {
    const base64 = btoa(unescape(encodeURIComponent(svg)));
    return `data:image/svg+xml;base64,${base64}`;
  } catch {
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }
}

export const SAMPLE_CROP_IMAGES: SampleImageItem[] = [
  {
    id: 'sample_cotton_spot',
    name: 'Cotton - Alternaria Leaf Spot (పత్తి ఆకుమచ్చ)',
    crop: 'Cotton',
    expectedDisease: 'Alternaria Leaf Spot (ఆల్టర్నేరియా ఆకుమచ్చ తెగులు)',
    symptomsDescription: 'Circular brown necrotic spots with concentric target-board rings on middle leaves after recent rainfall.',
    dataUrl: createLeafSvgDataUrl({
      bgHue: '#f0f5ec',
      leafFill: '#539645',
      spotFill: '#6e3914',
      hasTargetRings: true
    })
  },
  {
    id: 'sample_chilli_curl',
    name: 'Chilli - Thrips & Leaf Curl (మిర్చి ముడత)',
    crop: 'Chilli',
    expectedDisease: 'Chilli Leaf Curl & Thrips (తామర పురుగు / ముడత తెగులు)',
    symptomsDescription: 'Upward cupping of young leaves, crinkling along margin, bronzing on underside.',
    dataUrl: createLeafSvgDataUrl({
      bgHue: '#f8f4eb',
      leafFill: '#6aa34b',
      spotFill: '#825619',
      hasCurling: true
    })
  },
  {
    id: 'sample_tomato_blight',
    name: 'Tomato - Early Blight (టమాటా ఎండు తెగులు)',
    crop: 'Tomato',
    expectedDisease: 'Early Blight (Alternaria solani)',
    symptomsDescription: 'Dark brown sunken spots with yellow halos on lower leaves spreading upward.',
    dataUrl: createLeafSvgDataUrl({
      bgHue: '#f4f6ef',
      leafFill: '#4e8d3e',
      spotFill: '#50290e',
      hasTargetRings: true
    })
  },
  {
    id: 'sample_cotton_healthy',
    name: 'Cotton - Healthy Leaf (ఆరోగ్యకరమైన పత్తి ఆకు)',
    crop: 'Cotton',
    expectedDisease: 'Healthy Foliage (ఆరోగ్యకరమైన ఆకు)',
    symptomsDescription: 'Lush dark green leaf blade, no lesions, clean venation, vigorous square formation.',
    dataUrl: createLeafSvgDataUrl({
      bgHue: '#edf7ea',
      leafFill: '#2e7d32',
      spotFill: '#2e7d32' // no brown spots
    })
  }
];
