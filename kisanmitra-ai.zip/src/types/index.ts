export type LanguageCode = 'te' | 'hi' | 'en' | 'ta' | 'kn' | 'mr';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  nativeLabel: string;
  voiceCode: string; // for speech synthesis
}

export interface FarmerProfile {
  id: string;
  name: string;
  age?: number;
  location: string;
  district: string;
  state: string;
  preferredLanguage: LanguageCode;
  landArea: string;
  soilType: string;
  irrigationMethod: string;
  cropName: string;
  cropGrowthStage: string;
  sowingDate?: string;
  phone?: string;
  avatar?: string;
  pin?: string;
}

export interface AuthSession {
  farmer: FarmerProfile;
  token?: string;
  isLoggedIn: boolean;
}

export interface LoginCredentials {
  phone: string;
  pin?: string;
  otp?: string;
}

export interface RegisterCredentials {
  name: string;
  phone: string;
  pin: string;
  location: string;
  district: string;
  state: string;
  preferredLanguage: LanguageCode;
  landArea: string;
  soilType: string;
  irrigationMethod: string;
  cropName: string;
  cropGrowthStage: string;
}

export interface FarmTask {
  id: string;
  title: string;
  titleLocal?: Record<string, string>;
  crop: string;
  category: 'Irrigation' | 'Fertilizer' | 'Pesticide' | 'Weeding' | 'Scouting' | 'Harvest';
  dueDate: string;
  completed: boolean;
  priority: 'High' | 'Medium' | 'Low';
  notes: string;
}

export interface AgriAlert {
  id: string;
  title: string;
  message: string;
  type: 'pest' | 'weather' | 'mandi' | 'scheme';
  severity: 'urgent' | 'warning' | 'info';
  timestamp: string;
  region: string;
}

export interface CropDiagnosis {
  id: string;
  timestamp: string;
  crop: string;
  diseaseName: string;
  confidence: number;
  severity: 'Mild' | 'Moderate' | 'Severe' | 'Healthy' | 'Unclear';
  symptoms: string[];
  causes: string[];
  safeNextSteps: string[];
  prevention: string[];
  notes?: string;
  imageUrl?: string;
  language: LanguageCode;
  source: 'Crop Doctor' | 'Voice Assistant';
  status: 'Active' | 'Under Observation' | 'Resolved';
  isUnclear?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  language: LanguageCode;
  timestamp: string;
  cropDetected?: string;
  recommendedAction?: string;
  followUpQuestion?: string;
  suggestedQuestions?: string[];
  audioSource?: 'browser' | 'gnani' | 'none';
}

export interface MandiRecord {
  id: string;
  commodity: string;
  variety: string;
  state: string;
  district: string;
  market: string;
  minPrice: number;
  maxPrice: number;
  modalPrice: number;
  trend: 'up' | 'down' | 'stable';
  changePercent: number;
  arrivalQuantity: string;
  date: string;
  history30d: { date: string; price: number; volume: number }[];
}

export interface GovernmentScheme {
  id: string;
  name: string;
  shortName: string;
  category: 'Direct Income' | 'Credit' | 'Insurance' | 'Subsidies' | 'State Benefit';
  amount: string;
  overview: string;
  eligibility: string[];
  documents: string[];
  procedure: string[];
  officialLink: string;
  helpline: string;
  tags: string[];
}

export interface WeatherData {
  city: string;
  state: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  windDirection: string;
  condition: string;
  icon: string;
  rainfallChance: number;
  uvIndex: number;
  advisory: string;
  daily: {
    day: string;
    date: string;
    minTemp: number;
    maxTemp: number;
    condition: string;
    rainProb: number;
    farmingAction: string;
  }[];
  hourly: {
    time: string;
    temp: number;
    rainProb: number;
    humidity: number;
  }[];
}

export interface FarmRiskAssessment {
  overallRisk: 'Low' | 'Medium' | 'High';
  score: number; // 0-100
  factors: {
    category: 'Weather' | 'Pest & Disease' | 'Soil Moisture' | 'Market Price';
    level: 'Low' | 'Medium' | 'High';
    title: string;
    description: string;
    recommendation: string;
  }[];
  summary: string;
}
