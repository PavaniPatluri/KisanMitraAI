/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { LandingPage } from './views/LandingPage.tsx';
import { DashboardView } from './views/DashboardView.tsx';
import { CropDoctorView } from './views/CropDoctorView.tsx';
import { VoiceAssistantView } from './views/VoiceAssistantView.tsx';
import { WeatherView } from './views/WeatherView.tsx';
import { MandiPricesView } from './views/MandiPricesView.tsx';
import { GovernmentSchemesView } from './views/GovernmentSchemesView.tsx';
import { FarmRiskView } from './views/FarmRiskView.tsx';
import { ProfileView } from './views/ProfileView.tsx';
import { LoginPage } from './views/LoginPage.tsx';
import { GitHubSyncModal } from './components/GitHubSyncModal.tsx';

import {
  FarmerProfile,
  FarmTask,
  AgriAlert,
  CropDiagnosis,
  MandiRecord,
  GovernmentScheme,
  WeatherData,
  FarmRiskAssessment,
  ChatMessage,
  LanguageCode
} from './types/index.ts';
import { api } from './services/api.ts';
import { Sparkles, CheckCircle2, ChevronRight, X, Play, Github } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('landing');
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode>('te'); // Telugu default as requested
  const [gitHubModalOpen, setGitHubModalOpen] = useState<boolean>(false);

  // Application Data States
  const [profile, setProfile] = useState<FarmerProfile>({
    id: 'farmer_ramesh_01',
    name: 'Ramesh Kumar (రామేష్)',
    age: 44,
    location: 'Warangal Rural',
    district: 'Warangal',
    state: 'Telangana',
    preferredLanguage: 'te',
    landArea: '3.0 Acres',
    soilType: 'Deep Black Cotton Soil (నల్లరేగడి నేల)',
    irrigationMethod: 'Borewell with Micro-Drip',
    cropName: 'Cotton - BT Hybrid (పత్తి)',
    cropGrowthStage: 'Square & Early Flowering (65 Days)',
    phone: '+91 98480 34211'
  });

  const [availableProfiles, setAvailableProfiles] = useState<FarmerProfile[]>([]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [tasks, setTasks] = useState<FarmTask[]>([]);
  const [alerts, setAlerts] = useState<AgriAlert[]>([]);
  const [consultations, setConsultations] = useState<CropDiagnosis[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [mandiRecords, setMandiRecords] = useState<MandiRecord[]>([]);
  const [schemes, setSchemes] = useState<GovernmentScheme[]>([]);
  const [riskAssessment, setRiskAssessment] = useState<FarmRiskAssessment | null>(null);

  const [apiStatus, setApiStatus] = useState({
    geminiLive: true,
    gnaniLive: false
  });

  // Guided Demo Scenario walkthrough bar
  const [showDemoGuide, setShowDemoGuide] = useState<boolean>(true);
  const [demoStep, setDemoStep] = useState<number>(1);

  // Initialize data on mount
  useEffect(() => {
    async function loadInitialData() {
      try {
        const [
          statusData,
          profileData,
          profilesData,
          weatherData,
          tasksData,
          alertsData,
          consultationsData,
          chatsData,
          mandiData,
          schemesData,
          riskData
        ] = await Promise.all([
          api.getStatus().catch(() => null),
          api.getProfile().catch(() => null),
          api.getAuthProfiles().catch(() => []),
          api.getWeather('warangal').catch(() => null),
          api.getTasks().catch(() => []),
          api.getAlerts().catch(() => []),
          api.getConsultations().catch(() => []),
          api.getChatHistory().catch(() => []),
          api.getMandiPrices().catch(() => []),
          api.getSchemes().catch(() => []),
          api.getRiskAssessment().catch(() => null)
        ]);

        if (statusData?.aiCapabilities) {
          setApiStatus({
            geminiLive: Boolean(statusData.aiCapabilities.geminiVision?.enabled),
            gnaniLive: Boolean(statusData.aiCapabilities.gnaniVoice?.enabled)
          });
        }
        if (profilesData && Array.isArray(profilesData)) {
          setAvailableProfiles(profilesData);
        }
        if (profileData) {
          setProfile(profileData);
          if (profileData.preferredLanguage) {
            setSelectedLanguage(profileData.preferredLanguage);
          }
        }
        if (weatherData) setWeather(weatherData);
        if (tasksData) setTasks(tasksData);
        if (alertsData) setAlerts(alertsData);
        if (consultationsData) setConsultations(consultationsData);
        if (chatsData) setChatHistory(chatsData);
        if (mandiData) setMandiRecords(mandiData);
        if (schemesData) setSchemes(schemesData);
        if (riskData) setRiskAssessment(riskData);
      } catch (err) {
        console.error('Failed to load initial data:', err);
      }
    }

    loadInitialData();
  }, []);

  // Handlers
  const handleToggleTask = async (taskId: string, currentCompleted: boolean) => {
    const updated = await api.updateTask(taskId, { completed: !currentCompleted });
    if (updated) {
      setTasks(prev => prev.map(t => (t.id === taskId ? updated : t)));
    }
  };

  const handleAddTask = async (
    title: string,
    category: FarmTask['category'],
    priority: FarmTask['priority']
  ) => {
    const created = await api.addTask({
      title,
      crop: profile.cropName || 'Cotton',
      category,
      priority,
      dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      completed: false,
      notes: 'Added from farmer dashboard'
    });
    setTasks(prev => [created, ...prev]);
  };

  const handleSendMessage = async (message: string, language: LanguageCode): Promise<ChatMessage> => {
    const res = await api.sendVoiceChat(message, language);
    // Reload full chat history to stay synced with backend
    const updatedChats = await api.getChatHistory();
    setChatHistory(updatedChats);
    return res;
  };

  const handleClearChat = async () => {
    await api.clearChatHistory();
    setChatHistory([]);
  };

  const handleDiagnoseCrop = async (params: {
    imageBase64?: string;
    mimeType?: string;
    cropType: string;
    symptoms: string;
    language: LanguageCode;
  }) => {
    return await api.diagnoseCrop(params);
  };

  const handleSaveConsultation = async (consultation: Omit<CropDiagnosis, 'id' | 'timestamp'>) => {
    const saved = await api.addConsultation(consultation);
    setConsultations(prev => [saved, ...prev]);
    // Also re-fetch updated risk assessment
    const newRisk = await api.getRiskAssessment();
    setRiskAssessment(newRisk);
  };

  const handleRefreshWeather = async (district: string) => {
    const w = await api.getWeather(district);
    setWeather(w);
  };

  const handleRefreshRisk = async () => {
    const r = await api.getRiskAssessment();
    setRiskAssessment(r);
  };

  const handleLoginSuccess = (newProfile: FarmerProfile) => {
    setProfile(newProfile);
    if (newProfile.preferredLanguage) {
      setSelectedLanguage(newProfile.preferredLanguage);
    }
    setCurrentView('dashboard');
    if (newProfile.district) {
      handleRefreshWeather(newProfile.district);
    }
  };

  const handleSwitchProfile = async (id: string): Promise<boolean> => {
    const res = await api.switchProfile(id);
    if (res.success && res.profile) {
      setProfile(res.profile);
      if (res.profile.preferredLanguage) {
        setSelectedLanguage(res.profile.preferredLanguage);
      }
      if (res.profile.district) {
        handleRefreshWeather(res.profile.district);
      }
      return true;
    }
    return false;
  };

  const handleLoginWithPhone = async (phone: string, pin: string) => {
    return await api.login(phone, pin);
  };

  const handleRegisterFarmer = async (data: any) => {
    const res = await api.register(data);
    if (res.success && res.profile) {
      setAvailableProfiles(prev => [...prev, res.profile!]);
    }
    return res;
  };

  const handleUpdateProfile = async (updated: Partial<FarmerProfile>): Promise<FarmerProfile> => {
    const saved = await api.updateProfile(updated);
    setProfile(saved);
    return saved;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAF5] text-[#1F2937]">
      {/* Top Demo Guide Banner */}
      {showDemoGuide && (
        <div className="bg-emerald-900 text-emerald-100 text-xs py-2 px-4 border-b border-emerald-800">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="font-bold text-white">Full Experience Walkthrough:</span>
              <span className="text-emerald-200 hidden md:inline">
                1. Select Telugu → 2. Open Voice AI → 3. Speak or tap sample → 4. Listen to Telugu audio → 5. Diagnose Leaf in Crop Doctor → 6. Save consultation
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setCurrentView('voice');
                  setSelectedLanguage('te');
                }}
                className="px-2.5 py-1 rounded-md bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <Play className="w-3 h-3 fill-white" />
                <span>Try Voice AI</span>
              </button>
              <button
                onClick={() => setCurrentView('crop-doctor')}
                className="px-2.5 py-1 rounded-md bg-white hover:bg-emerald-100 text-emerald-950 font-bold text-[11px] cursor-pointer"
              >
                Crop Doctor
              </button>
              <button
                onClick={() => setCurrentView('login')}
                className="px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] cursor-pointer"
              >
                Farmer Login
              </button>
              <button
                onClick={() => setGitHubModalOpen(true)}
                className="px-2.5 py-1 rounded-md bg-gray-900 hover:bg-black text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <Github className="w-3 h-3" />
                <span>GitHub Repo</span>
              </button>
              <button
                onClick={() => setShowDemoGuide(false)}
                className="text-emerald-400 hover:text-white p-1 cursor-pointer"
                title="Dismiss banner"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Header */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        selectedLanguage={selectedLanguage}
        onSelectLanguage={setSelectedLanguage}
        profile={profile}
        apiStatus={apiStatus}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {currentView === 'landing' && (
          <LandingPage
            onNavigate={setCurrentView}
            selectedLanguage={selectedLanguage}
          />
        )}

        {currentView === 'dashboard' && (
          <DashboardView
            profile={profile}
            weather={weather}
            tasks={tasks}
            alerts={alerts}
            consultations={consultations}
            mandiRecords={mandiRecords}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onNavigate={setCurrentView}
            selectedLanguage={selectedLanguage}
          />
        )}

        {currentView === 'crop-doctor' && (
          <CropDoctorView
            onDiagnose={handleDiagnoseCrop}
            onSaveConsultation={handleSaveConsultation}
            selectedLanguage={selectedLanguage}
            profile={profile}
            consultations={consultations}
          />
        )}

        {currentView === 'voice' && (
          <VoiceAssistantView
            chatHistory={chatHistory}
            onSendMessage={handleSendMessage}
            onClearChat={handleClearChat}
            selectedLanguage={selectedLanguage}
            onSelectLanguage={setSelectedLanguage}
            profile={profile}
            gnaniStatus={apiStatus.gnaniLive ? { isConfigured: true, hasApiKey: true } : { isConfigured: false, hasApiKey: false }}
            onNavigate={setCurrentView}
          />
        )}

        {currentView === 'weather' && (
          <WeatherView
            weather={weather}
            onRefreshWeather={handleRefreshWeather}
            currentDistrict={profile.district || 'warangal'}
          />
        )}

        {currentView === 'mandi' && (
          <MandiPricesView
            mandiRecords={mandiRecords}
          />
        )}

        {currentView === 'schemes' && (
          <GovernmentSchemesView
            schemes={schemes}
            profile={profile}
          />
        )}

        {currentView === 'risk' && (
          <FarmRiskView
            riskAssessment={riskAssessment}
            onRefreshRisk={handleRefreshRisk}
            profile={profile}
            weather={weather}
            onNavigate={setCurrentView}
          />
        )}

        {currentView === 'profile' && (
          <ProfileView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            selectedLanguage={selectedLanguage}
            onSelectLanguage={setSelectedLanguage}
            onNavigate={setCurrentView}
          />
        )}

        {currentView === 'login' && (
          <LoginPage
            currentProfile={profile}
            availableProfiles={availableProfiles}
            onLoginSuccess={handleLoginSuccess}
            onNavigate={setCurrentView}
            selectedLanguage={selectedLanguage}
            onSelectLanguage={setSelectedLanguage}
            onSwitchProfile={handleSwitchProfile}
            onLoginWithPhone={handleLoginWithPhone}
            onRegisterFarmer={handleRegisterFarmer}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer onNavigate={setCurrentView} />

      {/* GitHub Repository Sync & Download Modal */}
      <GitHubSyncModal
        isOpen={gitHubModalOpen}
        onClose={() => setGitHubModalOpen(false)}
      />
    </div>
  );
}
