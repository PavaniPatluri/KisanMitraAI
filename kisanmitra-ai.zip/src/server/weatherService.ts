import { WeatherData } from '../types/index.ts';

interface DistrictCoords {
  lat: number;
  lon: number;
  name: string;
  state: string;
}

export const DISTRICT_COORDS: Record<string, DistrictCoords> = {
  warangal: { lat: 17.9689, lon: 79.5941, name: 'Warangal', state: 'Telangana' },
  khammam: { lat: 17.2473, lon: 80.1514, name: 'Khammam', state: 'Telangana' },
  karimnagar: { lat: 18.4386, lon: 79.1288, name: 'Karimnagar', state: 'Telangana' },
  nizamabad: { lat: 18.6725, lon: 78.0941, name: 'Nizamabad', state: 'Telangana' },
  guntur: { lat: 16.3067, lon: 80.4365, name: 'Guntur', state: 'Andhra Pradesh' },
  kurnool: { lat: 15.8281, lon: 78.0373, name: 'Kurnool', state: 'Andhra Pradesh' },
  aurangabad: { lat: 19.8762, lon: 75.3433, name: 'Chhatrapati Sambhajinagar', state: 'Maharashtra' },
  indore: { lat: 22.7196, lon: 75.8577, name: 'Indore', state: 'Madhya Pradesh' }
};

export async function fetchWeather(districtKey: string = 'warangal'): Promise<WeatherData> {
  const target = DISTRICT_COORDS[districtKey.toLowerCase()] || DISTRICT_COORDS.warangal;

  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${target.lat}&longitude=${target.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,relative_humidity_2m,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max&timezone=Asia%2FKolkata`;

    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`Open-Meteo HTTP ${res.status}`);
    }
    const data = await res.json();

    const current = data.current || {};
    const daily = data.daily || {};
    const hourly = data.hourly || {};

    const conditionInfo = mapWeatherCode(current.weather_code);
    const rainChance = daily.precipitation_probability_max?.[0] || 10;
    const temp = Math.round(current.temperature_2m ?? 29);
    const humidity = Math.round(current.relative_humidity_2m ?? 62);
    const wind = Math.round(current.wind_speed_10m ?? 8);

    // Build intelligent agricultural advisory based on actual current and rain parameters
    let advisory = 'Weather conditions are optimal for general crop maintenance and drip irrigation.';
    if (rainChance > 50) {
      advisory = 'High probability of rain. Postpone chemical foliar sprays and fertilizer top-dressing to prevent wash-off. Ensure field drainage channels are clear.';
    } else if (wind > 15) {
      advisory = 'Moderate to strong winds detected. Avoid spray operations to prevent droplet drift. Secure young seedlings and stake tall crops if needed.';
    } else if (temp > 34) {
      advisory = 'High temperature alert. Irrigate in early morning or late evening to reduce root stress and square drop in cotton.';
    } else {
      advisory = 'Favorable calm weather. Safe window for foliar sprays (19:19:19 / micronutrients) between 7:30 AM and 10:30 AM.';
    }

    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dailyList = (daily.time || []).slice(0, 7).map((tStr: string, idx: number) => {
      const d = new Date(tStr);
      const code = daily.weather_code?.[idx] ?? 1;
      const rainP = daily.precipitation_probability_max?.[idx] ?? 15;
      const cInfo = mapWeatherCode(code);
      let action = 'Regular monitoring';
      if (rainP > 40) action = 'Rain risk; postpone spraying';
      else if (daily.temperature_2m_max?.[idx] > 33) action = 'Maintain drip irrigation';
      else action = 'Safe for foliar spray';

      return {
        day: idx === 0 ? 'Today' : idx === 1 ? 'Tomorrow' : dayNames[d.getDay()],
        date: d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }),
        minTemp: Math.round(daily.temperature_2m_min?.[idx] ?? 20),
        maxTemp: Math.round(daily.temperature_2m_max?.[idx] ?? 31),
        condition: cInfo.text,
        rainProb: rainP,
        farmingAction: action
      };
    });

    const hourlyList = (hourly.time || []).slice(0, 12).map((tStr: string, idx: number) => {
      const d = new Date(tStr);
      return {
        time: d.toLocaleTimeString('en-IN', { hour: 'numeric', hour12: true }),
        temp: Math.round(hourly.temperature_2m?.[idx] ?? temp),
        rainProb: hourly.precipitation_probability?.[idx] ?? 10,
        humidity: Math.round(hourly.relative_humidity_2m?.[idx] ?? humidity)
      };
    });

    return {
      city: target.name,
      state: target.state,
      temperature: temp,
      feelsLike: Math.round(current.apparent_temperature ?? temp),
      humidity: humidity,
      windSpeed: wind,
      windDirection: `${Math.round(current.wind_direction_10m ?? 80)}°`,
      condition: conditionInfo.text,
      icon: conditionInfo.icon,
      rainfallChance: rainChance,
      uvIndex: Math.round(daily.uv_index_max?.[0] ?? 6),
      advisory,
      daily: dailyList,
      hourly: hourlyList
    };
  } catch (err) {
    console.warn('Weather API failed, using fallback data:', err);
    return getFallbackWeather(target);
  }
}

function mapWeatherCode(code: number): { text: string; icon: string } {
  if (code === 0) return { text: 'Clear Sky (ప్రశాంతమైన ఆకాశం)', icon: 'sun' };
  if (code === 1 || code === 2) return { text: 'Partly Cloudy (పాక్షికంగా మేఘావృతం)', icon: 'cloud-sun' };
  if (code === 3) return { text: 'Overcast (మేఘావృతం)', icon: 'cloud' };
  if (code >= 45 && code <= 48) return { text: 'Misty / Fog (పొగమంచు)', icon: 'cloud-fog' };
  if (code >= 51 && code <= 55) return { text: 'Light Drizzle (తుంపర వర్షం)', icon: 'cloud-drizzle' };
  if (code >= 61 && code <= 65) return { text: 'Moderate Rain (వర్షం)', icon: 'cloud-rain' };
  if (code >= 80 && code <= 82) return { text: 'Rain Showers (జల్లులు)', icon: 'cloud-rain' };
  if (code >= 95) return { text: 'Thunderstorm (ఉరుములతో కూడిన వర్షం)', icon: 'cloud-lightning' };
  return { text: 'Sunny & Mild (ఎండ)', icon: 'sun' };
}

function getFallbackWeather(target: DistrictCoords): WeatherData {
  return {
    city: target.name,
    state: target.state,
    temperature: 30,
    feelsLike: 32,
    humidity: 58,
    windSpeed: 9,
    windDirection: '75° ENE',
    condition: 'Partly Cloudy (పాక్షికంగా మేఘావృతం)',
    icon: 'cloud-sun',
    rainfallChance: 15,
    uvIndex: 6,
    advisory: 'Clear to partly cloudy conditions. Safe window for cotton foliar nutrition and bollworm scouting.',
    daily: [
      { day: 'Today', date: 'Nov 10', minTemp: 21, maxTemp: 31, condition: 'Partly Cloudy', rainProb: 15, farmingAction: 'Safe for foliar spray' },
      { day: 'Tomorrow', date: 'Nov 11', minTemp: 20, maxTemp: 31, condition: 'Sunny & Clear', rainProb: 10, farmingAction: 'Run 2hr drip irrigation' },
      { day: 'Wed', date: 'Nov 12', minTemp: 21, maxTemp: 32, condition: 'Sunny', rainProb: 10, farmingAction: 'Monitor pheromone traps' },
      { day: 'Thu', date: 'Nov 13', minTemp: 22, maxTemp: 30, condition: 'Partly Cloudy', rainProb: 25, farmingAction: 'Soil weed cultivation' },
      { day: 'Fri', date: 'Nov 14', minTemp: 22, maxTemp: 30, condition: 'Light Cloud Cover', rainProb: 30, farmingAction: 'Foliar NPK 19:19:19 spray' },
      { day: 'Sat', date: 'Nov 15', minTemp: 21, maxTemp: 29, condition: 'Passing Shower', rainProb: 40, farmingAction: 'Hold pesticide sprays' },
      { day: 'Sun', date: 'Nov 16', minTemp: 20, maxTemp: 30, condition: 'Sunny', rainProb: 15, farmingAction: 'Field inspection' }
    ],
    hourly: [
      { time: '08:00 AM', temp: 24, rainProb: 5, humidity: 75 },
      { time: '11:00 AM', temp: 29, rainProb: 10, humidity: 60 },
      { time: '02:00 PM', temp: 31, rainProb: 15, humidity: 52 },
      { time: '05:00 PM', temp: 28, rainProb: 15, humidity: 64 },
      { time: '08:00 PM', temp: 25, rainProb: 10, humidity: 72 }
    ]
  };
}
