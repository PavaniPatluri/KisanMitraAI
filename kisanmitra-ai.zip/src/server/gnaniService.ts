/**
 * Gnani AI Integration Service
 * Wraps Gnani AI Prisma (Speech-to-Text), Evon (Conversational NLU), and Timbre (Text-to-Speech)
 * If Gnani credentials are not supplied, provides graceful fallback instructions for browser native speech APIs.
 */

export interface GnaniConfigStatus {
  isConfigured: boolean;
  hasApiKey: boolean;
  hasClientId: boolean;
  endpoints: {
    prisma: string;
    timbre: string;
    evon: string;
  };
  supportedLanguages: string[];
}

const GNANI_API_KEY = process.env.GNANI_API_KEY || '';
const GNANI_CLIENT_ID = process.env.GNANI_CLIENT_ID || '';
const GNANI_TOKEN = process.env.GNANI_TOKEN || '';
const GNANI_PRISMA_ENDPOINT = process.env.GNANI_PRISMA_ENDPOINT || 'https://speech.gnani.ai/v1/stt';
const GNANI_TIMBRE_ENDPOINT = process.env.GNANI_TIMBRE_ENDPOINT || 'https://speech.gnani.ai/v1/tts';
const GNANI_EVON_ENDPOINT = process.env.GNANI_EVON_ENDPOINT || 'https://speech.gnani.ai/v1/evon';

export function getGnaniStatus(): GnaniConfigStatus {
  const isConfigured = Boolean(GNANI_API_KEY && GNANI_API_KEY.trim() !== '');
  return {
    isConfigured,
    hasApiKey: isConfigured,
    hasClientId: Boolean(GNANI_CLIENT_ID),
    endpoints: {
      prisma: GNANI_PRISMA_ENDPOINT,
      timbre: GNANI_TIMBRE_ENDPOINT,
      evon: GNANI_EVON_ENDPOINT
    },
    supportedLanguages: ['te-IN', 'hi-IN', 'en-IN', 'ta-IN', 'kn-IN', 'mr-IN']
  };
}

/**
 * Proxy for Gnani AI Prisma Speech-to-Text
 */
export async function transcribeWithGnaniPrisma(audioBuffer: Buffer, languageCode: string): Promise<{ text: string; confidence: number } | null> {
  if (!GNANI_API_KEY) {
    return null;
  }

  try {
    const response = await fetch(GNANI_PRISMA_ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GNANI_API_KEY}`,
        'X-Client-Id': GNANI_CLIENT_ID,
        'Content-Type': 'audio/wav',
        'X-Language-Code': languageCode
      },
      body: new Uint8Array(audioBuffer)
    });

    if (!response.ok) {
      console.warn(`Gnani Prisma STT responded with HTTP ${response.status}`);
      return null;
    }

    const data = await response.json();
    return {
      text: data.transcript || data.text || '',
      confidence: data.confidence || 0.95
    };
  } catch (err) {
    console.error('Gnani Prisma transcription error:', err);
    return null;
  }
}

/**
 * Proxy for Gnani AI Timbre Text-to-Speech
 */
export async function synthesizeWithGnaniTimbre(text: string, languageCode: string): Promise<Buffer | null> {
  if (!GNANI_API_KEY) {
    return null;
  }

  try {
    const response = await fetch(GNANI_TIMBRE_ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GNANI_API_KEY}`,
        'X-Client-Id': GNANI_CLIENT_ID,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        text,
        language: languageCode,
        voice: languageCode === 'te-IN' ? 'telugu_female_01' : 'hindi_female_01',
        audioFormat: 'wav'
      })
    });

    if (!response.ok) {
      console.warn(`Gnani Timbre TTS responded with HTTP ${response.status}`);
      return null;
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } catch (err) {
    console.error('Gnani Timbre TTS synthesis error:', err);
    return null;
  }
}
