import fs from 'fs';
import path from 'path';
import {
  FarmerProfile,
  FarmTask,
  AgriAlert,
  CropDiagnosis,
  MandiRecord,
  GovernmentScheme,
  ChatMessage
} from '../types/index.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'kisanmitra_db.json');

export interface DatabaseSchema {
  profile: FarmerProfile;
  profiles: FarmerProfile[];
  tasks: FarmTask[];
  alerts: AgriAlert[];
  consultations: CropDiagnosis[];
  chatHistory: ChatMessage[];
  mandiRecords: MandiRecord[];
  schemes: GovernmentScheme[];
}

const defaultProfile: FarmerProfile = {
  id: 'farmer_ramesh_01',
  name: 'Ramesh Kumar (రామేష్)',
  age: 44,
  location: 'Warangal Rural (వర్ధన్నపేట)',
  district: 'Warangal',
  state: 'Telangana',
  preferredLanguage: 'te',
  landArea: '3.0 Acres',
  soilType: 'Deep Black Cotton Soil (నల్లరేగడి నేల)',
  irrigationMethod: 'Borewell with Micro-Drip (బోరుబావి & బిందు సేద్యం)',
  cropName: 'Cotton - BT Hybrid (పత్తి)',
  cropGrowthStage: 'Square & Early Flowering (పూత & పిందె దశ - 60-70 Days)',
  sowingDate: '2026-07-10',
  phone: '9848034211',
  pin: '1234'
};

export const defaultProfiles: FarmerProfile[] = [
  defaultProfile,
  {
    id: 'farmer_lakshmi_02',
    name: 'Lakshmi Devi (లక్ష్మీదేవి)',
    age: 39,
    location: 'Tenali (తెనాలి)',
    district: 'Guntur',
    state: 'Andhra Pradesh',
    preferredLanguage: 'te',
    landArea: '4.5 Acres',
    soilType: 'Red Loamy Fertile Soil (ఎర్ర నేల)',
    irrigationMethod: 'Krishna Canal & Drip System (కాలువ & డ్రిప్)',
    cropName: 'Red Chilli - Teja (తేజ మిర్చి)',
    cropGrowthStage: 'Pod Setting & Flowering (కాత దశ - 75 Days)',
    sowingDate: '2026-08-01',
    phone: '9440122344',
    pin: '1234'
  },
  {
    id: 'farmer_balram_03',
    name: 'Balram Patel (बलराम पटेल)',
    age: 48,
    location: 'Sanwer (सांवेर)',
    district: 'Indore',
    state: 'Madhya Pradesh',
    preferredLanguage: 'hi',
    landArea: '5.0 Acres',
    soilType: 'Heavy Black Clayey Soil (काली मिट्टी)',
    irrigationMethod: 'Tube well with Sprinklers (ट्यूबवेल व स्प्रिंकलर)',
    cropName: 'Soybean & Wheat (सोयाबीन व गेहूं)',
    cropGrowthStage: 'Pod Filling & Maturity (दाने भराव अवस्था)',
    sowingDate: '2026-06-25',
    phone: '9826055432',
    pin: '1234'
  },
  {
    id: 'farmer_suresh_04',
    name: 'Suresh Gowda (ಸುರೇಶ್ ಗೌಡ)',
    age: 42,
    location: 'Maddur (ಮದ್ದೂರು)',
    district: 'Mandya',
    state: 'Karnataka',
    preferredLanguage: 'kn',
    landArea: '2.5 Acres',
    soilType: 'Clay Loam (ಜೇಡಿ ಮಣ್ಣು)',
    irrigationMethod: 'Canal Irrigation (ಕಾಲುವೆ ನೀರಾವರಿ)',
    cropName: 'Paddy / Rice (ಭತ್ತ - ಸೋನಾ ಮಸೂರಿ)',
    cropGrowthStage: 'Tillering & Panicle Initiation (ತೆನೆ ಒಡೆಯುವ ಹಂತ)',
    sowingDate: '2026-07-20',
    phone: '9845077890',
    pin: '1234'
  }
];

const defaultTasks: FarmTask[] = [
  {
    id: 'task_01',
    title: 'Install Pheromone Traps for Pink Bollworm',
    titleLocal: {
      te: 'గులాబీ రంగు కాయతొలుచు పురుగు నివారణకు లింగాకర్షక బుట్టలు (Pheromone Traps) అమర్చండి',
      hi: 'गुलाबी सुंडी की निगरानी हेतु फेरोमोन ट्रैप लगाएं'
    },
    crop: 'Cotton',
    category: 'Scouting',
    dueDate: '2026-11-12',
    completed: false,
    priority: 'High',
    notes: 'Place 5 traps per acre at crop canopy height to monitor moth population.'
  },
  {
    id: 'task_02',
    title: 'Foliar Spray: 19:19:19 NPK + Boron',
    titleLocal: {
      te: 'పూత రాలడం నివారణకు 19:19:19 (5 గ్రా/లీ) మరియు బోరాన్ (1 గ్రా/లీ) పిచికారీ',
      hi: 'फूल झड़ने से रोकने के लिए 19:19:19 (5g/L) और बोरान (1g/L) का छिड़काव'
    },
    crop: 'Cotton',
    category: 'Fertilizer',
    dueDate: '2026-11-14',
    completed: false,
    priority: 'Medium',
    notes: 'Apply in morning or late afternoon to avoid direct hot midday sun.'
  },
  {
    id: 'task_03',
    title: 'Drip Irrigation Cycle (2 Hours)',
    titleLocal: {
      te: 'బిందు సేద్యం ద్వారా 2 గంటల పాటు నీటి తడి అందించండి',
      hi: 'ड्रिप सिंचाई के माध्यम से 2 घंटे पानी दें'
    },
    crop: 'Cotton',
    category: 'Irrigation',
    dueDate: '2026-11-11',
    completed: true,
    priority: 'High',
    notes: 'Maintain optimal root zone moisture during square formation.'
  },
  {
    id: 'task_04',
    title: 'Inter-row Weeding & Soil Aeration',
    titleLocal: {
      te: 'గుంటక / దంతె తో అంతర కృషి చేసి కలుపు నివారించండి',
      hi: 'कतारों के बीच निराई-गुड़ाई कर खरपतवार निकालें'
    },
    crop: 'Cotton',
    category: 'Weeding',
    dueDate: '2026-11-18',
    completed: false,
    priority: 'Low',
    notes: 'Improves root aeration and reduces weed competition.'
  }
];

const defaultAlerts: AgriAlert[] = [
  {
    id: 'alert_01',
    title: 'Pink Bollworm Advisory in Warangal Belt',
    message: 'Warangal & Jangaon agricultural officers report initial moth catches exceeding ETL (8 moths/trap/night). Check squares and install pheromone lures immediately.',
    type: 'pest',
    severity: 'urgent',
    timestamp: '2 hours ago',
    region: 'Warangal, Telangana'
  },
  {
    id: 'alert_02',
    title: 'Dry Spell Forecast (Next 5 Days)',
    message: 'Clear sunny weather with daytime highs of 31°C expected. Ideal window for fertilizer application and pest monitoring; ensure drip irrigation schedule.',
    type: 'weather',
    severity: 'info',
    timestamp: '5 hours ago',
    region: 'Northern Telangana'
  },
  {
    id: 'alert_03',
    title: 'Cotton Mandi Prices Up by ₹180/Quintal',
    message: 'Warangal Enumamula market recorded Medium Staple Cotton at ₹7,450/q due to increased mill procurement.',
    type: 'mandi',
    severity: 'warning',
    timestamp: 'Yesterday',
    region: 'Enumamula Market Yard'
  }
];

const defaultConsultations: CropDiagnosis[] = [
  {
    id: 'diag_init_01',
    timestamp: '2026-11-08T10:30:00Z',
    crop: 'Cotton (పత్తి)',
    diseaseName: 'Early Alternaria Leaf Spot (ఆల్టర్నేరియా ఆకుమచ్చ తెగులు)',
    confidence: 89,
    severity: 'Moderate',
    symptoms: [
      'Circular brown necrotic spots on lower canopy leaves',
      'Concentric target-board rings visible under sunlight',
      'Partial yellow halo surrounding older leaf lesions'
    ],
    causes: [
      'High intermittent humidity after recent rains',
      'Dense vegetative canopy limiting airflow in lower leaves',
      'Fungal spores (Alternaria macrospora) thriving in 26-28°C temperature'
    ],
    safeNextSteps: [
      'Avoid overhead wetting of foliage; maintain furrow/drip irrigation',
      'Remove heavily spotted lower leaves and safely compost away from fields',
      'Consult local Krishi Vigyan Kendra (KVK Warangal: 08712-245600) for approved bio-fungicide like Trichoderma or copper oxychloride if spots spread to upper nodes'
    ],
    prevention: [
      'Maintain 90x60 cm plant spacing for optimal aeration',
      'Balance nitrogen fertilizer to avoid overly lush succulent leaves',
      'Rotate crops next season with pulse crops like red gram or green gram'
    ],
    notes: 'Farmer Ramesh reported leaf spots after 3 days of cloudy humid weather.',
    language: 'te',
    source: 'Crop Doctor',
    status: 'Under Observation'
  },
  {
    id: 'diag_init_02',
    timestamp: '2026-11-05T15:15:00Z',
    crop: 'Chilli (మిర్చి - Intercrop border)',
    diseaseName: 'Thrips Infestation / Leaf Curl (తామర పురుగు / ముడత తెగులు)',
    confidence: 93,
    severity: 'Mild',
    symptoms: [
      'Upward curling of young tender leaves like boat-shape',
      'Silvery or bronzed patches on the leaf underside'
    ],
    causes: [
      'Warm dry days encouraging Western Flower Thrips / Scirtothrips dorsalis reproduction'
    ],
    safeNextSteps: [
      'Install blue sticky traps (20 per acre) at plant height',
      'Spray Neem oil (Azadirachtin 10,000 ppm @ 2ml per litre) in the cool evening'
    ],
    prevention: [
      'Maintain border rows of maize or sorghum to act as natural pest barrier'
    ],
    language: 'te',
    source: 'Voice Assistant',
    status: 'Resolved'
  }
];

const defaultChatHistory: ChatMessage[] = [
  {
    id: 'chat_init_01',
    role: 'user',
    content: 'నా పత్తి పంట ఆకులపై మచ్చలు వస్తున్నాయి. ఏం చేయాలి?',
    language: 'te',
    timestamp: '2026-11-09T09:12:00Z'
  },
  {
    id: 'chat_init_02',
    role: 'assistant',
    content: 'నమస్కారం రమేష్ గారు! మీ పత్తి పంట ప్రస్తుతం పూత, పిందె దశలో ఉంది. ఆకులపై మచ్చలు కనిపించడానికి ఆల్టర్నేరియా (Alternaria) ఫంగల్ ఆకుమచ్చ లేదా వర్షం తర్వాత వచ్చే బాక్టీరియల్ బ్లైట్ కారణం కావచ్చు.\n\nమీరు చేయవలసిన ముఖ్యమైన పనులు:\n1. ఆకుపై ఉన్న మచ్చల ఫోటోను మన AI Crop Doctor లో అప్‌లోడ్ చేయండి, మేము ఖచ్చితమైన విశ్లేషణ ఇస్తాము.\n2. నేలపై తేమ ఎక్కువగా ఉంటే నీరు నిల్వ ఉండకుండా చూసుకోండి.\n3. ప్రాథమికంగా వేప నూనె (5ml/లీ) పిచికారీ చేయడం వల్ల ప్రారంభ వ్యాప్తి తగ్గుతుంది.\n\nమచ్చల రంగు గోధుమ రంగులో ఉందా లేక నల్లగా ఉందా?',
    language: 'te',
    timestamp: '2026-11-09T09:12:06Z',
    cropDetected: 'Cotton (పత్తి)',
    recommendedAction: 'Upload leaf photo to AI Crop Doctor for confirmation',
    followUpQuestion: 'మచ్చల చుట్టూ పసుపు రంగు వలయం ఉందా?',
    suggestedQuestions: [
      'గులాబీ రంగు పురుగు నివారణ ఎలా?',
      'పూత రాలకుండా ఎలాంటి ఎరువు వేయాలి?',
      'నేటి వరంగల్ మార్కెట్ లో పత్తి ధర ఎంత?'
    ]
  }
];

const generate30DayTrend = (basePrice: number) => {
  const points = [];
  const today = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
    const fluctuation = Math.sin(i * 0.4) * (basePrice * 0.04) + (Math.random() - 0.48) * (basePrice * 0.02);
    const price = Math.round(basePrice + fluctuation);
    const volume = Math.round(300 + Math.random() * 250);
    points.push({ date: dateStr, price, volume });
  }
  return points;
};

const defaultMandiRecords: MandiRecord[] = [
  {
    id: 'mandi_01',
    commodity: 'Cotton (Kapas / పత్తి)',
    variety: 'Medium / Long Staple (H-4 / BT)',
    state: 'Telangana',
    district: 'Warangal',
    market: 'Enumamula Market Yard, Warangal',
    minPrice: 7100,
    maxPrice: 7650,
    modalPrice: 7450,
    trend: 'up',
    changePercent: 2.4,
    arrivalQuantity: '4,850 Quintals',
    date: 'Today, 10:30 AM',
    history30d: generate30DayTrend(7350)
  },
  {
    id: 'mandi_02',
    commodity: 'Cotton (Kapas)',
    variety: 'Bunny / Brahma',
    state: 'Telangana',
    district: 'Adilabad',
    market: 'Adilabad APMC',
    minPrice: 6950,
    maxPrice: 7420,
    modalPrice: 7280,
    trend: 'stable',
    changePercent: 0.2,
    arrivalQuantity: '3,200 Quintals',
    date: 'Today, 11:00 AM',
    history30d: generate30DayTrend(7250)
  },
  {
    id: 'mandi_03',
    commodity: 'Red Chilli (ఎర్ర మిర్చి)',
    variety: 'Teja / Deluxe',
    state: 'Telangana',
    district: 'Khammam',
    market: 'Khammam Mirchi Yard',
    minPrice: 18200,
    maxPrice: 22400,
    modalPrice: 20600,
    trend: 'up',
    changePercent: 4.1,
    arrivalQuantity: '2,100 Quintals',
    date: 'Today, 09:45 AM',
    history30d: generate30DayTrend(19800)
  },
  {
    id: 'mandi_04',
    commodity: 'Paddy (వరి - ధాన్యం)',
    variety: 'BPT 5204 (Samba Mahsuri)',
    state: 'Telangana',
    district: 'Nalgonda',
    market: 'Miryalaguda Mandi',
    minPrice: 2280,
    maxPrice: 2450,
    modalPrice: 2360,
    trend: 'stable',
    changePercent: -0.4,
    arrivalQuantity: '8,400 Quintals',
    date: 'Today, 10:15 AM',
    history30d: generate30DayTrend(2350)
  },
  {
    id: 'mandi_05',
    commodity: 'Maize (మొక్కజొన్న)',
    variety: 'Hybrid Yellow',
    state: 'Telangana',
    district: 'Nizamabad',
    market: 'Nizamabad APMC',
    minPrice: 2150,
    maxPrice: 2320,
    modalPrice: 2240,
    trend: 'down',
    changePercent: -1.2,
    arrivalQuantity: '1,950 Quintals',
    date: 'Today, 11:15 AM',
    history30d: generate30DayTrend(2270)
  },
  {
    id: 'mandi_06',
    commodity: 'Soybean (సోయాబీన్)',
    variety: 'Yellow JS 335',
    state: 'Maharashtra',
    district: 'Latur',
    market: 'Latur APMC',
    minPrice: 4300,
    maxPrice: 4750,
    modalPrice: 4580,
    trend: 'up',
    changePercent: 1.8,
    arrivalQuantity: '5,600 Quintals',
    date: 'Today, 10:00 AM',
    history30d: generate30DayTrend(4500)
  },
  {
    id: 'mandi_07',
    commodity: 'Turmeric (పసుపు)',
    variety: 'Finger / Nizamabad Special',
    state: 'Telangana',
    district: 'Nizamabad',
    market: 'Nizamabad Turmeric Market',
    minPrice: 12400,
    maxPrice: 15800,
    modalPrice: 14200,
    trend: 'up',
    changePercent: 3.5,
    arrivalQuantity: '1,450 Quintals',
    date: 'Today, 10:30 AM',
    history30d: generate30DayTrend(13800)
  }
];

const defaultSchemes: GovernmentScheme[] = [
  {
    id: 'pm-kisan',
    name: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
    shortName: 'PM-KISAN',
    category: 'Direct Income',
    amount: '₹6,000 / year (in 3 equal installments of ₹2,000)',
    overview: 'Central sector scheme that provides assured supplementary financial income support to all landholding farmer families across India directly into their Aadhaar-linked bank accounts.',
    eligibility: [
      'Small and marginal landholder farmer families with cultivable landholding',
      'Land records must be updated in state land registry (Pahani / 1B)',
      'Institutional landholders and income tax-paying individuals are excluded',
      'Active bank account linked with Aadhaar and e-KYC completed'
    ],
    documents: [
      'Aadhaar Card with linked active mobile number',
      'Landholding Pattadar Passbook / RoR-1B records',
      'Bank passbook photocopy showing IFSC and Account Number',
      'Self-declaration certificate of non-taxpayer status'
    ],
    procedure: [
      'Visit the official PM-KISAN portal (pmkisan.gov.in) or your local MeeSeva / CSC center',
      'Click on "Farmers Corner" -> "New Farmer Registration"',
      'Enter Aadhaar number, state, district, and mobile number to verify via OTP',
      'Upload survey number and sub-division details from land passbook',
      'Complete biometric or OTP-based e-KYC to activate DBT installment dispatch'
    ],
    officialLink: 'https://pmkisan.gov.in',
    helpline: '155261 / 011-24300606',
    tags: ['National', 'Direct Benefit Transfer', 'Central Scheme']
  },
  {
    id: 'kcc',
    name: 'Kisan Credit Card (KCC) Low-Interest Crop Loan',
    shortName: 'Kisan Credit Card',
    category: 'Credit',
    amount: 'Up to ₹3,00,000 at concessional 4% effective interest rate',
    overview: 'Comprehensive credit support for Indian farmers to purchase seeds, fertilizers, pesticides, pay labor charges, and meet post-harvest working capital needs without high-interest private moneylenders.',
    eligibility: [
      'All individual/joint owner farmers with agricultural land',
      'Tenant farmers, oral lessees, and sharecroppers with cultivation proof',
      'Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers'
    ],
    documents: [
      'Duly filled KCC application form',
      'Identity & Address proof (Aadhaar / Voter ID)',
      'Land title documents (Passbook / 1B / Pahani copies verified by VRO)',
      'Cropping pattern certificate of current season'
    ],
    procedure: [
      'Approach nearest commercial bank, regional rural bank (RRB), or PACS cooperative',
      'Submit the single-page simplified KCC form with land records',
      'Bank evaluates scale of finance for Cotton (approx ₹38,000 to ₹45,000 per acre)',
      'Card issued within 14 days with revolving credit validity for 5 years'
    ],
    officialLink: 'https://www.myscheme.gov.in/schemes/kcc',
    helpline: '1800-11-5526 (Toll-Free)',
    tags: ['Credit', 'Crop Loan', 'Low Interest']
  },
  {
    id: 'pmfby',
    name: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)',
    shortName: 'PM Fasal Bima (Crop Insurance)',
    category: 'Insurance',
    amount: 'Full sum insured coverage for non-preventable natural risks',
    overview: 'Comprehensive risk insurance coverage from pre-sowing to post-harvest against natural calamities, droughts, floods, pest epidemics, and unseasonal rainfall at nominal farmer premium rates.',
    eligibility: [
      'All farmers cultivating notified crops (like Cotton, Paddy, Chilli) in notified areas',
      'Both loanee farmers (via KCC) and non-loanee farmers eligible',
      'Crop cut experiments (CCE) or satellite yield deficit triggers indemnity'
    ],
    documents: [
      'Sowing Certificate / VRO Adangal record',
      'Aadhaar card copy',
      'Bank passbook details',
      'Land ownership documents or tenant lease agreement'
    ],
    procedure: [
      'Apply online via pmfby.gov.in portal or via bank branch / Common Service Centre (CSC)',
      'Pay nominal premium: only 2% for Kharif foodgrains/oilseeds, 5% for commercial/horticultural crops like Cotton/Chilli',
      'In case of localized calamity (hailstorm, cloudburst), report within 72 hours through Crop Insurance App'
    ],
    officialLink: 'https://pmfby.gov.in',
    helpline: '1800-180-1551',
    tags: ['Insurance', 'Disaster Relief', 'Calamity Protection']
  },
  {
    id: 'rythu-bharosa',
    name: 'Rythu Bharosa / Rythu Bandhu Agricultural Investment Support',
    shortName: 'Rythu Bharosa / Rythu Bandhu',
    category: 'State Benefit',
    amount: '₹15,000 per acre per year (₹7,500 per Kharif & Rabi season)',
    overview: 'State financial assistance scheme providing direct per-acre investment aid directly to farmers prior to agricultural seasons to purchase inputs and avoid debt cycles.',
    eligibility: [
      'Resident farmers possessing Pattadar Passbooks issued by Government of Telangana / Andhra Pradesh',
      'Cultivable land registered under Dharani / Webland portal',
      'Includes tenant farmers registered under designated verification protocols'
    ],
    documents: [
      'Dharani digital passbook / Pattadar passbook number',
      'Aadhaar Card linked bank account',
      'Voter ID / Domicile proof'
    ],
    procedure: [
      'Automatic seeding through Agriculture Extension Officer (AEO) field verification',
      'Check status in Dharani portal under Rythu Bandhu / Bharosa status module',
      'Direct treasury transfer to linked savings account before sowing season'
    ],
    officialLink: 'https://dharani.telangana.gov.in',
    helpline: '040-2338-3520',
    tags: ['Telangana', 'Andhra Pradesh', 'Per-Acre Support']
  },
  {
    id: 'pm-kusum',
    name: 'PM-KUSUM Solar Agriculture Pump Scheme',
    shortName: 'PM-KUSUM Solar Pump',
    category: 'Subsidies',
    amount: 'Up to 60% government subsidy on Solar Irrigation Pumps (3HP to 7.5HP)',
    overview: 'Subsidized off-grid and grid-connected solar pumps providing energy security to farmers, replacing expensive diesel pump sets and erratic night-time grid power.',
    eligibility: [
      'Farmers with borewell or open well source requiring pump energization',
      'Individual farmers, Water User Associations, and Farmer Producer Organizations (FPOs)'
    ],
    documents: [
      'Electricity DISCOM certificate of un-electrified borewell (if applicable)',
      'Land records and water source certificate',
      'Aadhaar and bank proof'
    ],
    procedure: [
      'Register on state renewable energy development agency portal (TSREDCO / NREDCAP)',
      'Pay farmer contribution (10% to 40% depending on pump capacity)',
      'Authorized vendor installs solar panels, motor, and controller with 5-year warranty'
    ],
    officialLink: 'https://pmkusum.mnre.gov.in',
    helpline: '1800-180-3333',
    tags: ['Solar Power', 'Irrigation Subsidy', 'Eco Friendly']
  }
];

export class StorageManager {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadDatabase();
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        if (!parsed.profiles || parsed.profiles.length === 0) {
          parsed.profiles = defaultProfiles;
        }
        return parsed;
      }
    } catch (err) {
      console.warn('Failed to read existing database file, initializing defaults:', err);
    }

    const initialData: DatabaseSchema = {
      profile: defaultProfile,
      profiles: defaultProfiles,
      tasks: defaultTasks,
      alerts: defaultAlerts,
      consultations: defaultConsultations,
      chatHistory: defaultChatHistory,
      mandiRecords: defaultMandiRecords,
      schemes: defaultSchemes
    };

    this.saveDatabase(initialData);
    return initialData;
  }

  private saveDatabase(data: DatabaseSchema) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  public getProfiles(): FarmerProfile[] {
    return this.data.profiles || defaultProfiles;
  }

  public switchProfile(id: string): FarmerProfile | null {
    const list = this.data.profiles || defaultProfiles;
    const found = list.find(p => p.id === id);
    if (!found) return null;
    this.data.profile = found;
    this.saveDatabase(this.data);
    return found;
  }

  public loginFarmer(phone: string, pin?: string): { success: boolean; profile?: FarmerProfile; error?: string } {
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    const list = this.data.profiles || defaultProfiles;
    const found = list.find(p => {
      const pClean = (p.phone || '').replace(/\D/g, '').slice(-10);
      return pClean === cleanPhone;
    });

    if (!found) {
      return { success: false, error: 'Mobile number not registered. Please sign up or select a demo profile.' };
    }

    if (pin && found.pin && found.pin !== pin && pin !== '1234') {
      return { success: false, error: 'Incorrect 4-digit PIN. (Demo PIN: 1234)' };
    }

    this.data.profile = found;
    this.saveDatabase(this.data);
    return { success: true, profile: found };
  }

  public registerFarmer(farmerData: Omit<FarmerProfile, 'id'>): FarmerProfile {
    const newFarmer: FarmerProfile = {
      ...farmerData,
      id: 'farmer_' + Date.now(),
      phone: farmerData.phone?.replace(/\D/g, '').slice(-10) || '9800000000',
      pin: farmerData.pin || '1234'
    };

    if (!this.data.profiles) {
      this.data.profiles = [...defaultProfiles];
    }
    this.data.profiles.push(newFarmer);
    this.data.profile = newFarmer;
    this.saveDatabase(this.data);
    return newFarmer;
  }

  public getProfile(): FarmerProfile {
    return this.data.profile;
  }

  public updateProfile(updated: Partial<FarmerProfile>): FarmerProfile {
    this.data.profile = {
      ...this.data.profile,
      ...updated,
      id: this.data.profile.id
    };
    if (this.data.profiles) {
      const idx = this.data.profiles.findIndex(p => p.id === this.data.profile.id);
      if (idx !== -1) {
        this.data.profiles[idx] = { ...this.data.profiles[idx], ...updated };
      }
    }
    this.saveDatabase(this.data);
    return this.data.profile;
  }

  public getTasks(): FarmTask[] {
    return this.data.tasks;
  }

  public addTask(task: Omit<FarmTask, 'id'>): FarmTask {
    const newTask: FarmTask = {
      ...task,
      id: 'task_' + Date.now()
    };
    this.data.tasks.unshift(newTask);
    this.saveDatabase(this.data);
    return newTask;
  }

  public updateTask(id: string, updates: Partial<FarmTask>): FarmTask | null {
    const idx = this.data.tasks.findIndex(t => t.id === id);
    if (idx === -1) return null;
    this.data.tasks[idx] = { ...this.data.tasks[idx], ...updates };
    this.saveDatabase(this.data);
    return this.data.tasks[idx];
  }

  public deleteTask(id: string): boolean {
    const before = this.data.tasks.length;
    this.data.tasks = this.data.tasks.filter(t => t.id !== id);
    if (this.data.tasks.length !== before) {
      this.saveDatabase(this.data);
      return true;
    }
    return false;
  }

  public getAlerts(): AgriAlert[] {
    return this.data.alerts;
  }

  public getConsultations(): CropDiagnosis[] {
    return this.data.consultations;
  }

  public addConsultation(consultation: Omit<CropDiagnosis, 'id' | 'timestamp'>): CropDiagnosis {
    const newConsultation: CropDiagnosis = {
      ...consultation,
      id: 'diag_' + Date.now(),
      timestamp: new Date().toISOString()
    };
    this.data.consultations.unshift(newConsultation);
    this.saveDatabase(this.data);
    return newConsultation;
  }

  public deleteConsultation(id: string): boolean {
    const before = this.data.consultations.length;
    this.data.consultations = this.data.consultations.filter(c => c.id !== id);
    if (this.data.consultations.length !== before) {
      this.saveDatabase(this.data);
      return true;
    }
    return false;
  }

  public getChatHistory(): ChatMessage[] {
    return this.data.chatHistory;
  }

  public addChatMessage(message: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage {
    const newMessage: ChatMessage = {
      ...message,
      id: 'chat_' + Date.now(),
      timestamp: new Date().toISOString()
    };
    this.data.chatHistory.push(newMessage);
    // Keep max 50 chat messages
    if (this.data.chatHistory.length > 50) {
      this.data.chatHistory = this.data.chatHistory.slice(-50);
    }
    this.saveDatabase(this.data);
    return newMessage;
  }

  public clearChatHistory(): void {
    this.data.chatHistory = [];
    this.saveDatabase(this.data);
  }

  public getMandiRecords(): MandiRecord[] {
    return this.data.mandiRecords;
  }

  public getSchemes(): GovernmentScheme[] {
    return this.data.schemes;
  }
}

export const storage = new StorageManager();
