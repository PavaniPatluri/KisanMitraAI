import { FarmerProfile, CropDiagnosis, WeatherData, FarmRiskAssessment } from '../types/index.ts';

export function calculateFarmRisk(
  profile: FarmerProfile,
  weather: WeatherData,
  consultations: CropDiagnosis[]
): FarmRiskAssessment {
  const factors: FarmRiskAssessment['factors'] = [];
  let riskScore = 20; // baseline healthy score

  // 1. Weather Risk Evaluation
  if (weather.rainfallChance > 45) {
    riskScore += 25;
    factors.push({
      category: 'Weather',
      level: 'Medium',
      title: 'Elevated Rainfall & Washout Risk',
      description: `Rain probability is ${weather.rainfallChance}%. Excess moisture on black soil can cause temporary water stagnation and fungal spore proliferation.`,
      recommendation: 'Check that furrow drainage outlets are unobstructed. Avoid spraying foliar nutrients within 4 hours of expected rainfall.'
    });
  } else if (weather.temperature > 35) {
    riskScore += 20;
    factors.push({
      category: 'Weather',
      level: 'Medium',
      title: 'High Thermal Evaporation',
      description: `Current temperature is ${weather.temperature}°C with relative humidity at ${weather.humidity}%. High daytime heat can trigger square and flower bud drop in cotton.`,
      recommendation: 'Operate drip irrigation during early morning (6:00 AM - 8:30 AM) to maintain steady root-zone moisture.'
    });
  } else {
    factors.push({
      category: 'Weather',
      level: 'Low',
      title: 'Favorable Agro-Climatic Window',
      description: `Calm wind (${weather.windSpeed} km/h) and moderate temperature (${weather.temperature}°C) support active photosynthesis and boll development.`,
      recommendation: 'Optimal period for scheduled foliar feeding and routine pest scouting.'
    });
  }

  // 2. Pest & Disease Risk from Symptoms and Consultations
  const activeConsultations = consultations.filter(c => c.status === 'Active' || c.status === 'Under Observation');
  const hasSevere = activeConsultations.some(c => c.severity === 'Severe');
  const hasModerate = activeConsultations.some(c => c.severity === 'Moderate');

  if (hasSevere) {
    riskScore += 35;
    factors.push({
      category: 'Pest & Disease',
      level: 'High',
      title: 'Active Disease Flare-up Detected',
      description: 'Recent diagnosis flagged severe fungal or insect stress requiring immediate localized cultural and biological response.',
      recommendation: 'Isolate affected rows immediately. Contact Mandal Agricultural Extension Officer (AEO) or Warangal KVK.'
    });
  } else if (hasModerate || activeConsultations.length > 0) {
    riskScore += 20;
    factors.push({
      category: 'Pest & Disease',
      level: 'Medium',
      title: 'Moderate Pest / Leaf Spot Pressure',
      description: 'Alternaria leaf spot or sucking pest symptoms reported during recent inspection in flowering cotton crop.',
      recommendation: 'Deploy 5 pheromone traps per acre for pink bollworm and spray organic Neem formulation (10,000 ppm) in the late afternoon.'
    });
  } else {
    factors.push({
      category: 'Pest & Disease',
      level: 'Low',
      title: 'Pest Population Below Economic Threshold (ETL)',
      description: 'No critical pest outbreaks reported in your immediate 3-acre parcel.',
      recommendation: 'Continue twice-weekly visual checks of 20 random plants for rosette flowers and leaf underside nymphs.'
    });
  }

  // 3. Soil Moisture & Growth Stage Vulnerability
  if (profile.cropGrowthStage.toLowerCase().includes('flower') || profile.cropGrowthStage.toLowerCase().includes('boll')) {
    riskScore += 10;
    factors.push({
      category: 'Soil Moisture',
      level: 'Medium',
      title: 'Critical Growth Stage: Flowering & Boll Set',
      description: 'Cotton is highly sensitive to both water deficit and waterlogging during 60-90 days after sowing. Black soil holds high water content.',
      recommendation: 'Regulate drip run times to 2 hours every 3-4 days; avoid deep flooding that suffocates cotton taproots.'
    });
  } else {
    factors.push({
      category: 'Soil Moisture',
      level: 'Low',
      title: 'Stable Soil Moisture Profile',
      description: `Deep black soil combined with ${profile.irrigationMethod} provides resilient buffer against brief dry spells.`,
      recommendation: 'Perform inter-cultivation (దంతె) to break capillary surface cracks and conserve subsurface moisture.'
    });
  }

  // 4. Market Price Volatility Risk
  factors.push({
    category: 'Market Price',
    level: 'Low',
    title: 'Firm Market Demand in Regional Mandis',
    description: 'Cotton prices in Warangal Enumamula market are holding steady at ₹7,450/q, above MSP benchmark of ₹7,121/q.',
    recommendation: 'Ensure picking clean cotton without leaf trash and store with moisture below 8% to command top modal rate.'
  });

  const finalScore = Math.min(100, Math.max(0, riskScore));
  let overallRisk: 'Low' | 'Medium' | 'High' = 'Low';
  if (finalScore >= 65) overallRisk = 'High';
  else if (finalScore >= 35) overallRisk = 'Medium';

  const summary = overallRisk === 'High'
    ? 'High caution advised. Immediate action needed regarding active disease signs and weather shifts.'
    : overallRisk === 'Medium'
    ? 'Moderate risk profile. Crop is in critical flowering phase; maintain tight monitoring on pink bollworm and regulated drip irrigation.'
    : 'Low farm risk. Your crop health and current micro-climate are in favorable equilibrium.';

  return {
    overallRisk,
    score: finalScore,
    factors,
    summary
  };
}
