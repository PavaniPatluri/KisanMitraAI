import {
  FarmerProfile,
  FarmTask,
  AgriAlert,
  CropDiagnosis,
  MandiRecord,
  GovernmentScheme,
  WeatherData,
  FarmRiskAssessment,
  ChatMessage,
  LanguageCode
} from '../types/index.ts';

export const api = {
  async getStatus() {
    const res = await fetch('/api/status');
    return res.json();
  },

  async pushToGitHub(token: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const res = await fetch('/api/github/push', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token })
    });
    return res.json();
  },

  async getAuthProfiles(): Promise<FarmerProfile[]> {
    const res = await fetch('/api/auth/profiles');
    return res.json();
  },

  async login(phone: string, pin?: string): Promise<{ success: boolean; profile?: FarmerProfile; error?: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, pin })
    });
    return res.json();
  },

  async switchProfile(id: string): Promise<{ success: boolean; profile?: FarmerProfile; error?: string }> {
    const res = await fetch('/api/auth/switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    return res.json();
  },

  async register(data: any): Promise<{ success: boolean; profile?: FarmerProfile; error?: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async getProfile(): Promise<FarmerProfile> {
    const res = await fetch('/api/profile');
    return res.json();
  },

  async updateProfile(profile: Partial<FarmerProfile>): Promise<FarmerProfile> {
    const res = await fetch('/api/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    });
    return res.json();
  },

  async getTasks(): Promise<FarmTask[]> {
    const res = await fetch('/api/tasks');
    return res.json();
  },

  async addTask(task: Omit<FarmTask, 'id'>): Promise<FarmTask> {
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task)
    });
    return res.json();
  },

  async updateTask(id: string, updates: Partial<FarmTask>): Promise<FarmTask> {
    const res = await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    return res.json();
  },

  async deleteTask(id: string): Promise<boolean> {
    const res = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
    const data = await res.json();
    return data.success;
  },

  async getAlerts(): Promise<AgriAlert[]> {
    const res = await fetch('/api/alerts');
    return res.json();
  },

  async getConsultations(): Promise<CropDiagnosis[]> {
    const res = await fetch('/api/consultations');
    return res.json();
  },

  async addConsultation(consultation: Omit<CropDiagnosis, 'id' | 'timestamp'>): Promise<CropDiagnosis> {
    const res = await fetch('/api/consultations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(consultation)
    });
    return res.json();
  },

  async deleteConsultation(id: string): Promise<boolean> {
    const res = await fetch(`/api/consultations/${id}`, { method: 'DELETE' });
    const data = await res.json();
    return data.success;
  },

  async getChatHistory(): Promise<ChatMessage[]> {
    const res = await fetch('/api/chats');
    return res.json();
  },

  async clearChatHistory(): Promise<boolean> {
    const res = await fetch('/api/chats/clear', { method: 'POST' });
    const data = await res.json();
    return data.success;
  },

  async sendVoiceChat(message: string, language: LanguageCode): Promise<ChatMessage> {
    const res = await fetch('/api/voice/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, language })
    });
    if (!res.ok) {
      throw new Error('Failed to get AI response');
    }
    return res.json();
  },

  async diagnoseCrop(params: {
    imageBase64?: string;
    mimeType?: string;
    cropType: string;
    symptoms: string;
    language: LanguageCode;
  }) {
    const res = await fetch('/api/crop-doctor/diagnose', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Crop diagnosis failed');
    }
    return res.json();
  },

  async getWeather(district: string = 'warangal'): Promise<WeatherData> {
    const res = await fetch(`/api/weather?district=${encodeURIComponent(district)}`);
    return res.json();
  },

  async getMandiPrices(params?: {
    commodity?: string;
    state?: string;
    district?: string;
    search?: string;
  }): Promise<MandiRecord[]> {
    const query = new URLSearchParams();
    if (params?.commodity) query.set('commodity', params.commodity);
    if (params?.state) query.set('state', params.state);
    if (params?.district) query.set('district', params.district);
    if (params?.search) query.set('search', params.search);

    const res = await fetch(`/api/mandi?${query.toString()}`);
    return res.json();
  },

  async getSchemes(params?: { category?: string; search?: string }): Promise<GovernmentScheme[]> {
    const query = new URLSearchParams();
    if (params?.category) query.set('category', params.category);
    if (params?.search) query.set('search', params.search);

    const res = await fetch(`/api/schemes?${query.toString()}`);
    return res.json();
  },

  async getRiskAssessment(): Promise<FarmRiskAssessment> {
    const res = await fetch('/api/risk-assessment');
    return res.json();
  }
};
