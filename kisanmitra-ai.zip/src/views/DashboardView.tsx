import React, { useState } from 'react';
import {
  Activity,
  Mic,
  CloudSun,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Plus,
  Clock,
  ArrowRight,
  ShieldCheck,
  Droplets,
  Sprout,
  ChevronRight,
  MapPin,
  ExternalLink,
  Sparkles,
  Info
} from 'lucide-react';
import {
  FarmerProfile,
  FarmTask,
  AgriAlert,
  CropDiagnosis,
  MandiRecord,
  WeatherData,
  LanguageCode
} from '../types/index.ts';

interface DashboardViewProps {
  profile: FarmerProfile;
  weather: WeatherData | null;
  tasks: FarmTask[];
  alerts: AgriAlert[];
  consultations: CropDiagnosis[];
  mandiRecords: MandiRecord[];
  onToggleTask: (taskId: string, currentCompleted: boolean) => void;
  onAddTask: (title: string, category: FarmTask['category'], priority: FarmTask['priority']) => void;
  onNavigate: (view: string) => void;
  selectedLanguage: LanguageCode;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  weather,
  tasks,
  alerts,
  consultations,
  mandiRecords,
  onToggleTask,
  onAddTask,
  onNavigate,
  selectedLanguage
}) => {
  const [newTaskModalOpen, setNewTaskModalOpen] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState<FarmTask['category']>('Scouting');
  const [newTaskPriority, setNewTaskPriority] = useState<FarmTask['priority']>('Medium');

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    onAddTask(newTaskTitle.trim(), newTaskCategory, newTaskPriority);
    setNewTaskTitle('');
    setNewTaskModalOpen(false);
  };

  const pendingTasks = tasks.filter(t => !t.completed);
  const completedTasks = tasks.filter(t => t.completed);

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner: Farmer Profile & Quick Actions */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-50 rounded-full blur-3xl -z-10 translate-x-32 -translate-y-32"></div>

        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
              <span>Verified Demo Farmer Profile</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              నమస్కారం, {profile.name}!
            </h1>
            <div className="flex flex-wrap items-center gap-3 text-xs text-gray-600 font-medium">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                {profile.location}, {profile.district}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Sprout className="w-3.5 h-3.5 text-emerald-700" />
                {profile.landArea} ({profile.cropName})
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Droplets className="w-3.5 h-3.5 text-emerald-700" />
                {profile.irrigationMethod}
              </span>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              onClick={() => onNavigate('crop-doctor')}
              className="px-4 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <Activity className="w-4 h-4 text-emerald-200" />
              <span>Diagnose Crop</span>
            </button>

            <button
              onClick={() => onNavigate('voice')}
              className="px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 text-emerald-900 font-bold text-xs border border-emerald-300 shadow-2xs transition flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <Mic className="w-4 h-4 text-emerald-700 animate-pulse" />
              <span>Ask AI Assistant</span>
            </button>

            <button
              onClick={() => onNavigate('weather')}
              className="px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 text-emerald-900 font-bold text-xs border border-emerald-300 shadow-2xs transition flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <CloudSun className="w-4 h-4 text-emerald-700" />
              <span>Check Weather</span>
            </button>

            <button
              onClick={() => onNavigate('mandi')}
              className="px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 text-emerald-900 font-bold text-xs border border-emerald-300 shadow-2xs transition flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <TrendingUp className="w-4 h-4 text-emerald-700" />
              <span>Mandi Prices</span>
            </button>
          </div>
        </div>
      </div>

      {/* 8 WIDGETS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* WIDGET 1: WEATHER OVERVIEW */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
                  <CloudSun className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Weather Overview</h3>
              </div>
              <span className="text-[11px] font-mono text-gray-400">Live • Open-Meteo</span>
            </div>

            {weather ? (
              <div className="space-y-4">
                <div className="flex items-baseline justify-between">
                  <div>
                    <span className="text-4xl font-extrabold text-gray-900">{weather.temperature}°C</span>
                    <p className="text-xs text-gray-500 font-medium">Feels like {weather.feelsLike}°C • {weather.condition}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-sky-50 text-sky-800 font-semibold border border-sky-200">
                      Rain: {weather.rainfallChance}%
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-gray-50 text-center text-xs">
                  <div>
                    <p className="text-gray-400 text-[10px]">Humidity</p>
                    <p className="font-bold text-gray-800">{weather.humidity}%</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-[10px]">Wind</p>
                    <p className="font-bold text-gray-800">{weather.windSpeed} km/h</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-[10px]">UV Index</p>
                    <p className="font-bold text-gray-800">{weather.uvIndex} / 10</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100 text-xs">
                  <p className="font-bold text-emerald-950 mb-0.5">🌾 Agricultural Spray Advisory:</p>
                  <p className="text-emerald-800 leading-snug">{weather.advisory}</p>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-gray-400">Loading weather data...</div>
            )}
          </div>

          <button
            onClick={() => onNavigate('weather')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center justify-between cursor-pointer"
          >
            <span>7-Day Detailed Forecast</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* WIDGET 2: MY CROPS */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Sprout className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">My Crops</h3>
              </div>
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full">
                Active Cycle
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-100 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-extrabold text-base text-gray-900">{profile.cropName}</h4>
                  <p className="text-xs text-emerald-800 font-medium">{profile.landArea} • {profile.soilType.split('(')[0]}</p>
                </div>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900">
                  Day 65
                </span>
              </div>

              {/* Progress bar for crop cycle */}
              <div>
                <div className="flex justify-between text-[11px] text-gray-500 mb-1 font-medium">
                  <span>Growth: {profile.cropGrowthStage.split('(')[0]}</span>
                  <span>55%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-emerald-200 overflow-hidden">
                  <div className="h-full bg-emerald-600 rounded-full" style={{ width: '55%' }}></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-600 pt-1">
                <div>
                  <span className="text-gray-400">Sown:</span> {profile.sowingDate || 'July 2026'}
                </div>
                <div>
                  <span className="text-gray-400">Harvest:</span> Dec 2026
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('profile')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center justify-between cursor-pointer"
          >
            <span>Edit Farm & Crop Profile</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* WIDGET 3: CROP HEALTH */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                  <Activity className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Crop Health Status</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-semibold">
                Needs Monitoring
              </span>
            </div>

            <div className="space-y-3">
              {consultations.slice(0, 2).map((diag) => (
                <div key={diag.id} className="p-3 rounded-xl bg-gray-50 border border-gray-100 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-gray-800 truncate max-w-[170px]">{diag.diseaseName}</span>
                    <span className={`px-1.5 py-0.5 rounded-sm font-semibold text-[10px] ${
                      diag.severity === 'Severe'
                        ? 'bg-rose-100 text-rose-800'
                        : diag.severity === 'Moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {diag.severity}
                    </span>
                  </div>
                  <p className="text-[11px] text-gray-500 line-clamp-1">{diag.symptoms[0]}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('crop-doctor')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center justify-between cursor-pointer"
          >
            <span>Launch AI Crop Doctor</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* WIDGET 4: AI RECOMMENDATIONS */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">AI Recommendations</h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                Cotton Stage 65d
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-100 space-y-1">
                <p className="font-bold text-emerald-950">1. Square & Boll Drop Prevention:</p>
                <p className="text-emerald-800 leading-snug">
                  Apply foliar spray of 19:19:19 (5g/L) + Boron (1g/L) during morning hours to nourish active squares.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-gray-50 border border-gray-100 space-y-1">
                <p className="font-bold text-gray-900">2. Pink Bollworm Scouting:</p>
                <p className="text-gray-600 leading-snug">
                  Inspect 20 green bolls across the 3 acres. Look for rosette flowers and entrance pinholes.
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('voice')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center justify-between cursor-pointer"
          >
            <span>Ask for Tailored Guidance</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* WIDGET 5: UPCOMING FARMING TASKS */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Calendar className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Farming Tasks</h3>
              </div>
              <button
                onClick={() => setNewTaskModalOpen(true)}
                className="p-1 rounded-lg hover:bg-emerald-50 text-emerald-700 text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {tasks.slice(0, 4).map((task) => (
                <div
                  key={task.id}
                  onClick={() => onToggleTask(task.id, task.completed)}
                  className={`p-2.5 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition ${
                    task.completed
                      ? 'bg-gray-50 border-gray-200 opacity-60'
                      : 'bg-white border-gray-200 hover:border-emerald-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className={`w-4 h-4 rounded-md flex items-center justify-center border ${
                      task.completed ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-gray-300'
                    }`}>
                      {task.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                    <span className={`font-semibold ${task.completed ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                      {task.title}
                    </span>
                  </div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-sm font-semibold ${
                    task.priority === 'High' ? 'bg-rose-50 text-rose-700' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {task.category}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
            <span>{pendingTasks.length} pending • {completedTasks.length} completed</span>
            <span className="text-[11px] text-emerald-700 font-semibold">Tap to toggle</span>
          </div>
        </div>

        {/* WIDGET 6: RECENT CONSULTATIONS */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center">
                  <Clock className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Recent Consultations</h3>
              </div>
              <span className="text-xs text-gray-400 font-medium">History Log</span>
            </div>

            <div className="space-y-2.5">
              {consultations.length > 0 ? (
                consultations.slice(0, 3).map((item) => (
                  <div key={item.id} className="p-3 rounded-xl bg-gray-50 border border-gray-100 text-xs">
                    <div className="flex items-center justify-between font-semibold text-gray-900">
                      <span>{item.crop}</span>
                      <span className="text-[10px] text-gray-400">
                        {new Date(item.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    <p className="text-emerald-800 font-medium text-[11px] mt-0.5 truncate">{item.diseaseName}</p>
                    <span className="text-[10px] text-gray-500 font-mono">Source: {item.source}</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-gray-400 py-4 text-center">No past consultations yet.</p>
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('crop-doctor')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center justify-between cursor-pointer"
          >
            <span>View Full Health Records</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* WIDGET 7: MARKET PRICE OVERVIEW */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Market Price Overview</h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                Warangal Mandi
              </span>
            </div>

            <div className="space-y-2.5">
              {mandiRecords.slice(0, 3).map((rec) => (
                <div key={rec.id} className="p-3 rounded-xl bg-gray-50 border border-gray-100 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-bold text-gray-900">{rec.commodity.split('(')[0]}</p>
                    <p className="text-[10px] text-gray-500">{rec.market.split(',')[0]}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-extrabold text-sm text-gray-900">₹{rec.modalPrice.toLocaleString()}<span className="text-[10px] text-gray-400">/q</span></p>
                    <span className={`text-[10px] font-bold ${rec.trend === 'up' ? 'text-emerald-600' : 'text-gray-500'}`}>
                      {rec.trend === 'up' ? `+${rec.changePercent}%` : `${rec.changePercent}%`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('mandi')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center justify-between cursor-pointer"
          >
            <span>Compare Regional Mandis</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* WIDGET 8: AGRICULTURAL ALERTS */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Agricultural Alerts</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-semibold">
                {alerts.length} Active
              </span>
            </div>

            <div className="space-y-3">
              {alerts.slice(0, 2).map((alert) => (
                <div key={alert.id} className="p-3 rounded-xl bg-rose-50/70 border border-rose-100 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-rose-950">{alert.title}</span>
                    <span className="text-[10px] text-rose-600 font-medium">{alert.timestamp}</span>
                  </div>
                  <p className="text-[11px] text-rose-800 leading-snug">{alert.message}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('risk')}
            className="mt-4 pt-3 border-t border-gray-100 text-xs font-bold text-rose-700 hover:text-rose-800 flex items-center justify-between cursor-pointer"
          >
            <span>View Full Risk Assessment</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ADD TASK MODAL */}
      {newTaskModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Add Farm Task</h3>
            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Task Title / Action</label>
                <input
                  type="text"
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="e.g. Apply 19:19:19 spray, Check pheromone lures..."
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Category</label>
                  <select
                    value={newTaskCategory}
                    onChange={(e) => setNewTaskCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  >
                    <option value="Scouting">Scouting</option>
                    <option value="Fertilizer">Fertilizer</option>
                    <option value="Irrigation">Irrigation</option>
                    <option value="Pesticide">Pesticide</option>
                    <option value="Weeding">Weeding</option>
                    <option value="Harvest">Harvest</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Priority</label>
                  <select
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  >
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setNewTaskModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-gray-600 hover:bg-gray-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-emerald-700 text-white hover:bg-emerald-800 cursor-pointer"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
