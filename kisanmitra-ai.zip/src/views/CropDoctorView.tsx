import React, { useState, useRef } from 'react';
import {
  Upload,
  Camera,
  Activity,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  ShieldCheck,
  RefreshCw,
  BookmarkCheck,
  Sparkles,
  Info,
  ChevronRight,
  Leaf
} from 'lucide-react';
import { CropDiagnosis, LanguageCode, FarmerProfile } from '../types/index.ts';
import { SAMPLE_CROP_IMAGES, SampleImageItem } from '../utils/sampleImages.ts';

interface CropDoctorViewProps {
  onDiagnose: (params: {
    imageBase64?: string;
    mimeType?: string;
    cropType: string;
    symptoms: string;
    language: LanguageCode;
  }) => Promise<any>;
  onSaveConsultation: (diagnosis: Omit<CropDiagnosis, 'id' | 'timestamp'>) => void;
  selectedLanguage: LanguageCode;
  profile: FarmerProfile;
  consultations: CropDiagnosis[];
}

export const CropDoctorView: React.FC<CropDoctorViewProps> = ({
  onDiagnose,
  onSaveConsultation,
  selectedLanguage,
  profile,
  consultations
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(SAMPLE_CROP_IMAGES[0].dataUrl);
  const [mimeType, setMimeType] = useState<string>('image/svg+xml');
  const [cropType, setCropType] = useState<string>('Cotton');
  const [symptoms, setSymptoms] = useState<string>(SAMPLE_CROP_IMAGES[0].symptomsDescription);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [diagnosisResult, setDiagnosisResult] = useState<any | null>(null);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPEG, PNG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
      setMimeType(file.type);
      setDiagnosisResult(null);
      setSavedSuccess(false);
      setErrorMsg(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSample = (sample: SampleImageItem) => {
    setSelectedImage(sample.dataUrl);
    setMimeType('image/svg+xml');
    setCropType(sample.crop);
    setSymptoms(sample.symptomsDescription);
    setDiagnosisResult(null);
    setSavedSuccess(false);
    setErrorMsg(null);
  };

  const handleRunDiagnosis = async () => {
    setIsAnalyzing(true);
    setErrorMsg(null);
    setSavedSuccess(false);

    try {
      const res = await onDiagnose({
        imageBase64: selectedImage || undefined,
        mimeType: mimeType,
        cropType: cropType,
        symptoms: symptoms,
        language: selectedLanguage
      });
      setDiagnosisResult(res);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to analyze crop image. Please check network connection.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveToHistory = () => {
    if (!diagnosisResult) return;

    onSaveConsultation({
      crop: diagnosisResult.crop || cropType,
      diseaseName: diagnosisResult.diseaseName,
      confidence: diagnosisResult.confidence || 88,
      severity: diagnosisResult.severity || 'Moderate',
      symptoms: diagnosisResult.symptoms || [],
      causes: diagnosisResult.causes || [],
      safeNextSteps: diagnosisResult.safeNextSteps || [],
      prevention: diagnosisResult.prevention || [],
      notes: diagnosisResult.notes || 'Saved from AI Crop Doctor',
      imageUrl: selectedImage || undefined,
      language: selectedLanguage,
      source: 'Crop Doctor',
      status: diagnosisResult.severity === 'Severe' ? 'Active' : 'Under Observation'
    });

    setSavedSuccess(true);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>Gemini 3.8 Vision Pathology Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              AI Crop Doctor (పంట వ్యాధి నిర్ధారణ)
            </h1>
            <p className="text-xs sm:text-sm text-gray-600 max-w-2xl">
              Upload a clear photograph of an affected plant leaf or fruit. Our AI detects disease pathogens, estimates severity, and prescribes verified safe biological and agronomic treatments.
            </p>
          </div>

          <div className="flex items-center gap-2 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 max-w-xs">
            <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0" />
            <span>ICAR Safe Practice Guarantee: No toxic unregistered chemical cocktails.</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Input Form & Image Uploader (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-5">
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-2">
              <Camera className="w-4 h-4 text-emerald-700" />
              <span>Step 1: Crop Photograph</span>
            </h2>

            {/* Image Preview / Drop Area */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="relative aspect-4/3 rounded-2xl border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/40 hover:bg-emerald-50/70 transition-all flex flex-col items-center justify-center p-4 cursor-pointer overflow-hidden group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />

              {selectedImage ? (
                <div className="relative w-full h-full flex items-center justify-center">
                  <img
                    src={selectedImage}
                    alt="Selected leaf specimen"
                    className="max-h-full max-w-full object-contain rounded-xl shadow-xs"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-xs font-semibold gap-1.5 rounded-xl">
                    <Camera className="w-4 h-4" />
                    <span>Change Image</span>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-800">Tap to upload leaf photo</p>
                    <p className="text-[11px] text-gray-500">Take photo from camera or choose file</p>
                  </div>
                </div>
              )}
            </div>

            {/* Quick 1-Click Diagnostic Presets */}
            <div>
              <p className="text-xs font-bold text-gray-700 mb-2">Or test with verified sample leaves:</p>
              <div className="grid grid-cols-2 gap-2">
                {SAMPLE_CROP_IMAGES.map((sample) => (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => handleSelectSample(sample)}
                    className="p-2 rounded-xl text-left border border-gray-200 hover:border-emerald-500 bg-gray-50/60 hover:bg-emerald-50 text-[11px] font-semibold text-gray-800 transition flex items-center gap-2 cursor-pointer"
                  >
                    <div className="w-7 h-7 rounded-lg overflow-hidden shrink-0 bg-white border border-gray-200">
                      <img src={sample.dataUrl} alt={sample.name} className="w-full h-full object-cover" />
                    </div>
                    <span className="truncate">{sample.crop}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Crop Selector & Symptoms */}
            <div className="space-y-4 pt-2 border-t border-gray-100">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Select Crop (పంట)</label>
                <select
                  value={cropType}
                  onChange={(e) => setCropType(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-medium"
                >
                  <option value="Cotton">Cotton (పత్తి)</option>
                  <option value="Chilli">Chilli / Mirchi (ఎర్ర మిర్చి)</option>
                  <option value="Tomato">Tomato (టమాటా)</option>
                  <option value="Paddy">Paddy / Rice (వరి)</option>
                  <option value="Maize">Maize (మొక్కజొన్న)</option>
                  <option value="Turmeric">Turmeric (పసుపు)</option>
                  <option value="Soybean">Soybean (సోయాబీన్)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Describe Visible Symptoms (లక్షణాలు)
                </label>
                <textarea
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  rows={3}
                  placeholder="e.g. Brown circular spots with yellow rings, leaf curling, wilting stems..."
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button
                onClick={handleRunDiagnosis}
                disabled={isAnalyzing}
                className="w-full py-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-400 text-white font-bold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Analyzing Leaf with Gemini Vision...</span>
                  </>
                ) : (
                  <>
                    <Activity className="w-4 h-4" />
                    <span>Analyze Crop Health</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Professional Diagnosis Report (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {diagnosisResult ? (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-md space-y-6 animate-in fade-in duration-200">
              {/* Report Header */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-100 pb-5 gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold">
                      {diagnosisResult.crop || cropType}
                    </span>
                    <span className="text-xs text-gray-400 font-mono">
                      Ref: KM-{Date.now().toString().slice(-6)}
                    </span>
                  </div>
                  <h3 className="text-2xl font-extrabold text-gray-900 tracking-tight">
                    {diagnosisResult.diseaseName}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  {/* Severity Badge */}
                  <span
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs shadow-2xs ${
                      diagnosisResult.severity === 'Severe'
                        ? 'bg-rose-100 text-rose-800 border border-rose-300'
                        : diagnosisResult.severity === 'Moderate'
                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                        : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    }`}
                  >
                    Severity: {diagnosisResult.severity}
                  </span>

                  {/* Confidence */}
                  <span className="px-3 py-1.5 rounded-xl bg-gray-100 text-gray-700 text-xs font-bold">
                    Confidence: {diagnosisResult.confidence}%
                  </span>
                </div>
              </div>

              {/* Unclear image warning if applicable */}
              {diagnosisResult.isUnclear && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1">
                  <p className="font-bold flex items-center gap-1.5 text-amber-950">
                    <Info className="w-4 h-4 text-amber-700" />
                    <span>Image Clarity Notice</span>
                  </p>
                  <p>
                    The photograph appears somewhat blurred or dimly lit. For 100% conclusive identification, please upload a close-up photo taken in bright daylight.
                  </p>
                </div>
              )}

              {/* Symptoms & Pathogen Causes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 space-y-2">
                  <h4 className="text-xs uppercase font-extrabold text-gray-700 tracking-wider">
                    Visible Symptoms
                  </h4>
                  <ul className="space-y-1.5 text-xs text-gray-700">
                    {diagnosisResult.symptoms?.map((s: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 space-y-2">
                  <h4 className="text-xs uppercase font-extrabold text-gray-700 tracking-wider">
                    Probable Causes
                  </h4>
                  <ul className="space-y-1.5 text-xs text-gray-700">
                    {diagnosisResult.causes?.map((c: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Recommended Safe Next Steps */}
              <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-100 space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-700" />
                  <h4 className="text-sm font-extrabold text-emerald-950">
                    Recommended Safe Next Steps (తక్షణ రక్షణ చర్యలు)
                  </h4>
                </div>
                <ul className="space-y-2 text-xs text-emerald-900">
                  {diagnosisResult.safeNextSteps?.map((step: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-emerald-200 text-emerald-900 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed font-medium">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Prevention & Long-term management */}
              <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 space-y-2">
                <h4 className="text-xs uppercase font-extrabold text-gray-700 tracking-wider">
                  Long-Term Prevention Measures
                </h4>
                <ul className="space-y-1 text-xs text-gray-600">
                  {diagnosisResult.prevention?.map((p: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Buttons: Save Consultation */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-gray-100">
                <p className="text-[11px] text-gray-400">
                  Preliminary diagnosis. Consult local KVK officer before chemical intervention.
                </p>

                <button
                  onClick={handleSaveToHistory}
                  disabled={savedSuccess}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                    savedSuccess
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-emerald-800 hover:bg-emerald-900 text-white shadow-xs'
                  }`}
                >
                  <BookmarkCheck className="w-4 h-4" />
                  <span>{savedSuccess ? 'Saved to Consultations!' : 'Save to My Health Logbook'}</span>
                </button>
              </div>
            </div>
          ) : (
            /* Empty State */
            <div className="bg-white rounded-3xl p-12 border border-gray-100 shadow-xs text-center space-y-4 flex flex-col items-center justify-center min-h-[480px]">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <Activity className="w-8 h-8" />
              </div>
              <div className="max-w-sm space-y-1">
                <h3 className="font-extrabold text-base text-gray-900">Ready to Diagnose Your Crop</h3>
                <p className="text-xs text-gray-500 leading-relaxed">
                  Select a leaf photo or pick one of the verified sample leaves on the left, then click "Analyze Crop Health" to generate your detailed diagnostic report.
                </p>
              </div>
              <div className="pt-2 flex items-center gap-4 text-xs text-gray-400">
                <span>• Pink Bollworm</span>
                <span>• Alternaria Leaf Spot</span>
                <span>• Chilli Leaf Curl</span>
                <span>• Blight</span>
              </div>
            </div>
          )}

          {/* Past Consultations Quick Log */}
          {consultations.length > 0 && (
            <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-3">
              <h3 className="text-xs uppercase font-extrabold text-gray-500 tracking-wider">
                Saved Consultation History ({consultations.length})
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {consultations.slice(0, 4).map((c) => (
                  <div key={c.id} className="p-3 rounded-xl bg-gray-50 border border-gray-100 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-800">{c.crop}</span>
                      <span className="text-[10px] text-gray-400">
                        {new Date(c.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    <p className="text-emerald-800 font-medium text-[11px] truncate">{c.diseaseName}</p>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-gray-200 text-gray-700 font-medium">
                      Status: {c.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
