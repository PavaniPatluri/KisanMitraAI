import React, { useState } from 'react';
import {
  TrendingUp,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  MapPin,
  Calendar,
  Layers,
  Filter,
  Sparkles,
  Info,
  ChevronRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  AreaChart,
  Area
} from 'recharts';
import { MandiRecord } from '../types/index.ts';

interface MandiPricesViewProps {
  mandiRecords: MandiRecord[];
}

export const MandiPricesView: React.FC<MandiPricesViewProps> = ({ mandiRecords }) => {
  const [selectedCrop, setSelectedCrop] = useState<string>('All');
  const [selectedState, setSelectedState] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeRecordId, setActiveRecordId] = useState<string>(mandiRecords[0]?.id || 'mandi_01');

  // Filter records
  const filteredRecords = mandiRecords.filter((rec) => {
    const matchesCrop = selectedCrop === 'All' || rec.commodity.toLowerCase().includes(selectedCrop.toLowerCase());
    const matchesState = selectedState === 'All' || rec.state.toLowerCase() === selectedState.toLowerCase();
    const matchesSearch =
      searchQuery === '' ||
      rec.commodity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.market.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.district.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCrop && matchesState && matchesSearch;
  });

  const activeRecord = mandiRecords.find((r) => r.id === activeRecordId) || mandiRecords[0];

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-700" />
              <span>AGMARKNET APMC Price Intelligence</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              Smart Mandi Price Comparison
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              Live market arrivals, minimum, maximum, and modal wholesale rates across Telangana and neighboring APMC mandis.
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 font-medium">
            <span>Cotton Minimum Support Price (MSP 2026): <strong>₹7,121 / Quintal</strong></span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs flex flex-col md:flex-row items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search crop, mandi yard, or district..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        {/* Commodity filter */}
        <div className="w-full md:w-48">
          <select
            value={selectedCrop}
            onChange={(e) => setSelectedCrop(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
          >
            <option value="All">All Crops (అన్ని పంటలు)</option>
            <option value="Cotton">Cotton (పత్తి)</option>
            <option value="Chilli">Red Chilli (మిర్చి)</option>
            <option value="Paddy">Paddy / Rice (వరి)</option>
            <option value="Maize">Maize (మొక్కజొన్న)</option>
            <option value="Soybean">Soybean (సోయాబీన్)</option>
            <option value="Turmeric">Turmeric (పసుపు)</option>
          </select>
        </div>

        {/* State filter */}
        <div className="w-full md:w-48">
          <select
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
          >
            <option value="All">All States (అన్ని రాష్ట్రాలు)</option>
            <option value="Telangana">Telangana</option>
            <option value="Andhra Pradesh">Andhra Pradesh</option>
            <option value="Maharashtra">Maharashtra</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Mandi Records List (5 cols) & Interactive Chart (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: List of Mandi Cards (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs uppercase font-extrabold text-gray-500 tracking-wider">
            Available APMC Market Yards ({filteredRecords.length})
          </h3>

          <div className="space-y-3 max-h-[640px] overflow-y-auto pr-1">
            {filteredRecords.map((rec) => {
              const isActive = rec.id === activeRecord?.id;
              return (
                <div
                  key={rec.id}
                  onClick={() => setActiveRecordId(rec.id)}
                  className={`p-4 rounded-2xl border transition cursor-pointer ${
                    isActive
                      ? 'bg-emerald-50/80 border-emerald-400 shadow-xs'
                      : 'bg-white border-gray-100 hover:border-emerald-200 shadow-2xs'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-sm text-gray-900">{rec.commodity}</span>
                        {isActive && (
                          <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
                        )}
                      </div>
                      <p className="text-[11px] text-gray-500 font-medium">{rec.variety}</p>
                    </div>

                    {/* Trend Pill */}
                    <div className="text-right">
                      <span className={`inline-flex items-center gap-0.5 text-xs font-bold ${
                        rec.trend === 'up'
                          ? 'text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full'
                          : rec.trend === 'down'
                          ? 'text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full'
                          : 'text-gray-700 bg-gray-100 px-2 py-0.5 rounded-full'
                      }`}>
                        {rec.trend === 'up' ? (
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        ) : rec.trend === 'down' ? (
                          <ArrowDownRight className="w-3.5 h-3.5" />
                        ) : (
                          <Minus className="w-3.5 h-3.5" />
                        )}
                        <span>{rec.changePercent > 0 ? `+${rec.changePercent}%` : `${rec.changePercent}%`}</span>
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-gray-100">
                    <span className="text-gray-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-700" />
                      {rec.market.split(',')[0]}
                    </span>
                    <div className="text-right">
                      <span className="text-[10px] text-gray-400">Modal Price: </span>
                      <strong className="text-sm font-extrabold text-emerald-950">₹{rec.modalPrice.toLocaleString()}</strong>
                      <span className="text-[10px] text-gray-400">/q</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed View & 30-Day Recharts Trend (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {activeRecord ? (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-100 pb-5 gap-3">
                <div>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                    {activeRecord.district}, {activeRecord.state}
                  </span>
                  <h3 className="text-2xl font-extrabold text-gray-900 tracking-tight mt-1">
                    {activeRecord.market}
                  </h3>
                  <p className="text-xs text-gray-500 font-medium">{activeRecord.commodity} • {activeRecord.variety}</p>
                </div>

                <div className="text-right">
                  <span className="text-xs text-gray-400">Modal Rate Today</span>
                  <p className="text-3xl font-extrabold text-emerald-900">
                    ₹{activeRecord.modalPrice.toLocaleString()}
                    <span className="text-xs font-normal text-gray-400">/Quintal</span>
                  </p>
                </div>
              </div>

              {/* Min, Modal, Max Price Cards */}
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
                  <span className="text-[10px] uppercase font-bold text-gray-400">Minimum Price</span>
                  <p className="text-lg font-bold text-gray-800 mt-1">₹{activeRecord.minPrice.toLocaleString()}</p>
                  <span className="text-[10px] text-gray-400">Per Quintal</span>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[10px] uppercase font-bold text-emerald-700">Modal Price</span>
                  <p className="text-xl font-extrabold text-emerald-950 mt-1">₹{activeRecord.modalPrice.toLocaleString()}</p>
                  <span className="text-[10px] text-emerald-800">Most Traded Rate</span>
                </div>

                <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
                  <span className="text-[10px] uppercase font-bold text-gray-400">Maximum Price</span>
                  <p className="text-lg font-bold text-gray-800 mt-1">₹{activeRecord.maxPrice.toLocaleString()}</p>
                  <span className="text-[10px] text-gray-400">Top Quality Grade</span>
                </div>
              </div>

              {/* 30-Day Historical Trend Chart (Recharts) */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs uppercase font-extrabold text-gray-700 tracking-wider">
                    30-Day Historical Price Trend (₹ / Quintal)
                  </h4>
                  <span className="text-xs text-emerald-700 font-semibold">Arrivals: {activeRecord.arrivalQuantity}</span>
                </div>

                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={activeRecord.history30d}
                      margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#16A34A" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#16A34A" stopOpacity={0.0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                      <XAxis
                        dataKey="date"
                        tick={{ fontSize: 10, fill: '#6B7280' }}
                        interval={5}
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: '#6B7280' }}
                        domain={['auto', 'auto']}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#14532D',
                          borderRadius: '12px',
                          color: '#fff',
                          fontSize: '12px',
                          border: 'none'
                        }}
                        formatter={(val: any) => [`₹${val.toLocaleString()}`, 'Price']}
                      />
                      <Area
                        type="monotone"
                        dataKey="price"
                        stroke="#16A34A"
                        strokeWidth={2.5}
                        fillOpacity={1}
                        fill="url(#colorPrice)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Selling Advice */}
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 text-xs text-emerald-950 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                  <span>KisanMitra Selling Advisory:</span>
                </p>
                <p className="text-emerald-800 leading-relaxed font-medium">
                  Current rate of ₹{activeRecord.modalPrice.toLocaleString()}/q is 4.6% above Government MSP. Ensure cotton moisture is kept below 8% and remove dry leaves (trash &lt; 3%) before bringing to the market yard to qualify for maximum grade price.
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-12 text-center text-xs text-gray-400">
              Select a mandi from the list to view historical price charts.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
