import React, { useState } from 'react';
import {
  User,
  Phone,
  Lock,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sprout,
  MapPin,
  Languages,
  KeyRound,
  UserPlus,
  LogIn,
  RotateCcw
} from 'lucide-react';
import { FarmerProfile, LanguageCode } from '../types/index.ts';
import { LANGUAGE_LOCALES } from '../utils/speech.ts';

interface LoginPageProps {
  currentProfile: FarmerProfile;
  availableProfiles: FarmerProfile[];
  onLoginSuccess: (profile: FarmerProfile) => void;
  onNavigate: (view: string) => void;
  selectedLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
  onSwitchProfile: (id: string) => Promise<boolean>;
  onLoginWithPhone: (phone: string, pin: string) => Promise<{ success: boolean; error?: string; profile?: FarmerProfile }>;
  onRegisterFarmer: (data: any) => Promise<{ success: boolean; error?: string; profile?: FarmerProfile }>;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  currentProfile,
  availableProfiles,
  onLoginSuccess,
  onNavigate,
  selectedLanguage,
  onSelectLanguage,
  onSwitchProfile,
  onLoginWithPhone,
  onRegisterFarmer
}) => {
  const [activeTab, setActiveTab] = useState<'phone' | 'demo' | 'register'>('phone');

  // Phone Login State
  const [phoneInput, setPhoneInput] = useState<string>('9848034211');
  const [pinInput, setPinInput] = useState<string>('1234');
  const [useOtpMode, setUseOtpMode] = useState<boolean>(false);
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpInput, setOtpInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Registration State
  const [regName, setRegName] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('');
  const [regPin, setRegPin] = useState<string>('1234');
  const [regState, setRegState] = useState<string>('Telangana');
  const [regDistrict, setRegDistrict] = useState<string>('Warangal');
  const [regLocation, setRegLocation] = useState<string>('Warangal Rural');
  const [regCrop, setRegCrop] = useState<string>('Cotton (పత్తి)');
  const [regLand, setRegLand] = useState<string>('3.0 Acres');
  const [regSoil, setRegSoil] = useState<string>('Black Soil (నల్లరేగడి నేల)');
  const [regIrrigation, setRegIrrigation] = useState<string>('Borewell with Micro-Drip');
  const [regLang, setRegLang] = useState<LanguageCode>(selectedLanguage);

  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanPhone = phoneInput.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }

    if (useOtpMode && !otpSent) {
      setOtpSent(true);
      setSuccessMsg('Demo OTP sent: 1234 (Enter 1234 below to verify)');
      return;
    }

    if (useOtpMode && otpSent) {
      if (otpInput.trim() !== '1234') {
        setErrorMsg('Invalid OTP. Use demo verification code 1234.');
        return;
      }
    }

    setLoading(true);
    try {
      const res = await onLoginWithPhone(cleanPhone, pinInput);
      if (res.success && res.profile) {
        setSuccessMsg(`Welcome back, ${res.profile.name}!`);
        setTimeout(() => {
          onLoginSuccess(res.profile!);
        }, 600);
      } else {
        setErrorMsg(res.error || 'Failed to login with provided credentials.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Login request failed. Please check network.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickSwitch = async (profileId: string) => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const success = await onSwitchProfile(profileId);
      if (success) {
        const found = availableProfiles.find(p => p.id === profileId);
        if (found) {
          setSuccessMsg(`Switched to farmer ${found.name}!`);
          setTimeout(() => {
            onLoginSuccess(found);
          }, 600);
        }
      } else {
        setErrorMsg('Could not switch to selected farmer profile.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to switch profile.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!regName.trim() || !regPhone.trim()) {
      setErrorMsg('Full name and mobile number are mandatory.');
      return;
    }

    setLoading(true);
    try {
      const res = await onRegisterFarmer({
        name: regName.trim(),
        phone: regPhone.replace(/\D/g, ''),
        pin: regPin || '1234',
        state: regState,
        district: regDistrict,
        location: regLocation,
        cropName: regCrop,
        landArea: regLand,
        soilType: regSoil,
        irrigationMethod: regIrrigation,
        preferredLanguage: regLang,
        cropGrowthStage: 'Vegetative to Flowering Stage'
      });

      if (res.success && res.profile) {
        setSuccessMsg(`Account created successfully for ${res.profile.name}!`);
        setTimeout(() => {
          onLoginSuccess(res.profile!);
        }, 700);
      } else {
        setErrorMsg(res.error || 'Registration failed.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Registration request failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
              <span>రైతు లాగిన్ • Farmer Sign In • किसान लॉगिन</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              Farmer Profile Authentication
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              Sign in with your mobile number to access personalized crop health logs, weather alerts, and tailored voice recommendations.
            </p>
          </div>

          {/* Currently Logged In Chip */}
          <div className="p-3 rounded-2xl bg-emerald-50/80 border border-emerald-200 text-xs flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-xs">
              {currentProfile.name.charAt(0)}
            </div>
            <div>
              <p className="text-[10px] text-gray-400 uppercase font-bold">Active Account</p>
              <p className="font-bold text-emerald-950">{currentProfile.name.split('(')[0]}</p>
              <p className="text-[10px] text-emerald-700">{currentProfile.location} • {currentProfile.landArea}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center justify-center p-1.5 rounded-2xl bg-gray-100 max-w-md mx-auto">
        <button
          type="button"
          onClick={() => {
            setActiveTab('phone');
            setErrorMsg(null);
            setSuccessMsg(null);
          }}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'phone'
              ? 'bg-white text-emerald-950 shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Phone className="w-3.5 h-3.5 text-emerald-700" />
          <span>Mobile Login</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveTab('demo');
            setErrorMsg(null);
            setSuccessMsg(null);
          }}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'demo'
              ? 'bg-white text-emerald-950 shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
          <span>Demo Farmers (1-Click)</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveTab('register');
            setErrorMsg(null);
            setSuccessMsg(null);
          }}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'register'
              ? 'bg-white text-emerald-950 shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <UserPlus className="w-3.5 h-3.5 text-emerald-700" />
          <span>New Farmer</span>
        </button>
      </div>

      {/* Alert / Feedback Messages */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2 max-w-lg mx-auto">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-xs text-emerald-900 font-bold flex items-center gap-2 max-w-lg mx-auto animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* TAB 1: MOBILE & PIN / OTP LOGIN */}
      {activeTab === 'phone' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-xs max-w-md mx-auto space-y-6">
          <div className="text-center space-y-1">
            <h2 className="text-lg font-extrabold text-gray-900">Sign In to KisanMitra AI</h2>
            <p className="text-xs text-gray-500">
              Enter your registered mobile number and PIN or verify via SMS OTP
            </p>
          </div>

          <form onSubmit={handlePhoneLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Mobile Number (మొబైల్ నంబర్)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">
                  +91
                </span>
                <input
                  type="tel"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  placeholder="98480 XXXXX"
                  maxLength={10}
                  className="w-full pl-12 pr-4 py-2.5 text-xs font-semibold border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>
              <p className="text-[10px] text-gray-400 mt-1">
                Demo number: <strong>9848034211</strong> (Ramesh) or <strong>9440122344</strong> (Lakshmi)
              </p>
            </div>

            {useOtpMode ? (
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Enter 4-Digit OTP (ఓటీపీ)
                </label>
                <input
                  type="text"
                  value={otpInput}
                  onChange={(e) => setOtpInput(e.target.value)}
                  placeholder="Enter 1234"
                  maxLength={4}
                  className="w-full px-4 py-2.5 text-xs text-center font-mono tracking-widest text-base font-bold border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <div className="flex items-center justify-between text-[11px] mt-1 text-gray-500">
                  <span>Demo OTP is always <strong>1234</strong></span>
                  <button
                    type="button"
                    onClick={() => setUseOtpMode(false)}
                    className="text-emerald-700 font-semibold hover:underline cursor-pointer"
                  >
                    Login with PIN instead
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-gray-700">
                    4-Digit Security PIN (పిన్)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setUseOtpMode(true);
                      setOtpSent(false);
                    }}
                    className="text-[11px] text-emerald-700 font-semibold hover:underline cursor-pointer"
                  >
                    Use SMS OTP instead
                  </button>
                </div>
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="1234"
                  maxLength={4}
                  className="w-full px-4 py-2.5 text-xs font-mono font-bold tracking-widest text-center border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
                <span className="text-[10px] text-gray-400 block mt-1">
                  Default demo PIN is <strong>1234</strong>
                </span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-400 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <LogIn className="w-4 h-4" />
              <span>{loading ? 'Authenticating...' : useOtpMode && !otpSent ? 'Send Verification OTP' : 'Sign In as Farmer'}</span>
            </button>
          </form>

          {/* Trust Guarantee */}
          <div className="pt-4 border-t border-gray-100 text-center space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-emerald-900">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Agristack Verified & Protected</span>
            </div>
            <p className="text-[10px] text-gray-400">
              No private passwords required. Fast, respectful, zero-friction sign in for Indian farmers.
            </p>
          </div>
        </div>
      )}

      {/* TAB 2: DEMO FARMERS (1-CLICK INSTANT LOGIN) */}
      {activeTab === 'demo' && (
        <div className="space-y-4">
          <div className="text-center max-w-md mx-auto space-y-1">
            <h2 className="text-lg font-extrabold text-gray-900">Choose a Demo Farmer Profile</h2>
            <p className="text-xs text-gray-500">
              Switch between diverse agro-climatic zones, crops, languages, and soil types with 1 click:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableProfiles.map((p) => {
              const isCurrent = p.id === currentProfile.id;
              return (
                <div
                  key={p.id}
                  className={`bg-white rounded-2xl p-5 border transition shadow-xs flex flex-col justify-between ${
                    isCurrent
                      ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/30'
                      : 'border-gray-100 hover:border-emerald-300'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-extrabold text-base text-gray-900">{p.name}</h3>
                          {isCurrent && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-emerald-800 font-semibold flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-emerald-600" />
                          <span>{p.location}, {p.district} ({p.state})</span>
                        </p>
                      </div>

                      <span className="text-xs px-2 py-1 rounded-lg bg-gray-100 text-gray-700 font-mono font-bold">
                        {p.landArea}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                      <div className="p-2 rounded-xl bg-gray-50">
                        <span className="text-gray-400 text-[10px] block">Primary Crop:</span>
                        <strong className="text-gray-800">{p.cropName}</strong>
                      </div>
                      <div className="p-2 rounded-xl bg-gray-50">
                        <span className="text-gray-400 text-[10px] block">Soil & Irrigation:</span>
                        <strong className="text-gray-800 truncate block">{p.soilType.split('(')[0]}</strong>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-gray-500 pt-1">
                      <span>Phone: <strong>{p.phone}</strong></span>
                      <span>PIN: <strong>{p.pin || '1234'}</strong></span>
                      <span>Lang: <strong>{LANGUAGE_LOCALES[p.preferredLanguage]?.name || 'Telugu'}</strong></span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-100">
                    <button
                      onClick={() => handleQuickSwitch(p.id)}
                      disabled={loading || isCurrent}
                      className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        isCurrent
                          ? 'bg-gray-100 text-gray-400 cursor-default'
                          : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
                      }`}
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>{isCurrent ? 'Currently Active Farmer' : `Sign In as ${p.name.split(' ')[0]}`}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: NEW FARMER REGISTRATION */}
      {activeTab === 'register' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-xs max-w-2xl mx-auto space-y-6">
          <div className="text-center space-y-1">
            <h2 className="text-lg font-extrabold text-gray-900">Create New Farmer Account</h2>
            <p className="text-xs text-gray-500">
              Register your farm to receive automated personalized AI disease diagnostics and mandi notifications
            </p>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Farmer Full Name (రైతు పేరు) *
                </label>
                <input
                  type="text"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Anji Reddy / Rajesh Sharma"
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Mobile Phone */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Mobile Number (మొబైల్ నంబర్) *
                </label>
                <input
                  type="tel"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="10-digit mobile number"
                  maxLength={10}
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* State */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">State (రాష్ట్రం)</label>
                <select
                  value={regState}
                  onChange={(e) => setRegState(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                >
                  <option value="Telangana">Telangana</option>
                  <option value="Andhra Pradesh">Andhra Pradesh</option>
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Karnataka">Karnataka</option>
                  <option value="Madhya Pradesh">Madhya Pradesh</option>
                  <option value="Punjab">Punjab</option>
                </select>
              </div>

              {/* District */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">District (జిల్లా)</label>
                <input
                  type="text"
                  value={regDistrict}
                  onChange={(e) => setRegDistrict(e.target.value)}
                  placeholder="e.g. Warangal / Guntur / Karimnagar"
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Location */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Village / Mandal (గ్రామం)</label>
                <input
                  type="text"
                  value={regLocation}
                  onChange={(e) => setRegLocation(e.target.value)}
                  placeholder="e.g. Wardhannapet / Tenali"
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Land Acreage */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Land Area (ఎకరాలు)</label>
                <input
                  type="text"
                  value={regLand}
                  onChange={(e) => setRegLand(e.target.value)}
                  placeholder="e.g. 3.0 Acres / 5 Hectares"
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Primary Crop */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Primary Crop (ప్రధాన పంట)</label>
                <input
                  type="text"
                  value={regCrop}
                  onChange={(e) => setRegCrop(e.target.value)}
                  placeholder="e.g. Cotton, Chilli, Paddy, Maize"
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Preferred Language */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Preferred Language for Voice AI</label>
                <select
                  value={regLang}
                  onChange={(e) => setRegLang(e.target.value as LanguageCode)}
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-semibold"
                >
                  {(Object.keys(LANGUAGE_LOCALES) as LanguageCode[]).map((c) => (
                    <option key={c} value={c}>
                      {LANGUAGE_LOCALES[c].nativeName} ({LANGUAGE_LOCALES[c].name})
                    </option>
                  ))}
                </select>
              </div>

              {/* Soil Type */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Soil Type (నేల రకం)</label>
                <input
                  type="text"
                  value={regSoil}
                  onChange={(e) => setRegSoil(e.target.value)}
                  placeholder="e.g. Deep Black Soil, Red Sandy Loam"
                  className="w-full px-3.5 py-2 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* 4-digit PIN */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Set 4-Digit Login PIN</label>
                <input
                  type="password"
                  value={regPin}
                  onChange={(e) => setRegPin(e.target.value)}
                  maxLength={4}
                  placeholder="1234"
                  className="w-full px-3.5 py-2 text-xs font-mono font-bold tracking-widest border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="pt-3">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-400 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>{loading ? 'Creating Profile...' : 'Complete Registration & Sign In'}</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
