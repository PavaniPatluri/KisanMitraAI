import React, { useState, useEffect } from 'react';
import {
  CloudSun,
  Droplets,
  Wind,
  Sun,
  CloudRain,
  AlertTriangle,
  CheckCircle2,
  MapPin,
  Calendar,
  Compass,
  Sparkles,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { WeatherData } from '../types/index.ts';

interface WeatherViewProps {
  weather: WeatherData | null;
  onRefreshWeather: (district: string) => Promise<void>;
  currentDistrict: string;
}

const DISTRICT_LIST = [
  { key: 'warangal', name: 'Warangal, Telangana' },
  { key: 'khammam', name: 'Khammam, Telangana' },
  { key: 'karimnagar', name: 'Karimnagar, Telangana' },
  { key: 'nizamabad', name: 'Nizamabad, Telangana' },
  { key: 'guntur', name: 'Guntur, Andhra Pradesh' },
  { key: 'kurnool', name: 'Kurnool, Andhra Pradesh' },
  { key: 'aurangabad', name: 'Chh. Sambhajinagar, Maharashtra' },
  { key: 'indore', name: 'Indore, Madhya Pradesh' }
];

export const WeatherView: React.FC<WeatherViewProps> = ({
  weather,
  onRefreshWeather,
  currentDistrict
}) => {
  const [selectedKey, setSelectedKey] = useState<string>(currentDistrict || 'warangal');
  const [loading, setLoading] = useState<boolean>(false);

  const handleDistrictChange = async (key: string) => {
    setSelectedKey(key);
    setLoading(true);
    await onRefreshWeather(key);
    setLoading(false);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner & Location Switcher */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-900 text-xs font-bold">
              <CloudSun className="w-3.5 h-3.5 text-sky-700" />
              <span>Agro-Meteorological Intelligence (Open-Meteo)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              Weather & Spray Intelligence
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              Real-time temperature, wind, humidity, and rainfall probability to optimize pesticide spraying and irrigation.
            </p>
          </div>

          {/* Location Selector */}
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
            <select
              value={selectedKey}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className="px-3.5 py-2 text-xs font-bold text-gray-800 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {DISTRICT_LIST.map((d) => (
                <option key={d.key} value={d.key}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="bg-white rounded-3xl p-16 text-center text-xs text-gray-500 flex items-center justify-center gap-2">
          <RefreshCw className="w-4 h-4 animate-spin text-emerald-700" />
          <span>Fetching meteorological data for {selectedKey}...</span>
        </div>
      ) : weather ? (
        <>
          {/* Main Weather Overview Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Primary Temp & Current Metrics (7 cols) */}
            <div className="lg:col-span-7 bg-gradient-to-br from-emerald-900 via-emerald-800 to-green-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs text-emerald-300 font-mono uppercase tracking-wider">
                      Current Agro-Climate
                    </span>
                    <h2 className="text-2xl font-bold">{weather.city}, {weather.state}</h2>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold text-white">
                    {weather.condition}
                  </span>
                </div>

                <div className="flex items-baseline gap-4 pt-2">
                  <span className="text-6xl sm:text-7xl font-extrabold tracking-tight">{weather.temperature}°C</span>
                  <div className="text-xs text-emerald-200">
                    <p>Feels like {weather.feelsLike}°C</p>
                    <p className="text-emerald-300">Rain chance: {weather.rainfallChance}%</p>
                  </div>
                </div>
              </div>

              {/* 4 Metrics Strip */}
              <div className="grid grid-cols-4 gap-2 pt-6 mt-6 border-t border-emerald-700/60 text-center">
                <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs">
                  <div className="flex items-center justify-center gap-1 text-emerald-300 mb-1">
                    <Droplets className="w-3.5 h-3.5" />
                    <span className="text-[10px] uppercase font-bold">Humidity</span>
                  </div>
                  <p className="font-extrabold text-sm sm:text-base">{weather.humidity}%</p>
                </div>

                <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs">
                  <div className="flex items-center justify-center gap-1 text-emerald-300 mb-1">
                    <Wind className="w-3.5 h-3.5" />
                    <span className="text-[10px] uppercase font-bold">Wind</span>
                  </div>
                  <p className="font-extrabold text-sm sm:text-base">{weather.windSpeed} km/h</p>
                </div>

                <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs">
                  <div className="flex items-center justify-center gap-1 text-emerald-300 mb-1">
                    <CloudRain className="w-3.5 h-3.5" />
                    <span className="text-[10px] uppercase font-bold">Rain Prob</span>
                  </div>
                  <p className="font-extrabold text-sm sm:text-base">{weather.rainfallChance}%</p>
                </div>

                <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs">
                  <div className="flex items-center justify-center gap-1 text-emerald-300 mb-1">
                    <Sun className="w-3.5 h-3.5" />
                    <span className="text-[10px] uppercase font-bold">UV Index</span>
                  </div>
                  <p className="font-extrabold text-sm sm:text-base">{weather.uvIndex} / 10</p>
                </div>
              </div>
            </div>

            {/* Right: Agricultural Spray Window & Farming Recommendation (5 cols) */}
            <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-700" />
                  <h3 className="font-extrabold text-gray-900 text-base">
                    Spray Window & Farming Advisory
                  </h3>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 text-xs space-y-2">
                  <p className="font-bold text-emerald-950">🌾 Field Recommendation:</p>
                  <p className="text-emerald-800 leading-relaxed font-medium">
                    {weather.advisory}
                  </p>
                </div>

                <div className="space-y-2 text-xs text-gray-600">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50">
                    <span className="font-medium">Morning Spray Window:</span>
                    <span className="font-bold text-emerald-800">07:00 AM – 10:30 AM (Safe)</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50">
                    <span className="font-medium">Wind Drift Safety:</span>
                    <span className={`font-bold ${weather.windSpeed > 15 ? 'text-rose-600' : 'text-emerald-800'}`}>
                      {weather.windSpeed > 15 ? 'Drift Alert (High)' : 'Calm / Safe (< 12 km/h)'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50">
                    <span className="font-medium">Irrigation Run Recommendation:</span>
                    <span className="font-bold text-gray-800">2 Hours Micro-Drip</span>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>Avoid spraying pesticides when daytime temperatures exceed 33°C to prevent rapid chemical evaporation and crop scorch.</span>
              </div>
            </div>
          </div>

          {/* 7-DAY AGRICULTURAL FORECAST TABLE */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-gray-900 text-base">7-Day Agricultural Forecast</h3>
              </div>
              <span className="text-xs text-gray-400">Regional crop advisory</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
              {weather.daily.map((day, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border text-center flex flex-col justify-between space-y-3 ${
                    idx === 0
                      ? 'bg-emerald-50/80 border-emerald-300 shadow-xs'
                      : 'bg-gray-50/70 border-gray-100 hover:border-emerald-200'
                  }`}
                >
                  <div>
                    <span className="text-xs font-bold text-gray-900">{day.day}</span>
                    <p className="text-[10px] text-gray-400 font-medium">{day.date}</p>
                  </div>

                  <div className="my-1">
                    <CloudSun className="w-7 h-7 mx-auto text-emerald-700" />
                    <p className="text-sm font-extrabold text-gray-900 mt-1">
                      {day.maxTemp}° / {day.minTemp}°
                    </p>
                    <span className="text-[10px] font-bold text-sky-700">Rain: {day.rainProb}%</span>
                  </div>

                  <div className="pt-2 border-t border-gray-200/60">
                    <p className="text-[10px] font-semibold text-emerald-900 leading-tight">
                      {day.farmingAction}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hourly Forecast Slider */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-xs space-y-3">
            <h4 className="text-xs uppercase font-extrabold text-gray-500 tracking-wider">
              12-Hour Hourly Trend
            </h4>
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {weather.hourly.map((h, idx) => (
                <div
                  key={idx}
                  className="px-4 py-3 rounded-2xl bg-gray-50 border border-gray-100 min-w-[90px] text-center shrink-0 space-y-1"
                >
                  <p className="text-[10px] text-gray-500 font-semibold">{h.time}</p>
                  <p className="text-base font-bold text-gray-900">{h.temp}°C</p>
                  <p className="text-[10px] text-sky-700 font-medium">💧 {h.rainProb}%</p>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
};
