import React, { useState } from 'react';
import {
  FileText,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Search,
  PhoneCall,
  Sparkles,
  HelpCircle,
  ArrowRight,
  Filter,
  CreditCard,
  Droplets,
  DollarSign
} from 'lucide-react';
import { GovernmentScheme, FarmerProfile } from '../types/index.ts';

interface GovernmentSchemesViewProps {
  schemes: GovernmentScheme[];
  profile: FarmerProfile;
}

export const GovernmentSchemesView: React.FC<GovernmentSchemesViewProps> = ({
  schemes,
  profile
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedSchemeId, setExpandedSchemeId] = useState<string>(schemes[0]?.id || 'pm-kisan');
  const [eligibilityModalOpen, setEligibilityModalOpen] = useState<boolean>(false);

  // Eligibility quiz state
  const [landAcres, setLandAcres] = useState<string>('3.0');
  const [hasAadhaar, setHasAadhaar] = useState<boolean>(true);
  const [hasBankLinked, setHasBankLinked] = useState<boolean>(true);
  const [isTaxPayer, setIsTaxPayer] = useState<boolean>(false);
  const [eligibilityResult, setEligibilityResult] = useState<string[] | null>(null);

  const categories = ['All', 'Direct Income', 'Credit', 'Insurance', 'State Benefit', 'Subsidies'];

  const filteredSchemes = schemes.filter((s) => {
    const matchesCat = selectedCategory === 'All' || s.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch =
      searchQuery === '' ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.shortName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.overview.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const runEligibilityCheck = (e: React.FormEvent) => {
    e.preventDefault();
    const qualified: string[] = [];
    const acres = parseFloat(landAcres) || 0;

    if (hasAadhaar && hasBankLinked && !isTaxPayer) {
      qualified.push('PM-KISAN (₹6,000 / year assured DBT support)');
    }
    if (acres > 0 && hasAadhaar) {
      qualified.push('Kisan Credit Card (KCC) Crop Loan up to ₹3 Lakhs at 4% interest');
      qualified.push('PM Fasal Bima Yojana (PMFBY) Crop Calamity Insurance');
      qualified.push('Rythu Bharosa / Rythu Bandhu Investment Support (₹15,000 / acre)');
    }
    if (acres >= 1.0) {
      qualified.push('PM-KUSUM Solar Agricultural Pump (60% Subsidy)');
    }

    setEligibilityResult(qualified);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              <FileText className="w-3.5 h-3.5 text-emerald-700" />
              <span>Direct Benefit Transfer & Subsidies</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              Government Schemes Assistant (ప్రభుత్వ పథకాలు)
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              Verified details, eligibility requirements, required documents, and official direct application portals for Central & State farmer welfare schemes.
            </p>
          </div>

          <button
            onClick={() => setEligibilityModalOpen(true)}
            className="px-5 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition flex items-center gap-2 cursor-pointer shrink-0"
          >
            <Sparkles className="w-4 h-4 text-emerald-300" />
            <span>Check My Scheme Eligibility</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Categories Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search schemes or benefits..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
          />
        </div>
      </div>

      {/* Schemes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSchemes.map((scheme) => {
          const isExpanded = expandedSchemeId === scheme.id;
          return (
            <div
              key={scheme.id}
              className={`bg-white rounded-3xl p-6 border transition shadow-xs flex flex-col justify-between ${
                isExpanded ? 'border-emerald-500 ring-2 ring-emerald-500/10' : 'border-gray-100 hover:border-gray-300'
              }`}
            >
              <div className="space-y-4">
                {/* Category & Amount */}
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {scheme.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded-md">
                    {scheme.amount.split('(')[0]}
                  </span>
                </div>

                <div>
                  <h3 className="font-extrabold text-base text-gray-900 leading-snug">{scheme.name}</h3>
                  <p className="text-xs text-gray-600 mt-2 leading-relaxed">{scheme.overview}</p>
                </div>

                {/* Eligibility Highlights */}
                <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-100 space-y-1.5 text-xs">
                  <h4 className="text-[11px] font-bold text-gray-800 uppercase tracking-wide">
                    Eligibility Highlights:
                  </h4>
                  <ul className="space-y-1 text-[11px] text-gray-600">
                    {scheme.eligibility.slice(0, 2).map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Required Documents */}
                <div className="space-y-1 text-xs">
                  <span className="text-[11px] font-bold text-gray-700">Documents Needed:</span>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {scheme.documents.map((doc, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-gray-100 text-gray-700 font-medium"
                      >
                        {doc.split('(')[0]}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions & Official Portal Link */}
              <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
                <a
                  href={scheme.officialLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-900 transition"
                >
                  <span>Apply on Official Portal</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <span className="text-[10px] text-gray-400 font-mono">
                  Helpline: {scheme.helpline.split('/')[0]}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* ELIGIBILITY CHECKER MODAL */}
      {eligibilityModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-gray-100 space-y-5 animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div>
                <h3 className="text-lg font-bold text-gray-900">30-Second Scheme Eligibility Quiz</h3>
                <p className="text-xs text-gray-500">For Farmer {profile.name} (Warangal, Telangana)</p>
              </div>
              <button
                onClick={() => {
                  setEligibilityModalOpen(false);
                  setEligibilityResult(null);
                }}
                className="text-gray-400 hover:text-gray-600 text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {!eligibilityResult ? (
              <form onSubmit={runEligibilityCheck} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Total Cultivable Land Area (in Acres)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={landAcres}
                    onChange={(e) => setLandAcres(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-2 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer font-medium text-gray-800">
                    <input
                      type="checkbox"
                      checked={hasAadhaar}
                      onChange={(e) => setHasAadhaar(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>I possess an Aadhaar card linked with an active mobile number</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer font-medium text-gray-800">
                    <input
                      type="checkbox"
                      checked={hasBankLinked}
                      onChange={(e) => setHasBankLinked(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>My bank account is e-KYC verified and seeded for Aadhaar DBT</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer font-medium text-gray-800">
                    <input
                      type="checkbox"
                      checked={isTaxPayer}
                      onChange={(e) => setIsTaxPayer(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Anyone in my household pays income tax (Income tax assessment exclusion)</span>
                  </label>
                </div>

                <div className="pt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEligibilityModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold cursor-pointer"
                  >
                    Evaluate Eligibility
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-emerald-700" />
                    <span>You Qualify for {eligibilityResult.length} Key Welfare Schemes!</span>
                  </div>
                  <ul className="space-y-2 pt-2 text-xs text-emerald-950 font-medium">
                    {eligibilityResult.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-4 h-4 rounded-full bg-emerald-200 text-emerald-900 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                          ✓
                        </span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => setEligibilityResult(null)}
                  className="w-full py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-xs cursor-pointer"
                >
                  Recalculate with Different Details
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
