import React, { useState } from 'react';
import {
  User,
  MapPin,
  Sprout,
  Droplets,
  Layers,
  Languages,
  Save,
  CheckCircle2,
  Calendar,
  Phone,
  Sparkles,
  Info,
  LogIn
} from 'lucide-react';
import { FarmerProfile, LanguageCode } from '../types/index.ts';
import { LANGUAGE_LOCALES } from '../utils/speech.ts';

interface ProfileViewProps {
  profile: FarmerProfile;
  onUpdateProfile: (updated: Partial<FarmerProfile>) => Promise<FarmerProfile>;
  selectedLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
  onNavigate?: (view: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  onUpdateProfile,
  selectedLanguage,
  onSelectLanguage,
  onNavigate
}) => {
  const [formData, setFormData] = useState<FarmerProfile>({ ...profile });
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleChange = (field: keyof FarmerProfile, val: any) => {
    setFormData((prev) => ({ ...prev, [field]: val }));
    setSaveSuccess(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const updated = await onUpdateProfile(formData);
      setFormData(updated);
      setSaveSuccess(true);
      if (formData.preferredLanguage) {
        onSelectLanguage(formData.preferredLanguage);
      }
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to update profile:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 pb-12 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
              <User className="w-3.5 h-3.5 text-emerald-700" />
              <span>Personalized Farm Profile (రైతు వివరాలు)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              Farm Profile & AI Personalization
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              KisanMitra AI customizes disease identification, fertilizer doses, and irrigation advisories specifically to your soil, acreage, and crop growth stage.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
            {saveSuccess && (
              <div className="p-2.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-xs font-bold text-emerald-900 flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <span>Profile Saved!</span>
              </div>
            )}

            {onNavigate && (
              <button
                type="button"
                onClick={() => onNavigate('login')}
                className="px-4 py-2.5 rounded-xl border border-emerald-200 hover:border-emerald-500 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <LogIn className="w-3.5 h-3.5 text-emerald-700" />
                <span>Switch Farmer Account</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Profile Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-xs space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Farmer Full Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Age & Phone */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Age (Years)</label>
              <input
                type="number"
                value={formData.age || 44}
                onChange={(e) => handleChange('age', parseInt(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Phone Number</label>
              <input
                type="text"
                value={formData.phone || ''}
                onChange={(e) => handleChange('phone', e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Location & Mandal */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Village / Mandal / Location</label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => handleChange('location', e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* District & State */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">District</label>
              <input
                type="text"
                value={formData.district}
                onChange={(e) => handleChange('district', e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">State</label>
              <select
                value={formData.state}
                onChange={(e) => handleChange('state', e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
              >
                <option value="Telangana">Telangana</option>
                <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Madhya Pradesh">Madhya Pradesh</option>
              </select>
            </div>
          </div>

          {/* Preferred Language */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Preferred Language for Voice AI</label>
            <select
              value={formData.preferredLanguage}
              onChange={(e) => handleChange('preferredLanguage', e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-semibold text-emerald-950"
            >
              {(Object.keys(LANGUAGE_LOCALES) as LanguageCode[]).map((c) => (
                <option key={c} value={c}>
                  {LANGUAGE_LOCALES[c].nativeName} ({LANGUAGE_LOCALES[c].name})
                </option>
              ))}
            </select>
          </div>

          {/* Land Area */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Total Cultivated Land Area</label>
            <input
              type="text"
              value={formData.landArea}
              onChange={(e) => handleChange('landArea', e.target.value)}
              placeholder="e.g. 3.0 Acres, 5 Hectares"
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Soil Type */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Soil Type (నేల రకం)</label>
            <input
              type="text"
              value={formData.soilType}
              onChange={(e) => handleChange('soilType', e.target.value)}
              placeholder="e.g. Deep Black Cotton Soil, Red Sandy Loam, Clay..."
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Irrigation Method */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Irrigation Method (నీటి పారుదల)</label>
            <input
              type="text"
              value={formData.irrigationMethod}
              onChange={(e) => handleChange('irrigationMethod', e.target.value)}
              placeholder="e.g. Borewell with Micro-Drip, Canal, Open Well, Rainfed..."
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Primary Crop Name */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Primary Crop Cultivated</label>
            <input
              type="text"
              value={formData.cropName}
              onChange={(e) => handleChange('cropName', e.target.value)}
              placeholder="e.g. Cotton - BT Hybrid, Chilli Teja, Paddy BPT 5204..."
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Crop Growth Stage */}
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Current Crop Growth Stage</label>
            <input
              type="text"
              value={formData.cropGrowthStage}
              onChange={(e) => handleChange('cropGrowthStage', e.target.value)}
              placeholder="e.g. Square & Early Flowering (60-70 Days), Vegetative..."
              className="w-full px-3.5 py-2.5 text-xs border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>
        </div>

        <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
          <p className="text-[11px] text-gray-400">
            Changes are persistently stored in backend JSON storage.
          </p>

          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-400 text-white font-bold text-xs shadow-md transition flex items-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving Profile...' : 'Save Profile Changes'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
