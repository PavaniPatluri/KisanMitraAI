import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Droplets,
  CloudSun,
  Activity,
  TrendingUp,
  Sparkles,
  Info,
  CheckCircle2,
  RefreshCw,
  ArrowRight
} from 'lucide-react';
import { FarmRiskAssessment, FarmerProfile, WeatherData } from '../types/index.ts';

interface FarmRiskViewProps {
  riskAssessment: FarmRiskAssessment | null;
  onRefreshRisk: () => Promise<void>;
  profile: FarmerProfile;
  weather: WeatherData | null;
  onNavigate: (view: string) => void;
}

export const FarmRiskView: React.FC<FarmRiskViewProps> = ({
  riskAssessment,
  onRefreshRisk,
  profile,
  weather,
  onNavigate
}) => {
  const [loading, setLoading] = useState<boolean>(false);

  const handleRefresh = async () => {
    setLoading(true);
    await onRefreshRisk();
    setLoading(false);
  };

  const overall = riskAssessment?.overallRisk || 'Medium';
  const score = riskAssessment?.score || 42;

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-100 text-purple-900 text-xs font-bold">
              <ShieldAlert className="w-3.5 h-3.5 text-purple-700" />
              <span>Multi-Factor Agro-Risk Intelligence</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              AI Farm Risk Assessment (వ్యవసాయ నష్ట విశ్లేషణ)
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              Evaluates weather vulnerability, pest/disease symptoms, crop flowering stage, and soil moisture stress to calculate actionable risk indices.
            </p>
          </div>

          <button
            onClick={handleRefresh}
            disabled={loading}
            className="px-4 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold transition flex items-center gap-2 cursor-pointer shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-emerald-700' : ''}`} />
            <span>Recalculate Farm Risk</span>
          </button>
        </div>
      </div>

      {riskAssessment ? (
        <>
          {/* Main Risk Gauge Banner */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Risk Gauge (5 cols) */}
            <div className={`lg:col-span-5 rounded-3xl p-6 sm:p-8 text-white flex flex-col justify-between shadow-xl ${
              overall === 'High'
                ? 'bg-gradient-to-br from-rose-900 via-rose-800 to-red-950'
                : overall === 'Medium'
                ? 'bg-gradient-to-br from-amber-900 via-amber-800 to-yellow-950'
                : 'bg-gradient-to-br from-emerald-900 via-emerald-800 to-green-950'
            }`}>
              <div className="space-y-3">
                <span className="text-xs uppercase font-extrabold tracking-wider opacity-80">
                  Overall Composite Risk Level
                </span>
                <div className="flex items-center gap-3">
                  <h2 className="text-3xl sm:text-4xl font-black">{overall} Risk</h2>
                  <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
                    Index: {score}/100
                  </span>
                </div>
                <p className="text-xs leading-relaxed opacity-90 pt-1">
                  {riskAssessment.summary}
                </p>
              </div>

              {/* Visual meter bar */}
              <div className="pt-6 mt-6 border-t border-white/20 space-y-2">
                <div className="flex justify-between text-[11px] font-bold opacity-80">
                  <span>Low Risk (0-35)</span>
                  <span>Moderate (35-65)</span>
                  <span>High Risk (65-100)</span>
                </div>
                <div className="w-full h-3 rounded-full bg-white/20 overflow-hidden relative">
                  <div
                    className="h-full bg-white rounded-full transition-all duration-500 shadow-sm"
                    style={{ width: `${score}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Farm Context Snapshot (7 cols) */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-gray-900 text-base">Evaluated Farm Parameters</h3>
                  <span className="text-[11px] text-gray-400 font-mono">Real-time dynamic synthesis</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                    <p className="text-gray-400 text-[10px]">Crop Stage</p>
                    <p className="font-bold text-gray-800 truncate">{profile.cropGrowthStage.split('(')[0]}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                    <p className="text-gray-400 text-[10px]">Soil Type</p>
                    <p className="font-bold text-gray-800 truncate">{profile.soilType.split('(')[0]}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                    <p className="text-gray-400 text-[10px]">Forecast Rain</p>
                    <p className="font-bold text-gray-800">{weather?.rainfallChance ?? 15}%</p>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                    <p className="text-gray-400 text-[10px]">Active Diseases</p>
                    <p className="font-bold text-gray-800">1 Logged</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100 text-xs text-emerald-950">
                  <p className="font-bold mb-0.5">🌾 Action Priority:</p>
                  <p className="text-emerald-800 leading-snug">
                    Inspect lower canopy for alternating leaf spot spread and keep 5 pheromone lures active for pink bollworm monitoring.
                  </p>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between text-[11px] text-gray-400 border-t border-gray-100">
                <span>Model: Heuristic agronomic risk synthesis engine.</span>
                <span className="text-emerald-700 font-semibold cursor-pointer" onClick={() => onNavigate('crop-doctor')}>
                  Review Diagnoses →
                </span>
              </div>
            </div>
          </div>

          {/* 4 CATEGORIZED RISK FACTOR CARDS */}
          <div className="space-y-4">
            <h3 className="text-xs uppercase font-extrabold text-gray-500 tracking-wider">
              Factor Breakdown & Scientific Explanations
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {riskAssessment.factors.map((factor, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase font-extrabold text-gray-500 tracking-wider">
                      {factor.category}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                        factor.level === 'High'
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : factor.level === 'Medium'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {factor.level} Risk
                    </span>
                  </div>

                  <h4 className="font-bold text-base text-gray-900">{factor.title}</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">{factor.description}</p>

                  <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-100 text-xs space-y-1">
                    <p className="font-bold text-emerald-950">Recommended Safe Action:</p>
                    <p className="text-emerald-800 leading-relaxed">{factor.recommendation}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="bg-white rounded-3xl p-12 text-center text-xs text-gray-400">
          Loading farm risk assessment...
        </div>
      )}

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 text-xs text-gray-500 leading-relaxed flex items-start gap-2">
        <Info className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
        <span>
          <strong>Scientific Notice:</strong> Farm Risk Intelligence provides advisory risk likelihoods based on local weather forecasts, crop stage sensitivity, and farmer-reported symptoms. It does not replace field inspection by accredited agricultural extension officers.
        </span>
      </div>
    </div>
  );
};
