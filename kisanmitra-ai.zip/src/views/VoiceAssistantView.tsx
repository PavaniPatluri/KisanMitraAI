import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  Bot,
  User,
  Trash2,
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  ArrowRight,
  RefreshCw,
  Languages
} from 'lucide-react';
import { ChatMessage, LanguageCode, FarmerProfile } from '../types/index.ts';
import { speechHandler, LANGUAGE_LOCALES } from '../utils/speech.ts';

interface VoiceAssistantViewProps {
  chatHistory: ChatMessage[];
  onSendMessage: (message: string, language: LanguageCode) => Promise<ChatMessage>;
  onClearChat: () => void;
  selectedLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
  profile: FarmerProfile;
  gnaniStatus: {
    isConfigured: boolean;
    hasApiKey: boolean;
  };
  onNavigate: (view: string) => void;
}

export const VoiceAssistantView: React.FC<VoiceAssistantViewProps> = ({
  chatHistory,
  onSendMessage,
  onClearChat,
  selectedLanguage,
  onSelectLanguage,
  profile,
  gnaniStatus,
  onNavigate
}) => {
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [inputText, setInputText] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activeSpeakingMsgId, setActiveSpeakingMsgId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const chatBottomRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<any>(null);

  // Suggested prompt chips based on selected language
  const promptSuggestions: Record<LanguageCode, string[]> = {
    te: [
      'నా పత్తి పంట ఆకులపై మచ్చలు వస్తున్నాయి. ఏం చేయాలి?',
      'గులాబీ రంగు పురుగు నివారణకు ఎలాంటి చర్యలు తీసుకోవాలి?',
      'నేటి వరంగల్ మార్కెట్ లో పత్తి ధర ఎంత?',
      'పూత రాలకుండా ఎలాంటి ఎరువు పిచికారీ చేయాలి?',
      'రైతు భరోసా పథకానికి అర్హతలు ఏమిటి?'
    ],
    hi: [
      'कपास में फूल झड़ने से रोकने के लिए क्या करें?',
      'गुलाबी सुंडी (Pink Bollworm) की रोकथाम कैसे करें?',
      'आज वारंगल मंडी में कपास का ताजा भाव क्या है?',
      'पीएम-किसान सम्मान निधि के लिए पात्रता क्या है?'
    ],
    en: [
      'My cotton leaves have circular brown spots. What should I do?',
      'How to manage pink bollworm during flowering stage?',
      'What is today\'s cotton modal price in Warangal mandi?',
      'What irrigation schedule is best for black soil?'
    ],
    ta: [
      'பருத்தி இலைகளில் புள்ளிகள் உள்ளன. என்ன செய்ய வேண்டும்?',
      'இன்றைய சந்தை விலை என்ன?'
    ],
    kn: [
      'ಹತ್ತಿ ಬೆಳೆ ಎಲೆಗಳ ಮೇಲೆ ಕಲೆಗಳು ಕಾಣಿಸಿಕೊಂಡಿವೆ. ಏನು ಮಾಡಬೇಕು?',
      'ಇಂದಿನ ಮಾರುಕಟ್ಟೆ ಬೆಲೆ ಎಷ್ಟು?'
    ],
    mr: [
      'कापसाच्या पानांवर डाग पडत आहेत. काय उपाय करावा?',
      'आजचा कापूस बाजारभाव काय आहे?'
    ]
  };

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, interimTranscript]);

  // Clean up speech synthesis & recording on unmount
  useEffect(() => {
    return () => {
      speechHandler.stopListening();
      speechHandler.stopSpeaking();
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const handleStartRecording = () => {
    setErrorMessage(null);
    setInterimTranscript('');
    setRecordingSeconds(0);

    const started = speechHandler.startListening(
      selectedLanguage,
      (text, isFinal) => {
        setInterimTranscript(text);
        if (isFinal) {
          handleStopRecording(text);
        }
      },
      (error) => {
        setErrorMessage(error);
        setIsRecording(false);
        if (timerRef.current) clearInterval(timerRef.current);
      },
      () => {
        setIsRecording(false);
        if (timerRef.current) clearInterval(timerRef.current);
      }
    );

    if (started) {
      setIsRecording(true);
      timerRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    }
  };

  const handleStopRecording = (forcedText?: string) => {
    speechHandler.stopListening();
    setIsRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);

    const textToSend = forcedText || interimTranscript;
    if (textToSend && textToSend.trim()) {
      handleSendQuery(textToSend.trim());
      setInterimTranscript('');
    }
  };

  const handleSendQuery = async (query: string) => {
    if (!query.trim() || isProcessing) return;
    setIsProcessing(true);
    setInputText('');
    setErrorMessage(null);

    try {
      const resMsg = await onSendMessage(query.trim(), selectedLanguage);
      // Auto-speak response if speech synthesis available
      handleSpeakMessage(resMsg.id, resMsg.content, selectedLanguage);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to get AI answer. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSpeakMessage = (msgId: string, text: string, lang: LanguageCode) => {
    if (activeSpeakingMsgId === msgId) {
      speechHandler.stopSpeaking();
      setActiveSpeakingMsgId(null);
      return;
    }

    setActiveSpeakingMsgId(msgId);
    speechHandler.speak(
      text,
      lang,
      () => setActiveSpeakingMsgId(msgId),
      () => setActiveSpeakingMsgId(null),
      () => setActiveSpeakingMsgId(null)
    );
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Top Banner & Status */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center gap-1.5">
                <Mic className="w-3.5 h-3.5 text-emerald-700" />
                <span>Primary Feature • వాయిస్ అసిస్టెంట్</span>
              </span>

              {/* Live Gnani vs Browser Speech badge */}
              <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                gnaniStatus.isConfigured
                  ? 'bg-purple-50 text-purple-800 border-purple-200'
                  : 'bg-emerald-50 text-emerald-800 border-emerald-200'
              }`}>
                {gnaniStatus.isConfigured
                  ? 'Gnani.ai Live (Prisma / Evon / Timbre)'
                  : 'Browser Speech AI + Gemini 3.8'}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
              Multilingual Voice Assistant
            </h1>
            <p className="text-xs sm:text-sm text-gray-600">
              Speak in Telugu or Hindi. KisanMitra AI understands your questions, remembers your 3-acre cotton farm in Warangal, and answers aloud.
            </p>
          </div>

          {/* Language Switcher Quick Pill */}
          <div className="flex items-center gap-2 bg-gray-50 p-1.5 rounded-2xl border border-gray-200">
            {(['te', 'hi', 'en'] as LanguageCode[]).map((code) => {
              const active = selectedLanguage === code;
              return (
                <button
                  key={code}
                  onClick={() => onSelectLanguage(code)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    active ? 'bg-emerald-800 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {LANGUAGE_LOCALES[code].nativeName}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Voice Assistant Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Chat Conversation Stream (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-gray-100 shadow-xs flex flex-col h-[580px] overflow-hidden">
          {/* Header bar of chat */}
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-700 text-white flex items-center justify-center text-xs font-bold">
                KM
              </div>
              <div>
                <h3 className="text-xs font-bold text-gray-900">KisanMitra AI Conversation</h3>
                <p className="text-[10px] text-gray-500">Speaking with {profile.name} (Warangal)</p>
              </div>
            </div>

            <button
              onClick={onClearChat}
              className="p-1.5 rounded-lg hover:bg-gray-200 text-gray-400 hover:text-gray-600 transition text-xs flex items-center gap-1 cursor-pointer"
              title="Clear conversation"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Clear</span>
            </button>
          </div>

          {/* Chat Messages scroll area */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {chatHistory.map((msg) => {
              const isUser = msg.role === 'user';
              const isSpeaking = activeSpeakingMsgId === msg.id;

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed shadow-2xs ${
                      isUser
                        ? 'bg-emerald-800 text-white rounded-br-none'
                        : 'bg-emerald-50/80 text-gray-800 border border-emerald-100 rounded-bl-none'
                    }`}
                  >
                    {/* Role header */}
                    <div className="flex items-center justify-between gap-3 mb-1.5 opacity-80 text-[10px]">
                      <span className="font-bold flex items-center gap-1">
                        {isUser ? <User className="w-3 h-3" /> : <Bot className="w-3 h-3 text-emerald-700" />}
                        {isUser ? 'You (రైతు)' : 'KisanMitra AI (కిసాన్ మిత్ర)'}
                      </span>
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    {/* Message content */}
                    <div className="whitespace-pre-wrap font-sans text-xs">
                      {msg.content}
                    </div>

                    {/* Assistant metadata tags */}
                    {!isUser && (
                      <div className="mt-3 pt-2.5 border-t border-emerald-200/60 flex flex-wrap items-center justify-between gap-2">
                        {msg.cropDetected && (
                          <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-200/70 text-emerald-950 font-semibold">
                            🌾 {msg.cropDetected}
                          </span>
                        )}

                        {/* Read Aloud button */}
                        <button
                          onClick={() => handleSpeakMessage(msg.id, msg.content, msg.language)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition cursor-pointer ${
                            isSpeaking
                              ? 'bg-emerald-700 text-white animate-pulse'
                              : 'bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-100'
                          }`}
                        >
                          {isSpeaking ? (
                            <>
                              <VolumeX className="w-3 h-3" />
                              <span>Speaking...</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3 h-3 text-emerald-700" />
                              <span>వినండి (Listen)</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Follow-up question banner */}
                  {!isUser && msg.followUpQuestion && (
                    <div className="mt-1 text-[11px] text-emerald-800 bg-emerald-100/50 px-3 py-1 rounded-lg border border-emerald-200 max-w-[85%]">
                      <span className="font-bold">Follow up: </span>{msg.followUpQuestion}
                    </div>
                  )}
                </div>
              );
            })}

            {/* Interim live speech recognition feedback */}
            {isRecording && interimTranscript && (
              <div className="flex flex-col items-end">
                <div className="max-w-[85%] rounded-2xl p-3 text-xs bg-emerald-700/80 text-white animate-pulse">
                  <span className="text-[10px] opacity-75">Listening...</span>
                  <p className="italic font-medium">{interimTranscript}</p>
                </div>
              </div>
            )}

            {/* Thinking indicator */}
            {isProcessing && (
              <div className="flex items-center gap-2 text-xs text-gray-500 py-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                <span>KisanMitra AI is formulating agricultural advice...</span>
              </div>
            )}

            <div ref={chatBottomRef} />
          </div>

          {/* Text Input Fallback Bar */}
          <div className="p-3 border-t border-gray-100 bg-white">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendQuery(inputText);
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  selectedLanguage === 'te'
                    ? 'మీ వ్యవసాయ ప్రశ్నను ఇక్కడ టైప్ చేయండి...'
                    : selectedLanguage === 'hi'
                    ? 'अपना कृषि प्रश्न यहाँ लिखें...'
                    : 'Type your farming question here...'
                }
                className="flex-1 px-4 py-2.5 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || isProcessing}
                className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-300 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Marquee Animated Mic & Suggested Prompts (5 cols) */}
        <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
          {/* Large Animated Microphone Studio Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xs text-center space-y-6 flex flex-col items-center justify-center">
            <div className="space-y-1">
              <span className="text-xs uppercase font-extrabold text-emerald-700 tracking-wider">
                Voice Input Console
              </span>
              <h3 className="text-xl font-extrabold text-gray-900">
                {isRecording ? 'Listening to Farmer...' : 'Tap & Speak Your Question'}
              </h3>
              <p className="text-xs text-gray-500 max-w-xs">
                Language: <strong className="text-emerald-900">{LANGUAGE_LOCALES[selectedLanguage].nativeName}</strong>
              </p>
            </div>

            {/* MARQUEE ANIMATED MIC BUTTON */}
            <div className="relative my-2">
              {/* Pulsing ripple waves when recording */}
              {isRecording && (
                <>
                  <div className="absolute -inset-6 rounded-full bg-emerald-500/20 animate-ping" style={{ animationDuration: '2s' }}></div>
                  <div className="absolute -inset-12 rounded-full bg-emerald-400/10 animate-ping" style={{ animationDuration: '3s' }}></div>
                </>
              )}

              <button
                type="button"
                onClick={isRecording ? () => handleStopRecording() : handleStartRecording}
                disabled={isProcessing}
                className={`relative w-28 h-28 rounded-full flex flex-col items-center justify-center text-white transition-all transform shadow-2xl cursor-pointer ${
                  isRecording
                    ? 'bg-rose-600 hover:bg-rose-700 scale-105 shadow-rose-600/40'
                    : 'bg-gradient-to-tr from-emerald-800 via-emerald-600 to-green-500 hover:scale-105 shadow-emerald-700/40'
                }`}
                title={isRecording ? 'Tap to stop recording' : 'Tap to start speaking'}
              >
                {isRecording ? (
                  <>
                    <MicOff className="w-10 h-10 animate-bounce" />
                    <span className="text-[10px] font-mono mt-1 font-bold">{recordingSeconds}s</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-10 h-10" />
                    <span className="text-[10px] font-bold mt-1 tracking-wide">SPEAK</span>
                  </>
                )}
              </button>
            </div>

            {/* Audio Wave Visualizer Bars */}
            <div className="flex items-center gap-1.5 h-8">
              {[4, 12, 24, 16, 28, 8, 22, 14, 26, 10].map((h, i) => (
                <span
                  key={i}
                  className={`w-1 rounded-full transition-all ${
                    isRecording
                      ? 'bg-emerald-600 animate-wave-bar'
                      : 'bg-gray-200'
                  }`}
                  style={{
                    height: isRecording ? undefined : `${h / 2}px`,
                    animationDelay: `${i * 0.1}s`
                  }}
                ></span>
              ))}
            </div>

            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-1.5 text-left">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          {/* Quick Voice Prompt Chips */}
          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-xs space-y-3">
            <h4 className="text-xs uppercase font-extrabold text-gray-500 tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>Tap a Sample Farming Question:</span>
            </h4>
            <div className="space-y-2">
              {(promptSuggestions[selectedLanguage] || promptSuggestions.te).map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendQuery(prompt)}
                  disabled={isProcessing}
                  className="w-full text-left p-2.5 rounded-xl bg-emerald-50/60 hover:bg-emerald-100/80 border border-emerald-100 text-xs text-emerald-950 font-medium transition flex items-center justify-between group cursor-pointer"
                >
                  <span className="leading-snug">"{prompt}"</span>
                  <ArrowRight className="w-3.5 h-3.5 text-emerald-600 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
