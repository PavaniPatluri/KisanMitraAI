import React from 'react';
import {
  Mic,
  Activity,
  CloudSun,
  TrendingUp,
  FileText,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Users,
  Award,
  Zap,
  Globe2,
  PhoneCall,
  ChevronRight,
  Wheat,
  Bot
} from 'lucide-react';
import { LanguageCode } from '../types/index.ts';

interface LandingPageProps {
  onNavigate: (view: string) => void;
  selectedLanguage: LanguageCode;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, selectedLanguage }) => {
  return (
    <div className="space-y-16 sm:space-y-24 pb-12">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-8 sm:pt-14 pb-12 sm:pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold tracking-wide shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700 animate-spin" style={{ animationDuration: '6s' }} />
                <span>Every Farmer Deserves an AI Expert • ప్రతి రైతుకు ఒక AI నిపుణుడు</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight leading-[1.12]">
                Smart Farming Starts with a <span className="text-emerald-700 underline decoration-emerald-300 decoration-wavy decoration-2">Conversation</span>.
              </h1>

              <p className="text-lg sm:text-xl text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Your intelligent farming companion. Ask questions, diagnose crop problems, understand weather, and make better farming decisions in your own language.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-base shadow-lg shadow-emerald-800/25 hover:shadow-xl hover:shadow-emerald-800/30 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
                >
                  <span>Explore KisanMitra</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate('voice')}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-900 font-bold text-base border-2 border-emerald-600 shadow-md transition-all flex items-center justify-center gap-2.5 cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-800">
                    <Mic className="w-3.5 h-3.5 animate-pulse" />
                  </div>
                  <span>Talk to AI Assistant</span>
                </button>
              </div>

              {/* Trust Badges */}
              <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-gray-600 font-medium">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Multilingual (Telugu & Hindi)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Gemini 3.8 Vision Diagnostic</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Real AGMARKNET Mandi Rates</span>
                </div>
              </div>
            </div>

            {/* Right Hero Visual: Indian farmer in green field with smartphone & AI interface elements */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Glow ring */}
                <div className="absolute -inset-4 bg-gradient-to-tr from-emerald-500/20 via-green-400/20 to-teal-500/20 rounded-3xl blur-2xl -z-10"></div>

                {/* Hero Card Container */}
                <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-2xl border border-emerald-100 relative overflow-hidden">
                  {/* Visual Header Banner */}
                  <div className="relative h-64 sm:h-72 rounded-2xl bg-gradient-to-b from-emerald-900 via-emerald-800 to-green-900 overflow-hidden flex flex-col justify-between p-5 text-white">
                    {/* SVG Illustration of Farmer in Field with Smartphone */}
                    <div className="absolute inset-0 opacity-25 mix-blend-overlay">
                      <svg viewBox="0 0 400 300" className="w-full h-full">
                        <path d="M 0 240 Q 100 200 200 230 T 400 210 L 400 300 L 0 300 Z" fill="#14532D" />
                        <path d="M 0 260 Q 150 240 250 265 T 400 250 L 400 300 L 0 300 Z" fill="#0f3d21" />
                      </svg>
                    </div>

                    {/* Top status */}
                    <div className="flex items-center justify-between z-10">
                      <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-emerald-200">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                        <span>Live AI Field Assistant</span>
                      </div>
                      <span className="text-xs bg-emerald-700/80 px-2.5 py-0.5 rounded-md font-mono">
                        Warangal, Telangana
                      </span>
                    </div>

                    {/* Illustrated stylized representation */}
                    <div className="z-10 flex items-center justify-center py-4">
                      <div className="relative flex flex-col items-center">
                        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-500 to-green-400 flex items-center justify-center shadow-lg shadow-emerald-950/40 border-2 border-emerald-200">
                          <Bot className="w-10 h-10 text-white" />
                        </div>
                        <div className="mt-2 text-center">
                          <span className="text-sm font-bold text-white">కిసాన్ మిత్ర వాయిస్ అసిస్టెంట్</span>
                          <p className="text-[11px] text-emerald-200">"మీ పత్తి పంటకు సరైన రక్షణ"</p>
                        </div>
                      </div>
                    </div>

                    {/* Speech Bar Simulation */}
                    <div className="z-10 bg-black/50 backdrop-blur-md rounded-xl p-3 border border-emerald-400/30 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
                        <Mic className="w-4 h-4 text-white" />
                      </div>
                      <div className="text-xs">
                        <p className="font-semibold text-white">"పత్తిలో ఆకుమచ్చ కనిపిస్తోంది. ఏం చేయాలి?"</p>
                        <p className="text-[10px] text-emerald-300">Telugu Voice Input • 98% Accuracy</p>
                      </div>
                    </div>
                  </div>

                  {/* Quick stats below hero card */}
                  <div className="grid grid-cols-3 gap-2 pt-4 text-center">
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
                      <p className="text-xs text-gray-500 font-medium">Languages</p>
                      <p className="text-base font-bold text-emerald-900">6 Indic</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
                      <p className="text-xs text-gray-500 font-medium">Crop Diagnoses</p>
                      <p className="text-base font-bold text-emerald-900">&lt; 3 Sec</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
                      <p className="text-xs text-gray-500 font-medium">Mandi Rates</p>
                      <p className="text-base font-bold text-emerald-900">Live APMC</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION: OUR MISSION */}
      <section className="bg-white py-16 rounded-3xl border border-gray-100 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <h2 className="text-xs uppercase font-extrabold text-emerald-700 tracking-wider">Our Core Mission</h2>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight">
              Bridging Agricultural Science & Grassroots Farmers
            </h3>
            <p className="text-base text-gray-600 leading-relaxed">
              India has over 140 million farming households, but agricultural scientists and extension officers cannot visit every field. KisanMitra AI places a 24/7 agricultural expert in the pocket of every farmer, speaking their mother tongue.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-emerald-50/70 border border-emerald-100 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center">
                <Globe2 className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-gray-900">Voice-First Vernacular Access</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Farmers do not need to type complicated botanical names. They simply speak in Telugu, Hindi, Tamil, Kannada, or Marathi, and KisanMitra understands regional idioms and local crop varieties.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-emerald-50/70 border border-emerald-100 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-gray-900">Safe, Science-Backed Guidance</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                We strictly avoid dangerous pesticide cocktail prescriptions. Our AI recommends verified biological, cultural, and approved IPM practices aligned with Indian Council of Agricultural Research (ICAR) guidelines.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-emerald-50/70 border border-emerald-100 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-gray-900">Market & Scheme Empowerment</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Farmers often sell below minimum support prices due to lack of market data. We aggregate live mandi arrivals and demystify government subsidies like PM-KISAN, KCC, and Rythu Bharosa.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION: AI CROP DOCTOR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-emerald-900 to-green-950 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-800 text-emerald-200 text-xs font-semibold">
                <Activity className="w-3.5 h-3.5 text-emerald-300" />
                <span>Gemini 3.8 Vision Powered</span>
              </div>
              <h3 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
                AI Crop Doctor: Instant Leaf Disease Diagnosis
              </h3>
              <p className="text-sm sm:text-base text-emerald-200 leading-relaxed">
                Take a photograph of an affected leaf, stem, or fruit. Our vision models scan for early blight, powdery mildew, pink bollworm damage, thrips, and nutrient deficiencies within seconds.
              </p>
              <ul className="space-y-2 text-xs sm:text-sm text-emerald-100 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Severity rating (Mild, Moderate, Severe) with confidence percentage</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Biological & organic solutions first, safe dosage recommendations</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Preserves full diagnosis history in your farm health logbook</span>
                </li>
              </ul>
              <div className="pt-4">
                <button
                  onClick={() => onNavigate('crop-doctor')}
                  className="px-6 py-3 rounded-xl bg-white text-emerald-950 font-bold text-sm hover:bg-emerald-50 transition shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <span>Diagnose a Crop Leaf Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 bg-emerald-800/60 rounded-2xl p-6 border border-emerald-700/50 space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-700 pb-3">
                <span className="text-xs uppercase font-bold text-emerald-300">Live Sample Diagnosis</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  Moderate Severity
                </span>
              </div>
              <div>
                <p className="text-xs text-emerald-300">Crop: Cotton (పత్తి)</p>
                <h5 className="text-lg font-bold text-white">Alternaria Leaf Spot</h5>
                <p className="text-xs text-emerald-200 mt-1">
                  Concentric target-board rings on middle canopy leaves caused by recent rain humidity.
                </p>
              </div>
              <div className="bg-emerald-900/80 p-3 rounded-xl text-xs space-y-1">
                <p className="font-semibold text-emerald-300">Recommended Action:</p>
                <p className="text-emerald-100">
                  Foliar spray with Copper Oxychloride (3g/L) or Trichoderma viride. Avoid overhead leaf wetting.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION: VOICE ASSISTANT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
          <h2 className="text-xs uppercase font-extrabold text-emerald-700 tracking-wider">Primary Feature</h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight">
            Multilingual Voice Assistant
          </h3>
          <p className="text-sm text-gray-600">
            Powered by Gnani.ai (Prisma STT, Evon NLU, Timbre TTS) with native browser audio fallbacks. Speak naturally just like calling your local agricultural officer.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Mic className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900">Natural Voice Recognition</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Trained on Indian regional accents and farming idioms. Understands spoken Telugu, Hindi, Tamil, Kannada, Marathi, and English.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900">Context-Aware Agronomy</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Remembers farmer Ramesh's 3-acre cotton field in Warangal, soil type, and irrigation history to give personalized answers.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900">Instant Audio Playback</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Don't want to read long texts? Tap the speaker button to hear the answer read aloud clearly in your native language.
            </p>
          </div>
        </div>

        <div className="text-center mt-8">
          <button
            onClick={() => onNavigate('voice')}
            className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md transition inline-flex items-center gap-2 cursor-pointer"
          >
            <Mic className="w-4 h-4" />
            <span>Launch Multilingual Voice Assistant</span>
          </button>
        </div>
      </section>

      {/* SECTION: 4 MODULAR PILLARS (WEATHER, MANDI, SCHEMES, RISK) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Weather */}
          <div
            onClick={() => onNavigate('weather')}
            className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs hover:border-emerald-500 hover:shadow-md transition cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <CloudSun className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900 text-base mb-1">Weather & Spray Alerts</h4>
            <p className="text-xs text-gray-600 leading-relaxed mb-4">
              Real-time temperature, humidity, wind, rainfall probability, and optimal morning spraying windows.
            </p>
            <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1 group-hover:gap-2 transition-all">
              <span>View Weather</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Mandi */}
          <div
            onClick={() => onNavigate('mandi')}
            className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs hover:border-emerald-500 hover:shadow-md transition cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900 text-base mb-1">Smart Mandi Rates</h4>
            <p className="text-xs text-gray-600 leading-relaxed mb-4">
              Real APMC market prices, 30-day historical trend charts, and commodity comparisons across Telangana.
            </p>
            <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1 group-hover:gap-2 transition-all">
              <span>Check Mandi Rates</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Schemes */}
          <div
            onClick={() => onNavigate('schemes')}
            className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs hover:border-emerald-500 hover:shadow-md transition cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900 text-base mb-1">Government Schemes</h4>
            <p className="text-xs text-gray-600 leading-relaxed mb-4">
              Eligibility guides and direct application links for PM-KISAN, KCC, PMFBY Crop Insurance, and Rythu Bharosa.
            </p>
            <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1 group-hover:gap-2 transition-all">
              <span>Explore Schemes</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Farm Risk */}
          <div
            onClick={() => onNavigate('risk')}
            className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs hover:border-emerald-500 hover:shadow-md transition cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-gray-900 text-base mb-1">Farm Risk Intelligence</h4>
            <p className="text-xs text-gray-600 leading-relaxed mb-4">
              Multi-factor risk index combining weather, pest pressure, growth stages, and irrigation resilience.
            </p>
            <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1 group-hover:gap-2 transition-all">
              <span>Assess Farm Risk</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </section>

      {/* SECTION: WHY KISANMITRA AI */}
      <section className="bg-emerald-900 text-white rounded-3xl py-14 px-6 sm:px-12 max-w-7xl mx-auto shadow-lg">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
          <h2 className="text-xs uppercase font-extrabold text-emerald-300 tracking-wider">The KisanMitra Advantage</h2>
          <h3 className="text-3xl font-extrabold tracking-tight">Why Farmers Choose KisanMitra AI</h3>
          <p className="text-xs sm:text-sm text-emerald-200">
            Engineered specifically for Indian smallholder farmers with realistic connectivity and regional agro-climatic intelligence.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center sm:text-left">
          <div className="bg-emerald-800/50 p-5 rounded-2xl border border-emerald-700/60 space-y-2">
            <span className="text-2xl font-black text-emerald-300">01</span>
            <h5 className="font-bold text-white text-base">Regional Language Fluency</h5>
            <p className="text-xs text-emerald-200">
              Speaks Telugu & Hindi natively, understands local farmer terms like 'పూత రాలడం', 'నల్లరేగడి', 'ముడత తెగులు'.
            </p>
          </div>

          <div className="bg-emerald-800/50 p-5 rounded-2xl border border-emerald-700/60 space-y-2">
            <span className="text-2xl font-black text-emerald-300">02</span>
            <h5 className="font-bold text-white text-base">Zero Toxic Cocktails</h5>
            <p className="text-xs text-emerald-200">
              Prioritizes bio-fungicides (Trichoderma, Neem), pheromone lures, and cultural practices to protect soil and health.
            </p>
          </div>

          <div className="bg-emerald-800/50 p-5 rounded-2xl border border-emerald-700/60 space-y-2">
            <span className="text-2xl font-black text-emerald-300">03</span>
            <h5 className="font-bold text-white text-base">Data Privacy & Transparency</h5>
            <p className="text-xs text-emerald-200">
              Clear distinction between live AI model inference and verified agricultural extension practices.
            </p>
          </div>

          <div className="bg-emerald-800/50 p-5 rounded-2xl border border-emerald-700/60 space-y-2">
            <span className="text-2xl font-black text-emerald-300">04</span>
            <h5 className="font-bold text-white text-base">End-to-End Farm Lifecycle</h5>
            <p className="text-xs text-emerald-200">
              From seed treatment and weather alerts to mandi sale and government financial support in one seamless app.
            </p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={() => onNavigate('dashboard')}
            className="px-8 py-3.5 rounded-xl bg-white text-emerald-950 font-bold text-sm hover:bg-emerald-50 transition shadow-lg cursor-pointer"
          >
            Get Started with Demo Farmer Ramesh
          </button>
        </div>
      </section>
    </div>
  );
};
