import React from 'react';
import { Sprout, PhoneCall, ExternalLink, Heart, Globe2, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-emerald-950 text-emerald-100 border-t border-emerald-900 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand & Vision */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-md">
                <Sprout className="w-5 h-5 text-emerald-200" />
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">KisanMitra AI</span>
            </div>
            <p className="text-xs text-emerald-300 leading-relaxed">
              Every Farmer Deserves an AI Expert. Empowering Indian agriculture with voice-first multilingual intelligence, visual crop diagnostics, and real-time market transparency.
            </p>
            <div className="flex items-center gap-2 pt-2 text-xs text-emerald-400">
              <Globe2 className="w-3.5 h-3.5 text-emerald-300" />
              <span>Available in Telugu, Hindi, English & regional languages</span>
            </div>
          </div>

          {/* Core Modules */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">AI Farming Modules</h4>
            <ul className="space-y-2 text-xs text-emerald-300">
              <li>
                <button onClick={() => onNavigate('crop-doctor')} className="hover:text-white transition cursor-pointer">
                  AI Crop Doctor (Disease Diagnostics)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('voice')} className="hover:text-white transition cursor-pointer">
                  Voice Assistant (Telugu & Hindi)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('weather')} className="hover:text-white transition cursor-pointer">
                  Weather & Spray Intelligence
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('mandi')} className="hover:text-white transition cursor-pointer">
                  Smart Mandi Price Comparison
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('risk')} className="hover:text-white transition cursor-pointer">
                  AI Farm Risk Engine
                </button>
              </li>
            </ul>
          </div>

          {/* Official Helplines & Govt Resources */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">National Helplines</h4>
            <ul className="space-y-2 text-xs text-emerald-300">
              <li className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Kisan Call Centre: <strong>1800-180-1551</strong> (Toll Free)</span>
              </li>
              <li className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>PM-KISAN Helpdesk: <strong>155261 / 011-24300606</strong></span>
              </li>
              <li className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Crop Insurance (PMFBY): <strong>1800-200-5142</strong></span>
              </li>
              <li className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Telangana KVK Warangal: <strong>08712-245600</strong></span>
              </li>
            </ul>
          </div>

          {/* Trust & Safety Disclaimer */}
          <div className="bg-emerald-900/60 rounded-xl p-4 border border-emerald-800">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-200 mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Agricultural Safety Policy</span>
            </div>
            <p className="text-[11px] text-emerald-300 leading-normal">
              KisanMitra AI provides advisory insights based on verified agricultural best practices. Always confirm severe pest outbreaks with your local Mandal Agriculture Officer (AEO) or Krishi Vigyan Kendra before applying chemical treatments.
            </p>
          </div>
        </div>

        <div className="border-t border-emerald-900/80 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-emerald-400 gap-3">
          <p>© 2026 KisanMitra AI. Built for the hardworking farmers of India.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              Powered by <span className="font-semibold text-white">Google Gemini 3.8</span> & <span className="font-semibold text-white">Gnani.ai</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
