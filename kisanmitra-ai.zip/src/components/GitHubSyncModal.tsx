import React, { useState } from 'react';
import {
  Github,
  Download,
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  ShieldCheck,
  X,
  Terminal,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api.ts';

interface GitHubSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitHubSyncModal: React.FC<GitHubSyncModalProps> = ({ isOpen, onClose }) => {
  const [token, setToken] = useState<string>('');
  const [pushing, setPushing] = useState<boolean>(false);
  const [pushSuccess, setPushSuccess] = useState<string | null>(null);
  const [pushError, setPushError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const repoUrl = 'https://github.com/PavaniPatluri/KisanMitraAI';

  const handlePush = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim()) return;

    setPushing(true);
    setPushError(null);
    setPushSuccess(null);

    try {
      const res = await api.pushToGitHub(token.trim());
      if (res.success) {
        setPushSuccess(res.message || 'Successfully pushed to GitHub repo!');
      } else {
        setPushError(res.error || 'Failed to push. Please check your GitHub token and permissions.');
      }
    } catch (err: any) {
      setPushError(err?.message || 'Push request failed.');
    } finally {
      setPushing(false);
    }
  };

  const handleCopyCommands = () => {
    const text = `git clone ${repoUrl}.git\ncd KisanMitraAI\n# (or copy files from ZIP)\ngit add .\ngit commit -m "feat: initial KisanMitra AI release"\ngit push -u origin main`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-gray-100 space-y-6 animate-in fade-in duration-150">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-gray-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gray-900 text-white flex items-center justify-center">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-gray-900">
                GitHub Repository Sync
              </h3>
              <a
                href={repoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 mt-0.5"
              >
                <span>PavaniPatluri/KisanMitraAI</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-1 rounded-lg text-lg font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Option 1: 1-Click Push via Personal Access Token */}
        <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
          <div className="flex items-center gap-2">
            <UploadCloud className="w-4 h-4 text-emerald-700" />
            <h4 className="font-extrabold text-xs text-emerald-950 uppercase tracking-wide">
              Option 1: Direct Push via GitHub Token
            </h4>
          </div>
          <p className="text-xs text-emerald-900 leading-relaxed">
            Enter your GitHub Personal Access Token (classic token with <code>repo</code> scope) to push the local commit directly to your GitHub repository:
          </p>

          <form onSubmit={handlePush} className="space-y-2">
            <input
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
              className="w-full px-3 py-2 text-xs font-mono border border-emerald-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
            />
            <div className="flex items-center justify-between text-[10px] text-gray-500">
              <a
                href="https://github.com/settings/tokens/new?scopes=repo&description=KisanMitraAI"
                target="_blank"
                rel="noopener noreferrer"
                className="text-emerald-700 hover:underline flex items-center gap-0.5"
              >
                <span>Generate token on GitHub (1 click)</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
              <span>Token is not saved</span>
            </div>

            <button
              type="submit"
              disabled={pushing || !token.trim()}
              className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-300 text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-2 cursor-pointer mt-1"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>{pushing ? 'Pushing to GitHub...' : 'Push Code to GitHub (PavaniPatluri/KisanMitraAI)'}</span>
            </button>
          </form>

          {pushSuccess && (
            <div className="p-3 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>{pushSuccess}</span>
            </div>
          )}

          {pushError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{pushError}</span>
            </div>
          )}
        </div>

        {/* Option 2: Download Full Project ZIP */}
        <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-gray-700" />
              <h4 className="font-extrabold text-xs text-gray-900 uppercase tracking-wide">
                Option 2: Download Complete Project ZIP
              </h4>
            </div>
            <span className="text-[10px] font-mono font-bold text-gray-500">134 KB</span>
          </div>
          <p className="text-xs text-gray-600">
            Download all source files, configurations, datasets, and server code to push manually or work locally.
          </p>
          <a
            href="/api/download-zip"
            download="KisanMitraAI.zip"
            className="w-full py-2.5 rounded-xl bg-white hover:bg-gray-100 border border-gray-300 text-gray-800 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-700" />
            <span>Download KisanMitraAI.zip</span>
          </a>
        </div>

        {/* Option 3: Terminal Command instructions */}
        <div className="p-4 rounded-2xl bg-gray-900 text-gray-200 text-xs space-y-2 font-mono">
          <div className="flex items-center justify-between text-[11px] text-gray-400">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span>Manual Push via Terminal</span>
            </span>
            <button
              onClick={handleCopyCommands}
              className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
          <p className="text-[11px] text-emerald-300 leading-relaxed overflow-x-auto">
            git remote add origin {repoUrl}.git<br />
            git branch -M main<br />
            git push -u origin main
          </p>
        </div>

        {/* Footer */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
