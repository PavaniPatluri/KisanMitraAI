import React, { useState } from 'react';
import {
  Sprout,
  Mic,
  Activity,
  CloudSun,
  TrendingUp,
  FileText,
  ShieldAlert,
  User,
  Menu,
  X,
  Languages,
  CheckCircle2,
  Sparkles,
  LogIn
} from 'lucide-react';
import { LanguageCode, FarmerProfile } from '../types/index.ts';
import { LANGUAGE_LOCALES } from '../utils/speech.ts';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  selectedLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
  profile: FarmerProfile;
  apiStatus: {
    geminiLive: boolean;
    gnaniLive: boolean;
  };
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  selectedLanguage,
  onSelectLanguage,
  profile,
  apiStatus
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);

  const navItems = [
    { id: 'landing', label: 'Home' },
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'voice', label: 'Voice AI', highlight: true, icon: Mic },
    { id: 'crop-doctor', label: 'Crop Doctor', icon: Activity },
    { id: 'weather', label: 'Weather', icon: CloudSun },
    { id: 'mandi', label: 'Mandi Prices', icon: TrendingUp },
    { id: 'schemes', label: 'Govt Schemes', icon: FileText },
    { id: 'risk', label: 'Farm Risk', icon: ShieldAlert },
    { id: 'profile', label: 'Farm Profile', icon: User },
    { id: 'login', label: 'Sign In / Login', icon: LogIn }
  ];

  const handleNavClick = (viewId: string) => {
    onNavigate(viewId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-emerald-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div
            onClick={() => onNavigate('landing')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 flex items-center justify-center text-white shadow-md shadow-emerald-700/20 group-hover:scale-105 transition-transform">
              <Sprout className="w-6 h-6 text-emerald-200" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg text-emerald-950 tracking-tight">KisanMitra</span>
                <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-1.5 py-0.5 rounded-sm">AI</span>
              </div>
              <p className="text-[10px] text-emerald-700 font-medium">కిసాన్ మిత్ర • Farmer's AI Expert</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const isActive = currentView === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : item.highlight
                      ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                      : 'text-gray-700 hover:text-emerald-800 hover:bg-emerald-50/70'
                  }`}
                >
                  {Icon && <Icon className="w-3.5 h-3.5" />}
                  {item.label}
                  {item.highlight && !isActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping"></span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Controls: AI Badge, Language Selector & Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* AI Engine Status Pill */}
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-800 font-medium">
              <Sparkles className="w-3 h-3 text-emerald-600" />
              <span>Gemini 3.8</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            </div>

            {/* Language Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 hover:border-emerald-500 bg-white text-gray-800 text-xs font-semibold shadow-2xs hover:bg-emerald-50/50 transition cursor-pointer"
                title="Select Language"
              >
                <Languages className="w-4 h-4 text-emerald-700" />
                <span className="font-bold text-emerald-900">
                  {LANGUAGE_LOCALES[selectedLanguage]?.nativeName || 'తెలుగు'}
                </span>
              </button>

              {langMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 py-1.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                  onClick={() => setLangMenuOpen(false)}
                >
                  <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                    Select Language / భాష
                  </div>
                  {(Object.keys(LANGUAGE_LOCALES) as LanguageCode[]).map((code) => {
                    const l = LANGUAGE_LOCALES[code];
                    const isSelected = selectedLanguage === code;
                    return (
                      <button
                        key={code}
                        onClick={() => onSelectLanguage(code)}
                        className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-emerald-50 transition cursor-pointer ${
                          isSelected ? 'font-bold text-emerald-800 bg-emerald-50/60' : 'text-gray-700'
                        }`}
                      >
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold">{l.nativeName}</span>
                          <span className="text-[10px] text-gray-500">{l.name}</span>
                        </div>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Farmer Profile & Login Action */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onNavigate('profile')}
                className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-full bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-xs font-medium text-emerald-900 transition cursor-pointer"
                title="View Farm Profile"
              >
                <div className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px] font-bold">
                  {profile.name.charAt(0)}
                </div>
                <span className="hidden sm:inline font-semibold">{profile.name.split(' ')[0]}</span>
              </button>

              <button
                onClick={() => onNavigate('login')}
                className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg border border-gray-200 hover:border-emerald-500 bg-white hover:bg-emerald-50 text-gray-700 hover:text-emerald-900 text-xs font-semibold shadow-2xs transition cursor-pointer"
                title="Sign In or Switch Account"
              >
                <LogIn className="w-3.5 h-3.5 text-emerald-700" />
                <span>లాగిన్ (Login)</span>
              </button>
            </div>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-gray-600 hover:text-emerald-800 hover:bg-gray-100 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-gray-200 px-4 pt-2 pb-4 space-y-1">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition ${
                  isActive
                    ? 'bg-emerald-800 text-white'
                    : 'text-gray-800 hover:bg-emerald-50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {Icon && <Icon className="w-4 h-4 text-emerald-600" />}
                  <span>{item.label}</span>
                </div>
                {item.highlight && (
                  <span className="text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                    Voice
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
