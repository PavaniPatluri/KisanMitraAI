import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { storage } from './src/server/storage.ts';
import { diagnoseCrop, chatAgriculturalAdvisor } from './src/server/geminiService.ts';
import { getGnaniStatus, transcribeWithGnaniPrisma, synthesizeWithGnaniTimbre } from './src/server/gnaniService.ts';
import { fetchWeather } from './src/server/weatherService.ts';
import { calculateFarmRisk } from './src/server/riskService.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '30mb' }));
  app.use(express.urlencoded({ extended: true, limit: '30mb' }));

  // API Status & AI Integration Info
  app.get('/api/status', (_req: Request, res: Response) => {
    const geminiKey = process.env.GEMINI_API_KEY || '';
    const hasValidGeminiKey = Boolean(geminiKey && geminiKey !== 'MY_GEMINI_API_KEY');
    const gnani = getGnaniStatus();

    res.json({
      status: 'online',
      app: 'KisanMitra AI',
      version: '1.0.0',
      aiCapabilities: {
        geminiVision: {
          enabled: true,
          liveApiKey: hasValidGeminiKey,
          model: 'gemini-3.8-flash'
        },
        gnaniVoice: {
          enabled: gnani.isConfigured,
          liveApiKey: gnani.hasApiKey,
          endpoints: gnani.endpoints,
          browserFallbackActive: !gnani.isConfigured
        }
      }
    });
  });

  // Download repository zip archive
  app.get('/api/download-zip', (_req: Request, res: Response) => {
    const zipPath = path.resolve(__dirname, 'public', 'kisanmitra-ai.zip');
    res.download(zipPath, 'KisanMitraAI.zip');
  });

  // Push to user's GitHub repo with Personal Access Token
  app.post('/api/github/push', async (req: Request, res: Response) => {
    const { token } = req.body;
    if (!token) {
      res.status(400).json({ error: 'GitHub Personal Access Token is required to push to https://github.com/PavaniPatluri/KisanMitraAI' });
      return;
    }
    try {
      const { execSync } = await import('child_process');
      const cleanToken = token.trim();
      const authenticatedUrl = `https://${cleanToken}@github.com/PavaniPatluri/KisanMitraAI.git`;
      execSync(`git push -u "${authenticatedUrl}" main`, { stdio: 'pipe' });
      res.json({ success: true, message: 'Successfully pushed all code to https://github.com/PavaniPatluri/KisanMitraAI on branch main!' });
    } catch (err: any) {
      console.error('Git push error:', err);
      res.status(500).json({ error: err?.stderr?.toString() || err?.message || 'Git push failed. Please verify token permissions (repo scope).' });
    }
  });

  // Auth & Multiple Farmer Profiles
  app.get('/api/auth/profiles', (_req: Request, res: Response) => {
    res.json(storage.getProfiles());
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { phone, pin } = req.body;
    if (!phone) {
      res.status(400).json({ error: 'Mobile number is required' });
      return;
    }
    const result = storage.loginFarmer(phone, pin);
    if (!result.success) {
      res.status(401).json({ error: result.error });
      return;
    }
    res.json({ success: true, profile: result.profile });
  });

  app.post('/api/auth/switch', (req: Request, res: Response) => {
    const { id } = req.body;
    if (!id) {
      res.status(400).json({ error: 'Profile ID is required' });
      return;
    }
    const switched = storage.switchProfile(id);
    if (!switched) {
      res.status(404).json({ error: 'Farmer profile not found' });
      return;
    }
    res.json({ success: true, profile: switched });
  });

  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { name, phone, state, district, cropName, landArea, preferredLanguage } = req.body;
    if (!name || !phone) {
      res.status(400).json({ error: 'Name and Mobile number are required' });
      return;
    }
    const newFarmer = storage.registerFarmer({
      name,
      phone,
      state: state || 'Telangana',
      district: district || 'Warangal',
      location: req.body.location || district || 'Warangal',
      cropName: cropName || 'Cotton',
      cropGrowthStage: req.body.cropGrowthStage || 'Vegetative Stage',
      landArea: landArea || '2.0 Acres',
      soilType: req.body.soilType || 'Black Soil',
      irrigationMethod: req.body.irrigationMethod || 'Borewell',
      preferredLanguage: preferredLanguage || 'te',
      pin: req.body.pin || '1234'
    });
    res.status(201).json({ success: true, profile: newFarmer });
  });

  // Farmer Profile
  app.get('/api/profile', (_req: Request, res: Response) => {
    res.json(storage.getProfile());
  });

  app.put('/api/profile', (req: Request, res: Response) => {
    try {
      const updated = storage.updateProfile(req.body);
      res.json(updated);
    } catch (err) {
      res.status(400).json({ error: 'Failed to update profile' });
    }
  });

  // Tasks
  app.get('/api/tasks', (_req: Request, res: Response) => {
    res.json(storage.getTasks());
  });

  app.post('/api/tasks', (req: Request, res: Response) => {
    const { title, crop, category, dueDate, priority, notes, titleLocal } = req.body;
    if (!title) {
      res.status(400).json({ error: 'Title is required' });
      return;
    }
    const created = storage.addTask({
      title,
      crop: crop || 'Cotton',
      category: category || 'Scouting',
      dueDate: dueDate || new Date().toISOString().split('T')[0],
      completed: false,
      priority: priority || 'Medium',
      notes: notes || '',
      titleLocal: titleLocal || {}
    });
    res.status(201).json(created);
  });

  app.patch('/api/tasks/:id', (req: Request, res: Response) => {
    const updated = storage.updateTask(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }
    res.json(updated);
  });

  app.delete('/api/tasks/:id', (req: Request, res: Response) => {
    const success = storage.deleteTask(req.params.id);
    res.json({ success });
  });

  // Alerts
  app.get('/api/alerts', (_req: Request, res: Response) => {
    res.json(storage.getAlerts());
  });

  // Consultations & Past Diagnoses
  app.get('/api/consultations', (_req: Request, res: Response) => {
    res.json(storage.getConsultations());
  });

  app.post('/api/consultations', (req: Request, res: Response) => {
    try {
      const saved = storage.addConsultation(req.body);
      res.status(201).json(saved);
    } catch (err) {
      res.status(400).json({ error: 'Failed to save consultation' });
    }
  });

  app.delete('/api/consultations/:id', (req: Request, res: Response) => {
    const success = storage.deleteConsultation(req.params.id);
    res.json({ success });
  });

  // AI Crop Doctor Diagnosis endpoint
  app.post('/api/crop-doctor/diagnose', async (req: Request, res: Response) => {
    try {
      const { imageBase64, mimeType, cropType, symptoms, language } = req.body;
      const profile = storage.getProfile();

      const result = await diagnoseCrop({
        imageBase64,
        mimeType,
        cropType: cropType || profile.cropName,
        symptoms: symptoms || '',
        language: language || profile.preferredLanguage || 'te',
        profile
      });

      res.json(result);
    } catch (error: any) {
      console.error('Crop Doctor Error:', error);
      res.status(500).json({ error: error?.message || 'Failed to analyze crop image' });
    }
  });

  // Multilingual Voice Chat Assistant
  app.get('/api/chats', (_req: Request, res: Response) => {
    res.json(storage.getChatHistory());
  });

  app.post('/api/chats/clear', (_req: Request, res: Response) => {
    storage.clearChatHistory();
    res.json({ success: true });
  });

  app.post('/api/voice/chat', async (req: Request, res: Response) => {
    try {
      const { message, language } = req.body;
      if (!message || !message.trim()) {
        res.status(400).json({ error: 'Message is required' });
        return;
      }

      const profile = storage.getProfile();
      const userLang = language || profile.preferredLanguage || 'te';

      // Save user message to persistent storage
      storage.addChatMessage({
        role: 'user',
        content: message.trim(),
        language: userLang
      });

      // Generate response via Gemini agricultural reasoning
      const history = storage.getChatHistory().map(c => ({
        role: c.role,
        content: c.content
      }));

      const aiResponse = await chatAgriculturalAdvisor({
        message: message.trim(),
        language: userLang,
        history,
        profile
      });

      // Save assistant message to persistent storage
      const savedAssistantMsg = storage.addChatMessage({
        role: 'assistant',
        content: aiResponse.reply,
        language: userLang,
        cropDetected: aiResponse.cropDetected,
        recommendedAction: aiResponse.recommendedAction,
        followUpQuestion: aiResponse.followUpQuestion,
        suggestedQuestions: aiResponse.suggestedQuestions
      });

      res.json(savedAssistantMsg);
    } catch (err: any) {
      console.error('Voice Chat Error:', err);
      res.status(500).json({ error: err?.message || 'Failed to process voice query' });
    }
  });

  // Gnani AI proxy endpoints (STT & TTS)
  app.get('/api/gnani/status', (_req: Request, res: Response) => {
    res.json(getGnaniStatus());
  });

  // Weather Intelligence
  app.get('/api/weather', async (req: Request, res: Response) => {
    try {
      const district = (req.query.district as string) || 'warangal';
      const weather = await fetchWeather(district);
      res.json(weather);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch weather' });
    }
  });

  // Mandi Prices
  app.get('/api/mandi', (req: Request, res: Response) => {
    const all = storage.getMandiRecords();
    const { commodity, state, district, search } = req.query;

    let filtered = all;
    if (state && typeof state === 'string' && state !== 'All') {
      filtered = filtered.filter(m => m.state.toLowerCase() === state.toLowerCase());
    }
    if (district && typeof district === 'string' && district !== 'All') {
      filtered = filtered.filter(m => m.district.toLowerCase() === district.toLowerCase());
    }
    if (commodity && typeof commodity === 'string' && commodity !== 'All') {
      filtered = filtered.filter(m => m.commodity.toLowerCase().includes(commodity.toLowerCase()));
    }
    if (search && typeof search === 'string') {
      const s = search.toLowerCase();
      filtered = filtered.filter(
        m =>
          m.commodity.toLowerCase().includes(s) ||
          m.market.toLowerCase().includes(s) ||
          m.variety.toLowerCase().includes(s)
      );
    }

    res.json(filtered);
  });

  // Government Schemes
  app.get('/api/schemes', (req: Request, res: Response) => {
    const schemes = storage.getSchemes();
    const { category, search } = req.query;

    let filtered = schemes;
    if (category && typeof category === 'string' && category !== 'All') {
      filtered = filtered.filter(s => s.category.toLowerCase() === category.toLowerCase());
    }
    if (search && typeof search === 'string') {
      const s = search.toLowerCase();
      filtered = filtered.filter(
        item =>
          item.name.toLowerCase().includes(s) ||
          item.shortName.toLowerCase().includes(s) ||
          item.overview.toLowerCase().includes(s) ||
          item.tags.some(t => t.toLowerCase().includes(s))
      );
    }

    res.json(filtered);
  });

  // AI Farm Risk Intelligence
  app.get('/api/risk-assessment', async (req: Request, res: Response) => {
    try {
      const profile = storage.getProfile();
      const weather = await fetchWeather(profile.district || 'warangal');
      const consultations = storage.getConsultations();
      const risk = calculateFarmRisk(profile, weather, consultations);
      res.json(risk);
    } catch (err) {
      res.status(500).json({ error: 'Failed to calculate risk assessment' });
    }
  });

  // Frontend mounting: Vite middleware in dev, static files in production
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, port: PORT, host: '0.0.0.0' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌾 KisanMitra AI server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
